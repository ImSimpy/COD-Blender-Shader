"""CoD AutoShader - builds Blender materials for Call of Duty: Black Ops 7 models exported by Saluki (.cast).

Texture decoding follows Infinite Ward's packed texture sets (Drobot, "Rendering of Call of Duty:
Infinite Warfare", Digital Dragons 2017, slides 110-115) and was verified against BO7 exports:

  packed CS  (semantic 0x47)  RGB = fused diffuse+specular color (sRGB), A = metalness mask with
                              an insulator range: a <= 0.1 -> dielectric F0 = a, a > 0.1 -> metal.
                              BO7 techsets that don't use the mask store a constant alpha; those are
                              shaded as plain dielectrics.
  packed NOG (semantic 0x48)  R = gloss, G = normal X, B = occlusion, A = normal Y. The normal is
                              hemi-octahedron encoded with DirectX Y (confirmed by an integrability
                              test over 110 BO7 normal maps).
  semantic 0x49  emissive color     semantic 0x4a  opacity mask

Gloss -> GGX alpha uses the Call of Duty: WWII parameterization (Chan, "Material Advances in Call of
Duty: WWII", SIGGRAPH 2018, slide 6 errata): alpha = sqrt(2 / (1 + 2^(18 * gloss))).
Emissive maps are stored dim (a BO7 watch screen peaks at 0.43) because the engine scales them, so each one is
measured and lifted so its brightest pixel glows; the glow takes a colour tint.
Skin techsets (skin LUT 0x54, wrinkle maps 0xb/0xc, or a skin-tone 0x4e) store something other than
metalness in CS alpha, so they are shaded as dielectric skin with subsurface scattering.
Hair cards get a Marschner-style R / TRT / TT shader with anisotropic highlights around the strands;
eyes get a cornea coat, iris parallax and the lid shadow from the lacrimal mid-shadow shell.
Sights: lenses become tinted glass with the game's dirt map (including shader-driven glass like watch crystals,
which carry no textures at all); red dot / holo lenses get a collimated reticle
(it stays on the aim point when the head moves); scope surfaces (ads_scope_lens*) become a zoomed
picture-in-picture like the game's scope camera (Cycles Ray Portal), framed by the eye-relief shadow.
Bodycam Look (Blender 5.0+): one compositor node group for the bodycam-game camera - fisheye lens with color
fringes and soft edges, blown-out exposure with bloom, a flat warm grade, sharpening and sensor noise.
Animations: Import Animation layers CoD viewmodel clips on the NLA (full-body clips on a Base track, tag_ads ADS
clips above them, true additive clips in Combine mode), lines the mounted sight up with the eye at full ADS and
adds a procedural recoil kick to fire clips; Viewmodel Camera puts the camera on the eye bone. Weapon Clips finds
the gun's animations in the export and adds a move with the clips it needs (e.g. ADS Fire = aim + ADS fire).
Third person: heads attach to their body on import, Assemble Selected puts a gun on a body's j_gun, and clips are
sorted into layers - stance / locomotion (legs) under upper-body actions, aim offsets and fire kicks stacked on
the Additive layers, and the export's facial_* clips on Face layers alongside the body. Import & Shade can merge what it imports into the
selected rig (heads, hair, gear, weapons), like the Cast importer's own Import Merge.
"""

bl_info = {
    "name": "CoD AutoShader",
    "author": "Simpy",
    "version": (1, 30, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > CoD, Shader Editor > Sidebar > CoD",
    "description": "Auto-shades Call of Duty Saluki/Cast exports (CS/NOG decoding)",
    "category": "Material",
}

import glob
import math
import os
import re

import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty,
                       StringProperty)
from bpy_extras.io_utils import ImportHelper

GROUP_NAME = "CoD Surface Decode"
GROUP_VERSION = 5
SSS_NODE_NAME = "CoD SSS Scale"

SEM_CS = 0x47
SEM_NOG = 0x48
SEM_EMISSIVE = 0x49
SEM_OPACITY = 0x4A
SEM_STRAND = 0x4D           # hair techsets: per-strand random / depth value
SEM_PARAMS = 0x4E           # techset-specific; skin-tone color on skin (hair: flat per-card color, unused)
SEM_SKIN_MARKERS = (0x54, 0x0B, 0x0C)   # skin scattering LUT, wrinkle color / wrinkle NOG

# gloss curve: alpha = sqrt(2 / (bias + 2^(exponent * gloss)))
GLOSS_CURVES = {
    'WWII': (18.0, 1.0),    # Call of Duty: WWII (2018)
    'AW': (16.0, 2.0),      # Call of Duty: Advanced Warfare (2015)
}

SKIN_F0 = 0.028
# Red travels far under skin, green and blue barely at all. The old ratios came from Jimenez's screen-space
# blur kernel, which is far wider in green/blue than the medium itself - in a path tracer that reads as a
# uniform pink glow through ears and nostrils. These are the per-channel mean free paths of dermis.
SKIN_SSS_RADIUS = (1.0, 0.22, 0.12)
SKIN_SSS_ANISOTROPY = 0.8            # skin scatters strongly forward, so light does not spread sideways
SKIN_DIFFUSE_ROUGHNESS = 0.35        # Oren-Nayar: skin is microscopically rough, which softens the terminator
SKIN_OIL_NODE_NAME = "CoD Skin Oil"
SKIN_OIL_IOR = 1.47                  # sebum: skin's own film sits near fat/oil, not water
SKIN_OIL_ROUGHNESS = (0.42, 0.14)    # film roughness where the gloss map reads dry, and where it reads shiny

# BO7 eye textures share one layout: iris centered at (0.5, 0.5), limbal ring at r ~0.19,
# sclera from r ~0.22 (measured over the exported eye materials)
HAIR_NODE_NAME = "CoD Hair"
HAIR_GROUP_VERSION = 3
HAIR_TRANSPARENT_BOUNCES = 64
HAIR_TINT_GAMMA = 1.4
HAIR_FRESNEL_NORM = 4.0      # brings Fresnel x |N.V| (peaks near 0.25) back to a 0..1 range for "Shine"        # TT/TRT color = (albedo / its brightest channel) ^ gamma: same hue, deeper

EYE_NODE_NAME = "CoD Eye Parallax"
EYE_SHADOW_NODE_NAME = "CoD Eye Shadow"
EYE_GROUP_VERSION = 3
EYE_IRIS_RADIUS = 0.21
EYE_IRIS_DEPTH = 0.06        # cornea apex over the iris plane (~0.4 cm) / 1.376 refraction, in eye UV units
EYE_TILT_MAX = 0.785         # cornea normal tilt model fitted to the BO7 eye mesh
EYE_TILT_FALLOFF = 0.11
EYE_CORNEA_IOR = 1.376
EYE_COAT_ROUGHNESS = 0.02

# Position of the NOG slot in the list of non-albedo semantics (ascending semantic order) for the
# common techset layout 3,4,5,a,12,3f,40,41,42,[47],48. Eye / face techsets add 0x0, 0xb, 0xc
# in front, shifting it by up to two.
NOG_POSITIONS = (9, 10, 11)

# MWII-era techset slot indices (hash column of those exports). Verified by matching MWII's unhashed image
# names against BO7 textures: 0x0 '_c&_s' (CS), 0x4 '_n&_o&_g' (NOG), 0xC '_alpha', 0x26 '_scatter&_m'
# (skin: scatter color + thickness), 0x1D thermal, 0x1B infrared.
MW2_SLOTS = {"cs": 0x0, "nog": 0x4, "emissive": 0x8, "opacity": 0xC, "params": 0x26}   # 0x8: '_e' textures
BO7_SLOTS = {"cs": SEM_CS, "nog": SEM_NOG, "emissive": SEM_EMISSIVE, "opacity": SEM_OPACITY,
             "strand": SEM_STRAND, "params": SEM_PARAMS}
SLOT_ROLES = ("cs", "nog", "emissive", "opacity", "strand", "params")

# Games with IW-style packed CS / NOG textures: (id, button label, full name, gloss curve, verified here)
GAMES = (
    ('BO7', "Black Ops 7", "Call of Duty: Black Ops 7 (2025)", 'WWII', True),
    ('BO6', "Black Ops 6", "Call of Duty: Black Ops 6 (2024)", 'WWII', False),
    ('MW4', "MW4 (2026)", "Call of Duty: Modern Warfare 4 (2026)", 'WWII', True),
    ('MW3', "MW III", "Call of Duty: Modern Warfare III (2023)", 'WWII', False),
    ('MW2', "MW II", "Call of Duty: Modern Warfare II / Warzone (2022)", 'WWII', True),
    ('VG', "Vanguard", "Call of Duty: Vanguard (2021)", 'WWII', False),
    ('CW', "Cold War", "Call of Duty: Black Ops Cold War (2020)", 'WWII', False),
    ('MW19', "MW (2019)", "Call of Duty: Modern Warfare (2019)", 'WWII', False),
    ('WW2', "WWII", "Call of Duty: WWII (2017)", 'WWII', False),
    ('IW', "Inf. Warfare", "Call of Duty: Infinite Warfare (2016)", 'AW', False),
)
GAME_CURVE = {g[0]: g[3] for g in GAMES}


# --------------------------------------------------------------------------------------------
# _mat_info parsing
# --------------------------------------------------------------------------------------------

class MatInfo:
    def __init__(self, name, techset, model_dir):
        self.name = name
        self.techset = techset
        self.model_dir = model_dir
        self.image_names = []   # texture names that are not hashes: they still carry the asset's real name
        self.by_semantic = {}   # semantic id -> image path (older Saluki: unk_semantic_XX)
        self.by_slot = {}       # MWII-era exports: techset slot index (hash column 0x0, 0x4, ...) -> path
        self.albedo = None      # newer Saluki: "Albedo" row
        self.extras = []        # newer Saluki: "Unknown" rows in slot order

    def image(self, semantic):
        return self.by_semantic.get(semantic)


def _norm_name(name):
    name = re.sub(r"\.\d{3}$", "", name)
    return name.replace("/", "_").replace("\\", "_").lower()


def _is_placeholder(path):
    return path is None or os.path.basename(path).startswith("$")


class ModelIndex:
    """All _mat_info entries under one or more model folders, keyed by normalized material name."""

    def __init__(self):
        self.by_name = {}
        self.by_albedo = {}
        self._dirs = set()

    def add_model_dir(self, model_dir):
        model_dir = os.path.normpath(model_dir)
        if model_dir in self._dirs:
            return
        self._dirs.add(model_dir)

        files = {}
        for p in glob.glob(os.path.join(model_dir, "_images", "**", "*.*"), recursive=True):
            files.setdefault(os.path.splitext(os.path.basename(p))[0].lower(), []).append(p)

        for txt in glob.glob(os.path.join(model_dir, "_mat_info", "*.txt")):
            info = _parse_mat_info(txt, model_dir, files)
            if info is None:
                continue
            self.by_name.setdefault(_norm_name(info.name), info)
            albedo = info.image(SEM_CS) or info.albedo
            if albedo:
                self.by_albedo.setdefault(os.path.basename(albedo).lower(), info)

    def add_root(self, root):
        for mat_info_dir in glob.glob(os.path.join(root, "**", "_mat_info"), recursive=True):
            self.add_model_dir(os.path.dirname(mat_info_dir))


def _resolve(files, image_name, mat_name):
    cands = files.get(image_name.lower())
    if not cands:
        return None
    sub = mat_name.replace("/", os.sep).lower()
    for c in cands:
        if sub in c.lower():
            return c
    return cands[0]


def _parse_mat_info(txt, model_dir, files):
    try:
        lines = open(txt, encoding="utf-8", errors="replace").read().splitlines()
    except OSError:
        return None
    name = os.path.splitext(os.path.basename(txt))[0]
    techset = ""
    header = None
    for i, line in enumerate(lines):
        if line.startswith("Name:"):
            name = line.split(":", 1)[1].strip()
        elif line.startswith("Techset:"):
            techset = line.split(":", 1)[1].strip()
        elif line.startswith("semantic,"):
            header = i
            break
    if header is None:
        return None

    info = MatInfo(name, techset, model_dir)
    hashed = []
    for line in lines[header + 1:]:
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 2 or not parts[0]:
            continue
        semantic, image = parts[0], parts[1]
        readable = re.sub(r"~\d+$", "", os.path.splitext(os.path.basename(image))[0])
        if not readable.startswith("$") and not re.fullmatch(r"image_[0-9a-f]+", readable):
            for piece in readable.split("&"):
                if piece and piece not in info.image_names:
                    info.image_names.append(piece)
        m = re.match(r"unk_semantic_([0-9a-fA-F]+)$", semantic)
        if m:
            # older format: semantic id + bare image name
            path = None if image.startswith("$") else _resolve(files, image, name)
            info.by_semantic[int(m.group(1), 16)] = path
        else:
            # newer format: semantic label + relative path; unlabeled slots are positional
            path = os.path.normpath(os.path.join(model_dir, image))
            if not os.path.exists(path):
                path = _resolve(files, os.path.splitext(os.path.basename(image))[0], name) or path
            if _is_placeholder(path):
                path = None
            if semantic.lower() == "albedo":
                info.albedo = path
            else:
                info.extras.append(path)
            try:
                hashed.append((int(parts[2], 16), path))
            except (IndexError, ValueError):
                pass
    # MWII-era exports put the techset slot index in the hash column (0x0, 0x4, 0x26 ...); later ones put a
    # 64-bit image hash there. Small values everywhere means slot indices.
    if hashed and all(h < 0x1000 for h, _ in hashed):
        info.by_slot = {h: p for h, p in hashed}
    return info


# --------------------------------------------------------------------------------------------
# Image helpers
# --------------------------------------------------------------------------------------------

_sample_cache = {}


def _set_colorspace(img, data):
    names = ("Non-Color", "Data", "Raw") if data else ("sRGB", "sRGB 2.1")
    for n in names:
        try:
            img.colorspace_settings.name = n
            return
        except TypeError:
            continue


def load_image(path, data, packed):
    img = bpy.data.images.load(path, check_existing=True)
    _set_colorspace(img, data)
    img.alpha_mode = 'CHANNEL_PACKED' if packed else 'STRAIGHT'
    return img


def _sample(path, size=64):
    """(RGBA float sample of an image file with raw values, original (w, h)), cached per path."""
    if path in _sample_cache:
        return _sample_cache[path]
    result = (None, (0, 0))
    try:
        tmp = bpy.data.images.load(path, check_existing=False)
        try:
            _set_colorspace(tmp, True)
            tmp.alpha_mode = 'CHANNEL_PACKED'
            dims = tuple(tmp.size)
            tmp.scale(size, size)
            buf = np.empty(size * size * 4, dtype=np.float32)
            tmp.pixels.foreach_get(buf)
            result = (buf.reshape(-1, 4), dims)
        finally:
            bpy.data.images.remove(tmp)
    except Exception:
        pass
    _sample_cache[path] = result
    return result


def sample_rgba(path):
    return _sample(path)[0]


def is_constant_white(path):
    """Placeholder opacity maps (e.g. a 4x4 white image) mean fully opaque."""
    px = sample_rgba(path)
    return px is not None and float(px[:, :3].min()) > 0.99


def is_lut(path):
    """Skin scattering LUT: a thin strip like 1024x8."""
    if _is_placeholder(path):
        return False
    w, h = _sample(path)[1]
    return h > 0 and w >= 256 and w // h >= 32


def is_skin_tone(path):
    if _is_placeholder(path):
        return False
    px = sample_rgba(path)
    if px is None:
        return False
    r, g, b = px[:, :3].mean(0)
    return r > 0.3 and r > g > b > 0.05 and r - b > 0.15


def is_scatter_map(path):
    """The subsurface tint map of a skin shader: red dominant, and an actual texture rather than a flat flag
    colour (gear materials keep pure red or grey constants in the same slot)."""
    if _is_placeholder(path):
        return False
    px = sample_rgba(path)
    if px is None:
        return False
    r, g, b = (float(x) for x in px[:, :3].mean(0))
    return r > 0.12 and r > g > b and r - b > 0.12


def looks_like_nog(path):
    if _is_placeholder(path):
        return False
    px = sample_rgba(path)
    if px is None:
        return False
    mean = px.mean(0)
    return mean[2] > 0.55 and abs(mean[1] - 0.5) < 0.15 and abs(mean[3] - 0.5) < 0.15


def emissive_gain(path, target=1.0, limit=25.0):
    """How much to scale an emissive map so its brightest pixel reaches full brightness. The game's maps are
    stored dim (the BO7 watch screen peaks at 0.43 sRGB, i.e. 0.16 linear) and the engine scales them up."""
    px = sample_rgba(path)
    if px is None:
        return 1.0
    peak = float(px[:, :3].max()) ** 2.2          # sample_rgba reads raw values; emissive maps are sRGB
    if peak < 1e-4:
        return 1.0
    return float(min(max(target / peak, 1.0), limit))


def alpha_is_metal_mask(path):
    """A real metalness mask is bimodal: insulator values <= ~0.1 and metal near 1.0.
    Constant alpha (unused, BO7 stores 1.0) or mostly mid-range values (other techset data,
    e.g. leather sleeves around 0.77) are not metal."""
    px = sample_rgba(path)
    if px is None:
        return False
    a = px[:, 3]
    if float(a.std()) < 0.01:
        return False
    mid = float(((a > 0.12) & (a < 0.88)).mean())
    return mid < 0.3


# --------------------------------------------------------------------------------------------
# Slot resolution
# --------------------------------------------------------------------------------------------

def resolve_slots(info):
    """Returns dict role -> image path for cs / nog / emissive / opacity / params, plus skin markers."""
    markers = []
    sem = info.by_semantic
    if sem and (SEM_CS in sem or SEM_NOG in sem):
        # BO7 / BO6 / MW4 numbering (0x47 CS, 0x48 NOG, ...)
        slots = {role: sem.get(BO7_SLOTS[role]) if role in BO7_SLOTS else None for role in SLOT_ROLES}
        markers = [sem.get(s) for s in SEM_SKIN_MARKERS]
    elif sem or info.by_slot:
        # MWII-era numbering, in either export format (unk_semantic_0 ... or a slot-index hash column).
        # Verified from MWII's unhashed names: '_c&_s' 0x0, '_n&_o&_g' 0x4, '_e' 0x8, '_alpha' 0xC, scatter 0x26
        mapping = sem or info.by_slot
        slots = {role: mapping.get(MW2_SLOTS[role]) if role in MW2_SLOTS else None for role in SLOT_ROLES}
        slots["cs"] = slots["cs"] or info.albedo
        if not looks_like_nog(slots["nog"]):
            slots["nog"] = next((p for p in list(mapping.values()) + info.extras if looks_like_nog(p)), None)
        markers = [p for p in mapping.values() if p and is_lut(p)][:1]
    else:
        slots = {"cs": info.albedo, "nog": None, "emissive": None, "opacity": None, "strand": None, "params": None}
        extras = info.extras
        for idx in NOG_POSITIONS:
            if idx < len(extras) and looks_like_nog(extras[idx]):
                slots["nog"] = extras[idx]
                for role, offset in (("emissive", SEM_EMISSIVE), ("opacity", SEM_OPACITY),
                                     ("strand", SEM_STRAND), ("params", SEM_PARAMS)):
                    j = idx + offset - SEM_NOG
                    if j < len(extras):
                        slots[role] = extras[j]
                # skin LUT / wrinkle maps sit before or after the core slots; look for the LUT strip
                markers = [p for p in extras if is_lut(p)][:1]
                break
        else:
            # unknown layout: still find the normal map by its pixel signature
            slots["nog"] = next((p for p in extras if looks_like_nog(p)), None)
    slots = {k: (None if _is_placeholder(v) or not os.path.exists(v) else v) for k, v in slots.items()}
    slots["skin_marker"] = any(m and not _is_placeholder(m) for m in markers)
    return slots


def classify(mat_name, slots, hints=()):
    """'EYE', 'TEARFILM', 'SKIN', 'HAIR' or 'DEFAULT'. Only DEFAULT reads CS alpha as metalness.
    MW4 (2026) exports hash every material name (material_381463ac...), but the textures often keep the asset's
    real name - an eye's infrared map is still called base_eye_infrared - so those are read as well."""
    by_name = _classify_name(mat_name, slots)
    if by_name is not None:
        return by_name
    for hint in hints:
        by_hint = _classify_name(hint, slots)
        if by_hint is not None:
            return by_hint
    if slots["skin_marker"]:
        return 'HAIR' if slots["opacity"] else 'SKIN'
    if not slots["opacity"] and is_skin_tone(slots["params"]):
        return 'SKIN'
    # MW4 faces and bare wrists carry no skin LUT, so read the shader's own maps: a skin-toned colour map
    # together with a red subsurface tint map is skin and nothing else (checked against every export here)
    if not slots["opacity"] and is_skin_tone(slots["cs"]) and is_scatter_map(slots["params"]):
        return 'SKIN'
    return 'DEFAULT'


def _classify_name(mat_name, slots):
    """The kind a name implies, or None when the name says nothing."""
    name = re.sub(r"\.\d{3}$", "", mat_name).lower()
    if "lacrimal" in name or "wetness" in name:      # BO7 lacrimal fluid, MWII eye_wetness
        return 'TEARFILM'
    if re.search(r"(^|_)eyes?($|_)", name) and not re.search(r"lash|brow", name):
        return 'EYE'
    # named hair first: MWII hair techsets carry no skin LUT, and solid hair meshes (braids) do carry one
    if re.search(r"hair|braid|beard|mustache|moustache|brow|lash", name):
        return 'HAIR' if (slots["opacity"] and "lash" not in name) else 'DEFAULT'
    return None


# --------------------------------------------------------------------------------------------
# Decode node group
# --------------------------------------------------------------------------------------------

class _Builder:
    def __init__(self, tree):
        self.tree = tree
        self.nodes = tree.nodes
        self.links = tree.links

    def _feed(self, sock, value):
        if value is None:
            return
        if isinstance(value, bpy.types.NodeSocket):
            self.links.new(value, sock)
        else:
            sock.default_value = value

    def math(self, op, a, b=None, c=None, clamp=False, loc=(0, 0)):
        n = self.nodes.new("ShaderNodeMath")
        n.operation = op
        n.use_clamp = clamp
        n.location = loc
        for i, v in enumerate((a, b, c)):
            self._feed(n.inputs[i], v)
        return n.outputs[0]

    def vmath(self, op, a, b=None, c=None, scale=None, loc=(0, 0)):
        n = self.nodes.new("ShaderNodeVectorMath")
        n.operation = op
        n.location = loc
        for i, v in enumerate((a, b, c)):
            self._feed(n.inputs[i], v)
        if scale is not None:
            self._feed(n.inputs[3], scale)
        return n.outputs[0]


def _socket(iface, name, in_out, stype, default=None, lo=None, hi=None, desc="", parent=None):
    s = iface.new_socket(name=name, in_out=in_out, socket_type=stype, description=desc, parent=parent)
    if default is not None and hasattr(s, "default_value"):
        s.default_value = default
    if lo is not None and hasattr(s, "min_value"):
        s.min_value = lo
    if hi is not None and hasattr(s, "max_value"):
        s.max_value = hi
    return s


def get_decode_group():
    # versioned name: materials built by an older version keep their own group until reshaded
    name = "%s v%d" % (GROUP_NAME, GROUP_VERSION)
    ng = bpy.data.node_groups.get(name)
    if ng is not None and ng.get("cod_version") == GROUP_VERSION:
        return ng
    ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    ng["cod_version"] = GROUP_VERSION

    iface = ng.interface
    I, O = "INPUT", "OUTPUT"
    # outputs first: sockets must come before panels at the same level
    for name, stype in (("Base Color", "NodeSocketColor"), ("Metallic", "NodeSocketFloat"),
                        ("Roughness", "NodeSocketFloat"), ("IOR", "NodeSocketFloat"), ("Normal", "NodeSocketVector"),
                        ("Alpha", "NodeSocketFloat"), ("Emission Color", "NodeSocketColor"),
                        ("Emission Strength", "NodeSocketFloat")):
        _socket(iface, name, O, stype)

    maps = iface.new_panel("Maps", description="texture maps from the Saluki export")
    _socket(iface, "CS Color", I, "NodeSocketColor", (0.5, 0.5, 0.5, 1.0), desc="packed CS RGB (sRGB image)", parent=maps)
    _socket(iface, "CS Alpha", I, "NodeSocketFloat", 0.0, 0.0, 1.0, "packed CS alpha: metalness mask", parent=maps)
    _socket(iface, "NOG Color", I, "NodeSocketColor", (0.0, 0.5, 1.0, 1.0), desc="packed NOG RGB (Non-Color)", parent=maps)
    _socket(iface, "NOG Alpha", I, "NodeSocketFloat", 0.5, 0.0, 1.0, "packed NOG alpha: normal Y", parent=maps)
    _socket(iface, "Opacity", I, "NodeSocketFloat", 1.0, 0.0, 1.0, parent=maps)
    _socket(iface, "Emissive", I, "NodeSocketColor", (0.0, 0.0, 0.0, 1.0), parent=maps)

    adjust = iface.new_panel("Adjust", description="safe to tweak")
    _socket(iface, "Normal Strength", I, "NodeSocketFloat", 1.0, 0.0, 4.0, "bumpiness of the normal map", parent=adjust)
    _socket(iface, "AO Strength", I, "NodeSocketFloat", 1.0, 0.0, 1.0, "baked ambient occlusion darkening", parent=adjust)
    _socket(iface, "Roughness Min", I, "NodeSocketFloat", 0.0, 0.0, 1.0,
            "raise to make the surface less shiny (roughness = min + (max - min) * r)", parent=adjust)
    _socket(iface, "Roughness Max", I, "NodeSocketFloat", 1.0, 0.0, 1.0, "lower to make rough areas shinier", parent=adjust)
    _socket(iface, "Emission Strength", I, "NodeSocketFloat", 1.0, 0.0, 100.0, "glow of emissive parts", parent=adjust)
    _socket(iface, "Emission Color", I, "NodeSocketColor", (1.0, 1.0, 1.0, 1.0),
            desc="tints the glow; white keeps the colour the game's emissive map has", parent=adjust)

    adv = iface.new_panel("Advanced (CoD decode)", description="how the game textures are decoded", default_closed=True)
    _socket(iface, "Metal Mask", I, "NodeSocketFloat", 1.0, 0.0, 1.0,
            "1 = CS alpha is an IW metalness mask, 0 = alpha unused (plain dielectric)", parent=adv)
    _socket(iface, "Insulator Range", I, "NodeSocketFloat", 0.1, 0.0, 0.5,
            "IW INSULATOR_SPEC_RANGE: alpha below this is dielectric F0, above is metal", parent=adv)
    _socket(iface, "Dielectric F0", I, "NodeSocketFloat", 0.04, 0.0, 0.2, "F0 used when the metal mask is unused", parent=adv)
    _socket(iface, "F0 Floor", I, "NodeSocketFloat", 0.02, 0.0, 0.2, "minimum dielectric reflectance", parent=adv)
    _socket(iface, "Emission Gain", I, "NodeSocketFloat", 1.0, 0.0, 100.0,
            "measured from the emissive map: lifts its brightest pixel to full brightness", parent=adv)
    _socket(iface, "CoD Gloss Curve", I, "NodeSocketFloat", 1.0, 0.0, 1.0,
            "0 = roughness = 1 - gloss, 1 = CoD gloss curve", parent=adv)
    _socket(iface, "Gloss Exponent", I, "NodeSocketFloat", 18.0, 1.0, 24.0,
            "alpha = sqrt(2 / (bias + 2^(exponent * gloss))); WWII = 18, Advanced Warfare = 16", parent=adv)
    _socket(iface, "Gloss Bias", I, "NodeSocketFloat", 1.0, 0.0, 4.0, "WWII = 1, Advanced Warfare = 2", parent=adv)

    extra = iface.new_panel("Extra Outputs", default_closed=True)
    _socket(iface, "Occlusion", O, "NodeSocketFloat", parent=extra)
    _socket(iface, "Gloss", O, "NodeSocketFloat", parent=extra)

    b = _Builder(ng)
    gi = ng.nodes.new("NodeGroupInput")
    gi.location = (-1400, 0)
    go = ng.nodes.new("NodeGroupOutput")
    go.location = (900, 0)
    inp = gi.outputs

    sep = ng.nodes.new("ShaderNodeSeparateColor")
    sep.location = (-1150, -300)
    ng.links.new(inp["NOG Color"], sep.inputs[0])
    gloss, nog_x, occl = sep.outputs[0], sep.outputs[1], sep.outputs[2]
    nog_y = inp["NOG Alpha"]

    # --- metalness / F0 (IW DeriveAlbedoAndSpec, slide 111-112)
    a = inp["CS Alpha"]
    rng = inp["Insulator Range"]
    m = b.math("DIVIDE", b.math("SUBTRACT", a, rng, loc=(-1000, 400)),
               b.math("SUBTRACT", 1.0, rng, loc=(-1000, 300)), clamp=True, loc=(-850, 400))
    metallic = b.math("MULTIPLY", m, inp["Metal Mask"], loc=(-700, 400))
    r0_iw = b.math("MINIMUM", a, rng, loc=(-1000, 200))
    r0 = b.math("MULTIPLY_ADD", b.math("SUBTRACT", r0_iw, inp["Dielectric F0"], loc=(-850, 200)),
                inp["Metal Mask"], inp["Dielectric F0"], loc=(-700, 200))
    r0 = b.math("MAXIMUM", r0, inp["F0 Floor"], loc=(-550, 200))
    s = b.math("MINIMUM", b.math("SQRT", r0, loc=(-400, 200)), 0.95, loc=(-250, 200))
    ior = b.math("DIVIDE", b.math("ADD", 1.0, s, loc=(-100, 250)),
                 b.math("SUBTRACT", 1.0, s, loc=(-100, 150)), loc=(50, 200))

    # --- base color with occlusion
    ao = b.math("MULTIPLY_ADD", b.math("SUBTRACT", occl, 1.0, loc=(-850, 0)),
                inp["AO Strength"], 1.0, loc=(-700, 0))
    base = b.vmath("SCALE", inp["CS Color"], scale=ao, loc=(-400, 550))

    # --- roughness from gloss: alpha = sqrt(2 / (bias + 2^(exp*g))), Blender roughness = sqrt(alpha)
    power = b.math("POWER", 2.0, b.math("MULTIPLY", gloss, inp["Gloss Exponent"], loc=(-850, -150)), loc=(-700, -150))
    r_cod = b.math("POWER", b.math("DIVIDE", 2.0, b.math("ADD", power, inp["Gloss Bias"], loc=(-550, -150)),
                                   loc=(-400, -150)), 0.25, loc=(-250, -150))
    r_lin = b.math("SUBTRACT", 1.0, gloss, loc=(-400, -250))
    rough = b.math("MULTIPLY_ADD", b.math("SUBTRACT", r_cod, r_lin, loc=(-100, -200)),
                   inp["CoD Gloss Curve"], r_lin, clamp=True, loc=(50, -200))
    rough = b.math("MULTIPLY_ADD", rough,
                   b.math("SUBTRACT", inp["Roughness Max"], inp["Roughness Min"], loc=(50, -300)),
                   inp["Roughness Min"], clamp=True, loc=(200, -200))

    # --- hemi-octahedron normal, DirectX Y -> Blender (OpenGL) tangent space
    ex = b.math("MULTIPLY_ADD", nog_x, 2.0, -1.0, loc=(-850, -450))
    ey = b.math("MULTIPLY_ADD", nog_y, 2.0, -1.0, loc=(-850, -550))
    tx = b.math("MULTIPLY", b.math("ADD", ex, ey, loc=(-700, -450)), 0.5, loc=(-550, -450))
    ty = b.math("MULTIPLY", b.math("SUBTRACT", ey, ex, loc=(-700, -550)), 0.5, loc=(-550, -550))
    tz = b.math("SUBTRACT", b.math("SUBTRACT", 1.0, b.math("ABSOLUTE", tx, loc=(-400, -650)), loc=(-250, -650)),
                b.math("ABSOLUTE", ty, loc=(-400, -750)), loc=(-100, -650))
    comb = ng.nodes.new("ShaderNodeCombineXYZ")
    comb.location = (50, -500)
    ng.links.new(b.math("MULTIPLY", tx, inp["Normal Strength"], loc=(-250, -450)), comb.inputs[0])
    ng.links.new(b.math("MULTIPLY", ty, inp["Normal Strength"], loc=(-250, -550)), comb.inputs[1])
    ng.links.new(tz, comb.inputs[2])
    n = b.vmath("NORMALIZE", comb.outputs[0], loc=(200, -500))
    ncol = b.vmath("MULTIPLY_ADD", n, (0.5, 0.5, 0.5), (0.5, 0.5, 0.5), loc=(350, -500))
    nmap = ng.nodes.new("ShaderNodeNormalMap")
    nmap.space = 'TANGENT'
    nmap.location = (550, -500)
    ng.links.new(ncol, nmap.inputs["Color"])

    out = go.inputs
    ng.links.new(base, out["Base Color"])
    ng.links.new(metallic, out["Metallic"])
    ng.links.new(rough, out["Roughness"])
    ng.links.new(ior, out["IOR"])
    ng.links.new(nmap.outputs["Normal"], out["Normal"])
    ng.links.new(inp["Opacity"], out["Alpha"])
    # CoD emissive maps are stored dim (a watch screen peaks around 0.4) and the engine scales them up, so the
    # material's own gain lifts the brightest pixel to full before the user's strength and tint
    tint = ng.nodes.new("ShaderNodeMix")
    tint.data_type = 'RGBA'
    tint.blend_type = 'MULTIPLY'
    tint.inputs[0].default_value = 1.0
    tint.location = (1500, -700)
    ng.links.new(inp["Emissive"], tint.inputs[6])
    ng.links.new(inp["Emission Color"], tint.inputs[7])
    ng.links.new(tint.outputs[2], out["Emission Color"])
    glow = b.math("MULTIPLY", inp["Emission Strength"], inp["Emission Gain"], loc=(1500, -850))
    ng.links.new(glow, out["Emission Strength"])
    ng.links.new(occl, out["Occlusion"])
    ng.links.new(gloss, out["Gloss"])
    return ng


# --------------------------------------------------------------------------------------------
# Material building
# --------------------------------------------------------------------------------------------

def _principled_input(bsdf, *names):
    for n in names:
        s = bsdf.inputs.get(n)
        if s is not None:
            return s
    return None


def _sss_scale_nodes(nt, base_cm):
    """Subsurface scale that follows the object's world scale: base value is in Cast import units
    (centimeters), multiplied by the length of an object->world transformed unit vector, so a rig
    scaled to 0.01 (meters) gets 0.01x the distance."""
    vt = nt.nodes.new("ShaderNodeVectorTransform")
    vt.vector_type = 'VECTOR'
    vt.convert_from = 'OBJECT'
    vt.convert_to = 'WORLD'
    vt.inputs[0].default_value = (0.57735, 0.57735, 0.57735)
    vt.label = "Object Scale"
    length = nt.nodes.new("ShaderNodeVectorMath")
    length.operation = 'LENGTH'
    length.label = "Scale Factor"
    nt.links.new(vt.outputs[0], length.inputs[0])
    mul = nt.nodes.new("ShaderNodeMath")
    mul.operation = 'MULTIPLY'
    mul.name = SSS_NODE_NAME
    mul.label = "SSS Scale (cm)"
    nt.links.new(length.outputs["Value"], mul.inputs[0])
    mul.inputs[1].default_value = base_cm
    return mul.outputs[0], [vt, length, mul]


def get_eye_parallax_group():
    """Iris parallax like CoD's eye shader, done in the eye's forward frame.

    BO7 eye meshes model the cornea bulge, so the surface normal tilts away from the pupil with UV
    radius (measured: 13.6 deg at r=0.05 ... 37.6 deg at the limbus, r=0.19). Parallax along the
    local normal would shrink the iris, so the forward axis F is rebuilt per pixel by undoing that
    tilt (theta(r) = tilt_max * (1 - exp(-r / falloff))), and the view vector is measured in F's
    frame:   uv' = uv - V_F.xy / V_F.z * depth * (1 - (r / R_iris)^2)"""
    name = "CoD Eye Parallax v%d" % EYE_GROUP_VERSION
    ng = bpy.data.node_groups.get(name)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    iface = ng.interface
    _socket(iface, "UV", "OUTPUT", "NodeSocketVector")
    _socket(iface, "Iris Mask", "OUTPUT", "NodeSocketFloat")
    _socket(iface, "Iris Depth", "INPUT", "NodeSocketFloat", EYE_IRIS_DEPTH, 0.0, 0.3,
            "how deep the iris sits under the cornea (0 = painted on)")
    _socket(iface, "Iris Radius", "INPUT", "NodeSocketFloat", EYE_IRIS_RADIUS, 0.0, 0.5, "size of the iris in the eye texture")
    adv = iface.new_panel("Advanced", default_closed=True)
    _socket(iface, "Iris Center", "INPUT", "NodeSocketVector", (0.5, 0.5, 0.0), parent=adv)
    _socket(iface, "Tilt Max", "INPUT", "NodeSocketFloat", EYE_TILT_MAX, 0.0, 1.5,
            "cornea normal tilt model (radians)", parent=adv)
    _socket(iface, "Tilt Falloff", "INPUT", "NodeSocketFloat", EYE_TILT_FALLOFF, 0.01, 1.0, parent=adv)

    b = _Builder(ng)
    nodes, link = ng.nodes, ng.links.new
    gi = nodes.new("NodeGroupInput")
    gi.location = (-1400, 0)
    go = nodes.new("NodeGroupOutput")
    go.location = (1100, 0)
    inp = gi.outputs

    tc = nodes.new("ShaderNodeTexCoord")
    tc.location = (-1400, 300)
    uv = tc.outputs["UV"]
    geo = nodes.new("ShaderNodeNewGeometry")
    geo.location = (-1400, -400)
    tan = nodes.new("ShaderNodeTangent")
    tan.direction_type = 'UV_MAP'
    tan.location = (-1400, -650)
    I, N, T = geo.outputs["Incoming"], geo.outputs["Normal"], tan.outputs["Tangent"]
    B = b.vmath("CROSS_PRODUCT", N, T, loc=(-1150, -650))

    def dot(a, c, loc):
        n = nodes.new("ShaderNodeVectorMath")
        n.operation = 'DOT_PRODUCT'
        n.location = loc
        link(a, n.inputs[0])
        link(c, n.inputs[1])
        return n.outputs["Value"]

    # radial UV offset and cornea height profile
    d = b.vmath("SUBTRACT", uv, inp["Iris Center"], loc=(-1150, 300))
    sep = nodes.new("ShaderNodeSeparateXYZ")
    sep.location = (-950, 300)
    link(d, sep.inputs[0])
    r = nodes.new("ShaderNodeVectorMath")
    r.operation = 'LENGTH'
    r.location = (-950, 150)
    link(d, r.inputs[0])
    r = r.outputs["Value"]
    rr = b.math("DIVIDE", r, inp["Iris Radius"], loc=(-750, 150))
    height = b.math("MAXIMUM", b.math("SUBTRACT", 1.0, b.math("MULTIPLY", rr, rr, loc=(-600, 150)), loc=(-450, 150)),
                    0.0, loc=(-300, 150))
    depth = b.math("MULTIPLY", height, inp["Iris Depth"], loc=(-150, 150))

    # forward axis F = cos(theta) N - sin(theta) R_hat, R_hat = outward radial direction on the surface
    r_hat = b.vmath("NORMALIZE", b.vmath("ADD", b.vmath("SCALE", T, scale=sep.outputs[0], loc=(-950, -150)),
                                          b.vmath("SCALE", B, scale=sep.outputs[1], loc=(-950, -300)),
                                          loc=(-750, -200)), loc=(-600, -200))
    theta = b.math("MULTIPLY", inp["Tilt Max"],
                   b.math("SUBTRACT", 1.0, b.math("EXPONENT", b.math("DIVIDE", b.math("MULTIPLY", r, -1.0, loc=(-750, 0)),
                                                                  inp["Tilt Falloff"], loc=(-600, 0)), loc=(-450, 0)),
                          loc=(-300, 0)), loc=(-150, 0))
    F = b.vmath("NORMALIZE", b.vmath("SUBTRACT",
                                     b.vmath("SCALE", N, scale=b.math("COSINE", theta, loc=(0, 50)), loc=(150, -100)),
                                     b.vmath("SCALE", r_hat, scale=b.math("SINE", theta, loc=(0, -50)), loc=(150, -250)),
                                     loc=(300, -150)), loc=(450, -150))

    # tangent frame orthogonal to F
    def ortho(v, loc):
        proj = b.vmath("SCALE", F, scale=dot(v, F, (loc[0], loc[1] + 80)), loc=(loc[0] + 150, loc[1]))
        return b.vmath("NORMALIZE", b.vmath("SUBTRACT", v, proj, loc=(loc[0] + 300, loc[1])), loc=(loc[0] + 450, loc[1]))

    TF = ortho(T, (0, -450))
    BF = ortho(B, (0, -650))
    vz = b.math("MAXIMUM", dot(I, F, (600, -300)), 0.2, loc=(750, -300))
    k = b.math("DIVIDE", depth, vz, loc=(750, -150))
    comb = nodes.new("ShaderNodeCombineXYZ")
    comb.location = (900, -300)
    link(b.math("MULTIPLY", dot(I, TF, (600, -450)), k, loc=(750, -450)), comb.inputs[0])
    link(b.math("MULTIPLY", dot(I, BF, (600, -650)), k, loc=(750, -650)), comb.inputs[1])
    link(b.vmath("SUBTRACT", uv, comb.outputs[0], loc=(950, 0)), go.inputs["UV"])
    link(b.math("CEIL", height, loc=(950, 150)), go.inputs["Iris Mask"])
    return ng


HAIR_PARAMS = (
    # name, default, min, max, description, node panel
    # Blender caps anisotropy at a 10:1 roughness ratio, so a fiber-like lobe (tight along the strand,
    # spread around it) needs a fairly high base roughness with anisotropy at 1: r 0.45 -> alpha ~0.06
    # along the strand and ~0.6 across it. Low roughness mirror-reflects the room on every card.
    ("Shine", 0.35, 0.0, 4.0, "white highlight on the strands (Marschner R lobe)", "Highlights"),
    ("Shine Softness", 0.45, 0.0, 1.0, "roughness of the white highlight (lower = sharper glints, more noise)",
     "Highlights"),
    ("Color Shine", 0.7, 0.0, 4.0, "hair-colored second highlight (TRT lobe)", "Highlights"),
    ("Color Shine Softness", 0.7, 0.0, 1.0, "roughness of the colored highlight", "Highlights"),
    ("Backlight", 0.9, 0.0, 2.0, "light shining through the hair from behind (TT lobe)", "Look"),
    ("Strand Variation", 0.45, 0.0, 1.0, "brightness variation between strands and clumps", "Look"),
    ("Shine Shift", 0.12, -1.0, 1.0, "moves the white highlight along the strand (+ toward root)", "Advanced"),
    ("Color Shine Shift", -0.18, -1.0, 1.0, "moves the colored highlight along the strand (- toward tip)", "Advanced"),
    ("Strand Stretch", 0.8, 0.0, 1.0, "anisotropy: how far highlights wrap around each strand", "Advanced"),
)


def get_hair_group():
    """Card hair shader after Marschner's hair model (R, TRT, TT lobes), as used by game hair shaders.
    Strands run along UV V (BO7 hair cards), so the UV tangent (U) is across the strands: anisotropic
    GGX stretched along it gives the horizontal highlight band. Each lobe tilts the shading normal
    along the strand to shift its highlight toward the root (R) or tip (TRT)."""
    name = "CoD Hair v%d" % HAIR_GROUP_VERSION
    ng = bpy.data.node_groups.get(name)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    iface = ng.interface
    _socket(iface, "Shader", "OUTPUT", "NodeSocketShader")
    panels = {name: iface.new_panel(name, default_closed=(name == "Advanced"))
              for name in ("Highlights", "Look", "Advanced")}
    for pname, default, lo, hi, desc, panel in HAIR_PARAMS:
        _socket(iface, pname, "INPUT", "NodeSocketFloat", default, lo, hi, desc, parent=panels[panel])
    maps = iface.new_panel("Maps", description="wired from the CoD Surface Decode node", default_closed=True)
    _socket(iface, "Color", "INPUT", "NodeSocketColor", (0.01, 0.008, 0.007, 1.0), desc="hair base color (linear)", parent=maps)
    _socket(iface, "Strand ID", "INPUT", "NodeSocketFloat", 0.2, 0.0, 1.0, "per-strand value (0x4d)", parent=maps)
    _socket(iface, "Occlusion", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0, parent=maps)
    _socket(iface, "Alpha", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0, parent=maps)
    n_sock = _socket(iface, "Normal", "INPUT", "NodeSocketVector", parent=maps)
    n_sock.hide_value = True

    b = _Builder(ng)
    nodes, link = ng.nodes, ng.links.new
    gi = nodes.new("NodeGroupInput")
    gi.location = (-1200, 0)
    go = nodes.new("NodeGroupOutput")
    go.location = (1300, 0)
    inp = gi.outputs

    tan = nodes.new("ShaderNodeTangent")
    tan.direction_type = 'UV_MAP'
    tan.location = (-1200, -500)
    across = tan.outputs["Tangent"]                                    # U: across the strands
    N_card = inp["Normal"]
    # cards are seen from both sides: face the shading normal toward the viewer, otherwise back-facing
    # cards get grazing-angle Fresnel (~100% reflection) and sparkle white
    geo = nodes.new("ShaderNodeNewGeometry")
    geo.location = (-1200, -750)
    facing = nodes.new("ShaderNodeVectorMath")
    facing.operation = 'DOT_PRODUCT'
    facing.location = (-1000, -750)
    link(N_card, facing.inputs[0])
    link(geo.outputs["Incoming"], facing.inputs[1])
    N = b.vmath("SCALE", N_card, scale=b.math("SIGN", facing.outputs["Value"], loc=(-850, -750)), loc=(-700, -750))
    head_on = b.math("ABSOLUTE", facing.outputs["Value"], loc=(-850, -900))   # 1 facing the camera, 0 edge-on
    edge_on = b.math("SUBTRACT", 1.0, head_on, loc=(-700, -900))

    # TT / TRT cross the fiber and are filtered by its pigment on the way, so they come out MORE saturated
    # than the albedo, not less - the amber you see through backlit hair. Brightening the albedo instead
    # (albedo x 4, clipped) pushed every brown into the same pale peach, which is what made card hair read
    # as ashy grey. Here the albedo is normalised to keep its hue, then gamma'd to deepen it.
    sep = nodes.new("ShaderNodeSeparateColor")
    sep.location = (-1000, 620)
    link(inp["Color"], sep.inputs[0])
    peak = b.math("MAXIMUM", b.math("MAXIMUM", sep.outputs[0], sep.outputs[1], loc=(-850, 700)),
                  b.math("MAXIMUM", sep.outputs[2], 1e-4, loc=(-850, 560)), loc=(-700, 640))
    hue = b.vmath("DIVIDE", inp["Color"], b.vmath("SCALE", (1.0, 1.0, 1.0), scale=peak, loc=(-550, 700)),
                  loc=(-400, 640))
    deepened = nodes.new("ShaderNodeGamma")
    deepened.location = (-250, 640)
    deepened.inputs["Gamma"].default_value = HAIR_TINT_GAMMA
    link(hue, deepened.inputs["Color"])
    # keep some of the albedo's own level, or black hair would transmit as brightly as blonde
    tint = b.vmath("SCALE", deepened.outputs[0], scale=b.math("SQRT", peak, loc=(-250, 520)), loc=(-100, 600))
    # strand direction from the card's own normal so root/tip stay put when the normal is flipped
    along = b.vmath("NORMALIZE", b.vmath("CROSS_PRODUCT", N_card, across, loc=(-1000, -500)), loc=(-850, -500))

    # per-strand variation: 0x4d spans ~0.05..0.35 in BO7 hair
    var = nodes.new("ShaderNodeMapRange")
    var.data_type = 'FLOAT'
    var.location = (-1000, 300)
    link(inp["Strand ID"], var.inputs[0])
    var.inputs[1].default_value = 0.05
    var.inputs[2].default_value = 0.35
    link(b.math("SUBTRACT", 1.0, inp["Strand Variation"], loc=(-1200, 350)), var.inputs[3])
    link(b.math("ADD", 1.0, inp["Strand Variation"], loc=(-1200, 250)), var.inputs[4])
    var = b.math("MULTIPLY", var.outputs[0], inp["Occlusion"], loc=(-800, 300))
    # Real hair reads in clumps: some locks catch more light than their neighbours. The game's per-strand
    # map only covers cards that have one, so a smooth object-space noise (~2 cm features, the width of a
    # lock) breaks up the flat "combed plastic" tone on every hairstyle.
    coord = nodes.new("ShaderNodeTexCoord")
    coord.location = (-1200, 150)
    clump_tex = nodes.new("ShaderNodeTexNoise")
    clump_tex.location = (-1000, 150)
    clump_tex.inputs["Scale"].default_value = 0.4
    clump_tex.inputs["Detail"].default_value = 2.0
    link(coord.outputs["Object"], clump_tex.inputs["Vector"])
    clump = b.math("ADD", 1.0, b.math("MULTIPLY", b.math("SUBTRACT", clump_tex.outputs["Fac"], 0.5, loc=(-800, 120)),
                                      inp["Strand Variation"], loc=(-650, 120)), loc=(-500, 150))
    var = b.math("MULTIPLY", var, clump, loc=(-350, 250))

    def shifted(shift, loc):
        return b.vmath("NORMALIZE", b.vmath("ADD", N, b.vmath("SCALE", along, scale=shift, loc=loc), loc=(loc[0] + 150, loc[1])),
                       loc=(loc[0] + 300, loc[1]))

    def glossy(color, rough, normal, loc):
        g = nodes.new("ShaderNodeBsdfGlossy")
        g.distribution = 'GGX'
        g.location = loc
        b._feed(g.inputs["Color"], color)
        link(rough, g.inputs["Roughness"])
        link(inp["Strand Stretch"], g.inputs["Anisotropy"])
        link(normal, g.inputs["Normal"])
        link(across, g.inputs["Tangent"])
        return g.outputs[0]

    def scaled(fac, shader, loc):
        m = nodes.new("ShaderNodeMixShader")
        m.location = loc
        link(fac, m.inputs[0])
        link(shader, m.inputs[2])      # first input left empty: output = fac * shader
        return m.outputs[0]

    # R: the white cuticle reflection. A fiber's Fresnel does climb to 1 at grazing - but there the fiber
    # is edge-on and covers almost no pixels. A card covers just as many pixels edge-on as face-on, so
    # Fresnel alone painted the whole silhouette white. Multiplying by |N.V| puts that foreshortening back:
    # the highlight band stays on the hair facing the camera and fades out along the outline.
    n_r = shifted(inp["Shine Shift"], (-700, -250))
    fres = nodes.new("ShaderNodeFresnel")
    fres.location = (-250, -150)
    fres.inputs["IOR"].default_value = 1.55
    link(n_r, fres.inputs["Normal"])
    lobe_shape = b.math("MULTIPLY", b.math("MULTIPLY", fres.outputs[0], head_on, loc=(-80, -150)),
                        HAIR_FRESNEL_NORM, loc=(60, -150))
    r_fac = b.math("MULTIPLY", b.math("MULTIPLY", inp["Shine"], lobe_shape, loc=(200, -120)), var, loc=(340, -120))
    r_lobe = scaled(r_fac, glossy((1.0, 1.0, 1.0, 1.0), inp["Shine Softness"], n_r, (100, -300)), (350, -200))

    # TRT: tinted, broader, shifted toward the tip
    n_trt = shifted(inp["Color Shine Shift"], (-700, -650))
    trt_fac = b.math("MULTIPLY", b.math("MULTIPLY", inp["Color Shine"], lobe_shape, loc=(100, -470)),
                     var, loc=(240, -470))
    trt_lobe = scaled(trt_fac, glossy(tint, inp["Color Shine Softness"], n_trt, (100, -650)), (350, -550))

    # body: dark diffuse + TT translucency in the tint color
    diff = nodes.new("ShaderNodeBsdfDiffuse")
    diff.location = (100, 350)
    link(b.vmath("SCALE", inp["Color"], scale=var, loc=(-200, 400)), diff.inputs["Color"])
    link(N, diff.inputs["Normal"])
    tt = nodes.new("ShaderNodeBsdfTranslucent")
    tt.location = (100, 150)
    link(b.vmath("SCALE", tint, scale=b.math("MULTIPLY", inp["Backlight"], edge_on, loc=(-350, 200)),
                 loc=(-200, 200)), tt.inputs["Color"])
    link(N, tt.inputs["Normal"])

    def add(a, c, loc):
        n = nodes.new("ShaderNodeAddShader")
        n.location = loc
        link(a, n.inputs[0])
        link(c, n.inputs[1])
        return n.outputs[0]

    surface = add(add(diff.outputs[0], tt.outputs[0], (350, 250)), add(r_lobe, trt_lobe, (550, -350)), (750, 0))
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.location = (750, 200)
    final = nodes.new("ShaderNodeMixShader")
    final.location = (1000, 0)
    link(inp["Alpha"], final.inputs[0])
    link(transparent.outputs[0], final.inputs[1])
    link(surface, final.inputs[2])
    link(final.outputs[0], go.inputs["Shader"])
    return ng


# node editor layout (columns, left to right)
X_EYE, X_TEX, X_DEC, X_SHADER, X_OUT = -1480, -1120, -760, -380, 20
Y_TOP = 300
TEX_STEP = 300
FRAME_COLORS = {
    "tex": (0.36, 0.26, 0.12), "decode": (0.12, 0.22, 0.36), "shader": (0.12, 0.30, 0.16),
    "helper": (0.26, 0.26, 0.26), "tip": (0.30, 0.30, 0.10),
}
DECODE_MAP_INPUTS = ("CS Color", "CS Alpha", "NOG Color", "NOG Alpha", "Opacity", "Emissive")


def _frame(nt, label, color, nodes_in):
    frame = nt.nodes.new("NodeFrame")
    frame.label = label
    frame.label_size = 16
    frame.use_custom_color = True
    frame.color = FRAME_COLORS[color]
    frame.location = (0, 0)          # children keep absolute coordinates
    for n in nodes_in:
        n.parent = frame
    return frame


def _hide_unused(node, inputs=True, outputs=True, only=None):
    """Hide unconnected sockets so beginners only see what is wired."""
    for group, enabled in ((node.inputs, inputs), (node.outputs, outputs)):
        if not enabled:
            continue
        for sock in group:
            if only is not None and sock.name not in only:
                continue
            if not sock.is_linked:
                sock.hide = True


def build_material(mat, slots, settings, metal_mode, hints=()):
    if hasattr(mat, "use_nodes") and not mat.use_nodes:
        mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    links = nt.links
    if slots["opacity"] and is_constant_white(slots["opacity"]):
        slots = dict(slots, opacity=None)
    kind = classify(mat.name, slots, hints)

    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    links.new(bsdf.outputs[0], out.inputs["Surface"])

    grp = nt.nodes.new("ShaderNodeGroup")
    grp.node_tree = get_decode_group()
    grp.label = "CoD Surface Decode"
    grp.width = 260
    gin = grp.inputs

    textures = []

    def tex(path, data, packed, label):
        node = nt.nodes.new("ShaderNodeTexImage")
        node.image = load_image(path, data, packed)
        node.label = label
        node.width = 240
        textures.append(node)
        return node

    helpers = {}
    parallax = None
    if kind == 'EYE' and settings.eye_parallax:
        parallax = nt.nodes.new("ShaderNodeGroup")
        parallax.node_tree = get_eye_parallax_group()
        parallax.name = EYE_NODE_NAME
        parallax.label = "Eye Iris Depth"
        parallax.width = 200
        helpers["Eye · iris depth under the cornea"] = [parallax]

    if slots["cs"]:
        cs = tex(slots["cs"], False, True, "Color + Metal  (CS)")
        links.new(cs.outputs["Color"], gin["CS Color"])
        links.new(cs.outputs["Alpha"], gin["CS Alpha"])
        if parallax:
            links.new(parallax.outputs["UV"], cs.inputs["Vector"])
    if slots["nog"]:
        nog = tex(slots["nog"], True, True, "Normal · Gloss · AO  (NOG)")
        links.new(nog.outputs["Color"], gin["NOG Color"])
        links.new(nog.outputs["Alpha"], gin["NOG Alpha"])
        if parallax:
            links.new(parallax.outputs["UV"], nog.inputs["Vector"])
    has_opacity = bool(slots["opacity"])
    if has_opacity:
        op = tex(slots["opacity"], True, False, "Opacity")
        opacity = op.outputs["Color"]
        if kind == 'TEARFILM' and "shadow" in mat.name.lower() and slots["params"]:
            # the eye "mid_shadow" shell darkens the eyeball near the lids with the broad ring in 0x4e
            # alpha; 0x4a only holds the thin wet line along the lid margin
            ring = tex(slots["params"], True, True, "Eye Shadow Ring  (0x4e)")
            strength = nt.nodes.new("ShaderNodeMath")
            strength.operation = 'MULTIPLY'
            strength.name = EYE_SHADOW_NODE_NAME
            strength.label = "Lid Shadow Strength"
            links.new(ring.outputs["Alpha"], strength.inputs[0])
            strength.inputs[1].default_value = settings.eye_shadow
            both = nt.nodes.new("ShaderNodeMath")
            both.operation = 'MAXIMUM'
            both.label = "Wet Line + Shadow"
            links.new(opacity, both.inputs[0])
            links.new(strength.outputs[0], both.inputs[1])
            opacity = both.outputs[0]
            helpers["Eye · lid shadow"] = [strength, both]
        links.new(opacity, gin["Opacity"])
    if slots["emissive"]:
        em = tex(slots["emissive"], False, False, "Emission")
        links.new(em.outputs["Color"], gin["Emissive"])
        gin["Emission Gain"].default_value = emissive_gain(slots["emissive"])

    if metal_mode == 'AUTO':
        mask = 1.0 if (kind == 'DEFAULT' and slots["cs"] and alpha_is_metal_mask(slots["cs"])) else 0.0
    else:
        mask = 1.0 if metal_mode == 'ON' else 0.0
    gin["Metal Mask"].default_value = mask
    if kind != 'DEFAULT':
        gin["Dielectric F0"].default_value = SKIN_F0
    if kind == 'SKIN':
        gin["Roughness Min"].default_value = settings.skin_roughness_min
    gin["Normal Strength"].default_value = settings.normal_strength
    gin["AO Strength"].default_value = settings.ao_strength
    gin["Emission Strength"].default_value = settings.emission_strength
    gin["Emission Color"].default_value = tuple(settings.emission_color) + (1.0,)
    curve_id = settings.gloss_curve
    if curve_id == 'GAME':
        curve_id = GAME_CURVE.get(getattr(settings, "game", 'BO7'), 'WWII')
    curve = GLOSS_CURVES.get(curve_id)
    gin["CoD Gloss Curve"].default_value = 1.0 if curve else 0.0
    if curve:
        gin["Gloss Exponent"].default_value, gin["Gloss Bias"].default_value = curve

    if kind == 'SKIN' and settings.skin_sss:
        # Random Walk (Skin) is Cycles' measured skin medium: it keeps the red bleed while holding on to
        # the pores and the shading in the concha of an ear, which plain random walk washes into wax
        if 'RANDOM_WALK_SKIN' in {i.identifier for i in bsdf.bl_rna.properties["subsurface_method"].enum_items}:
            bsdf.subsurface_method = 'RANDOM_WALK_SKIN'
        for names, value in ((("Subsurface Weight", "Subsurface"), settings.sss_weight),
                             (("Subsurface Radius",), SKIN_SSS_RADIUS),
                             (("Subsurface Anisotropy",), SKIN_SSS_ANISOTROPY),
                             (("Diffuse Roughness",), SKIN_DIFFUSE_ROUGHNESS)):
            sock = _principled_input(bsdf, *names)
            if sock is not None:
                sock.default_value = value
        scale_in = _principled_input(bsdf, "Subsurface Scale")
        if scale_in is not None:
            scale_out, sss_nodes = _sss_scale_nodes(nt, settings.sss_scale)
            links.new(scale_out, scale_in)
            helpers["Skin · SSS scale (follows object scale)"] = sss_nodes

    if kind == 'SKIN' and settings.skin_oil > 0.0:
        # A thin film of sebum over the diffuse skin. Real skin is never uniformly oily, so the film follows the
        # game's own gloss map - forehead, nose and lips read shiny, cheeks matte - and thins inside pores and
        # creases via the AO channel. A flat coat over the whole face is what makes skin look like plastic.
        shiny = nt.nodes.new("ShaderNodeMath")
        shiny.operation = 'MULTIPLY'
        shiny.label = "Oil Where Skin Is Shiny"
        links.new(grp.outputs["Gloss"], shiny.inputs[0])
        links.new(grp.outputs["Occlusion"], shiny.inputs[1])
        amount = nt.nodes.new("ShaderNodeMath")
        amount.operation = 'MULTIPLY'
        amount.name = SKIN_OIL_NODE_NAME
        amount.label = "Skin Oil"
        links.new(shiny.outputs[0], amount.inputs[0])
        amount.inputs[1].default_value = settings.skin_oil
        film = nt.nodes.new("ShaderNodeMapRange")
        film.label = "Oil Film Roughness"
        film.inputs["Value"].default_value = 0.0
        links.new(grp.outputs["Gloss"], film.inputs["Value"])
        film.inputs["To Min"].default_value, film.inputs["To Max"].default_value = SKIN_OIL_ROUGHNESS
        for name, src in (("Coat Weight", amount.outputs[0]), ("Coat Roughness", film.outputs[0])):
            sock = _principled_input(bsdf, name)
            if sock is not None:
                links.new(src, sock)
        ior = _principled_input(bsdf, "Coat IOR")
        if ior is not None:
            ior.default_value = SKIN_OIL_IOR
        helpers["Skin · oil film"] = [shiny, amount, film]

    if kind == 'EYE':
        # wet cornea: CoD's eye techset adds this in-shader, the textures only carry the matte eyeball
        for names, value in ((("Coat Weight",), 1.0), (("Coat Roughness",), EYE_COAT_ROUGHNESS),
                             (("Coat IOR",), EYE_CORNEA_IOR)):
            sock = _principled_input(bsdf, *names)
            if sock is not None:
                sock.default_value = value

    wiring = (
        ("Base Color", ("Base Color",)),
        ("Metallic", ("Metallic",)),
        ("Roughness", ("Roughness",)),
        ("IOR", ("IOR",)),
        ("Normal", ("Normal",)),
        ("Alpha", ("Alpha",)),
        ("Emission Color", ("Emission Color", "Emission")),
        ("Emission Strength", ("Emission Strength",)),
    )
    shader = bsdf
    if kind == 'HAIR' and settings.hair_shader:
        hair = nt.nodes.new("ShaderNodeGroup")
        hair.node_tree = get_hair_group()
        hair.name = HAIR_NODE_NAME
        hair.label = "CoD Hair Shader"
        hair.width = 260
        hin = hair.inputs
        links.new(grp.outputs["Base Color"], hin["Color"])
        links.new(grp.outputs["Normal"], hin["Normal"])
        links.new(grp.outputs["Alpha"], hin["Alpha"])
        links.new(grp.outputs["Occlusion"], hin["Occlusion"])
        if slots["strand"]:
            strand = tex(slots["strand"], True, False, "Hair Strands  (0x4d)")
            links.new(strand.outputs["Color"], hin["Strand ID"])
        links.new(hair.outputs["Shader"], out.inputs["Surface"])
        nt.nodes.remove(bsdf)
        shader = hair
    else:
        for src, dst_names in wiring:
            dst = _principled_input(bsdf, *dst_names)
            if dst is not None:
                links.new(grp.outputs[src], dst)

    _arrange(nt, textures, grp, shader, out, helpers)

    if has_opacity:
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = 'DITHERED'
        elif hasattr(mat, "blend_method"):
            mat.blend_method = 'HASHED'
        mat.use_backface_culling = False

    mat["cod_shaded"] = True
    mat["cod_kind"] = kind
    mat["cod_metal_mask"] = mask
    return mask


def _arrange(nt, textures, decode, shader, out, helpers):
    """Beginner-friendly layout: framed columns Maps -> Decode -> Shader -> Output, wires left to right."""
    for i, t in enumerate(textures):
        t.location = (X_TEX, Y_TOP - i * TEX_STEP)
        _hide_unused(t)
    decode.location = (X_DEC, Y_TOP)
    _hide_unused(decode, only=DECODE_MAP_INPUTS)
    _hide_unused(decode, inputs=False)
    shader.location = (X_SHADER, Y_TOP)
    out.location = (X_OUT, Y_TOP)

    _frame(nt, "1 · Texture maps (from Saluki)", "tex", textures)
    _frame(nt, "2 · CoD decode (tweak the Adjust sliders)", "decode", [decode])
    _frame(nt, "3 · Shader", "shader", [shader, out])

    # helper frames below the decode column; the eye depth node sits left of the maps it drives
    y = Y_TOP - 600
    for label, nodes_in in helpers.items():
        if label.startswith("Eye · iris"):
            nodes_in[0].location = (X_EYE, Y_TOP)
        else:
            for j, n in enumerate(nodes_in):
                n.location = (X_DEC + j * 190, y)
            y -= 260
        _frame(nt, label, "helper", nodes_in)

    tip = nt.nodes.new("NodeFrame")
    tip.label = "Tip: adjust the sliders on the green nodes, or use the CoD tab in the sidebar (N)"
    tip.label_size = 18
    tip.use_custom_color = True
    tip.color = FRAME_COLORS["tip"]
    tip.shrink = False
    tip.location = (X_TEX, Y_TOP + 150)
    tip.width = X_OUT + 200 - X_TEX
    tip.height = 70


# --------------------------------------------------------------------------------------------
# Sights: lens glass, collimated red-dot reticle, picture-in-picture scope (Cycles Ray Portal)
# --------------------------------------------------------------------------------------------
# Lens meshes are flat discs facing the shooter (MWII's att_lens_minireddot on tag_reflex, the scope eyepiece
# stack on tag_lense), so the sight axis is the lens normal pointing away from the eye. A collimated reticle
# depends only on the viewing ANGLE to that axis, not on where the eye ray crosses the glass, so it stays on
# the aim point when the head moves - like the game. The scope surface (ads_scope_lens*) re-shoots every eye
# ray from past the objective lens with its off-axis angle divided by the zoom: a real magnified
# picture-in-picture, framed by the game's eye-relief disc (the scope shadow) and a crosshair.

SIGHT_NODE_NAME = "CoD Sight"
SIGHT_GROUP_VERSION = 2
RETICLE_NODE_NAME = "CoD Reticle Light"
# Game lens meshes are slightly domed (the MWII scope eyepiece: 2.4 mm over 3.9 cm, face normals up to 12 deg
# off), which would bend a collimated reticle and the zoomed view. A geometry-nodes modifier after the armature
# stores each lens material's area-weighted mean normal as a face attribute: a flat axis that follows animation.
SIGHT_AXIS_ATTR = "cod_sight_axis"
SIGHT_AXIS_MODIFIER = "CoD Sight Axis"
SCOPE_PORTAL_OFFSET_CM = 40.0     # fallback; measured per scope from its objective lens when possible
SCOPE_PORTAL_MARGIN_CM = 3.0
SCOPE_CLEAR_RADIUS_CM = 15.0      # weapon parts this close to the scope axis are skipped by the magnified view
ARM_BONE_PREFIXES = ("j_wrist", "j_elbow", "j_shoulder", "j_clavicle", "j_index", "j_thumb")
LENS_IOR = 1.52
LENS_REFLECTION_NODE_NAME = "CoD Lens Reflection"
COATED_LENS_REFLECTION = 0.25     # scope optics are anti-reflection coated; bare glass reflects ~4%
DEG = 0.0174533


def _live_socket(sockets, name):
    """Sockets of type-switching nodes share a name across hidden variants; take the enabled one."""
    return next(s for s in sockets if s.name.startswith(name) and s.enabled)


def get_sight_axis_nodes():
    name = "CoD Sight Axis v1"
    ng = bpy.data.node_groups.get(name)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(name, "GeometryNodeTree")
    if hasattr(ng, "is_modifier"):
        ng.is_modifier = True
    ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    nodes, link = ng.nodes, ng.links.new
    gi = nodes.new("NodeGroupInput")
    gi.location = (-800, 0)
    go = nodes.new("NodeGroupOutput")
    go.location = (400, 0)
    normal = nodes.new("GeometryNodeInputNormal")
    normal.location = (-800, -200)
    area = nodes.new("GeometryNodeInputMeshFaceArea")
    area.location = (-800, -350)
    lens_id = nodes.new("GeometryNodeInputMaterialIndex")    # one axis per lens material (islands can be split)
    lens_id.location = (-800, -450)
    weighted = nodes.new("ShaderNodeVectorMath")
    weighted.operation = 'SCALE'
    weighted.location = (-600, -250)
    link(normal.outputs.get("True Normal") or normal.outputs["Normal"], weighted.inputs[0])
    link(area.outputs["Area"], weighted.inputs[3])
    acc = nodes.new("GeometryNodeAccumulateField")
    acc.data_type = 'FLOAT_VECTOR'
    acc.domain = 'FACE'
    acc.location = (-400, -250)
    link(weighted.outputs[0], _live_socket(acc.inputs, "Value"))
    link(lens_id.outputs[0], _live_socket(acc.inputs, "Group"))
    unit = nodes.new("ShaderNodeVectorMath")
    unit.operation = 'NORMALIZE'
    unit.location = (-200, -250)
    link(_live_socket(acc.outputs, "Total"), unit.inputs[0])
    store = nodes.new("GeometryNodeStoreNamedAttribute")
    store.data_type = 'FLOAT_VECTOR'
    store.domain = 'FACE'
    store.location = (100, 0)
    store.inputs["Name"].default_value = SIGHT_AXIS_ATTR
    link(gi.outputs[0], store.inputs["Geometry"])
    link(unit.outputs[0], _live_socket(store.inputs, "Value"))
    link(store.outputs["Geometry"], go.inputs[0])
    return ng


def _add_sight_axis_modifier(mat):
    for ob, _ in _material_polygons(mat):
        mod = ob.modifiers.get(SIGHT_AXIS_MODIFIER)
        if mod is None:
            mod = ob.modifiers.new(SIGHT_AXIS_MODIFIER, 'NODES')     # appended after the armature deform
        mod.node_group = get_sight_axis_nodes()


def get_sight_group():
    name = "CoD Sight v%d" % SIGHT_GROUP_VERSION
    ng = bpy.data.node_groups.get(name)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    iface = ng.interface
    for out_name, stype in (("Dot", "NodeSocketFloat"), ("Ring", "NodeSocketFloat"), ("Crosshair", "NodeSocketFloat"),
                            ("Eye Box", "NodeSocketFloat"), ("Portal Position", "NodeSocketVector"),
                            ("Portal Direction", "NodeSocketVector"), ("Relief UV", "NodeSocketVector")):
        _socket(iface, out_name, "OUTPUT", stype)
    ret = iface.new_panel("Reticle")
    _socket(iface, "Dot Size", "INPUT", "NodeSocketFloat", 0.15, 0.0, 5.0, "Dot radius in degrees", parent=ret)
    _socket(iface, "Ring Size", "INPUT", "NodeSocketFloat", 1.2, 0.0, 10.0,
            "Circle radius in degrees (scopes: where the thick crosshair posts start)", parent=ret)
    _socket(iface, "Line Width", "INPUT", "NodeSocketFloat", 0.08, 0.0, 2.0, "Circle / crosshair line width in degrees",
            parent=ret)
    scope = iface.new_panel("Scope")
    _socket(iface, "Zoom", "INPUT", "NodeSocketFloat", 4.0, 1.0, 40.0, "Magnification of the picture-in-picture",
            parent=scope)
    _socket(iface, "Eye Relief", "INPUT", "NodeSocketFloat", 1.5, 0.0, 20.0,
            "How fast the scope shadow closes in when the eye moves off the scope's center line", parent=scope)
    _socket(iface, "Portal Offset (cm)", "INPUT", "NodeSocketFloat", SCOPE_PORTAL_OFFSET_CM, 0.0, 500.0,
            "Where the magnified view starts: just past the objective lens (follows object scale)", parent=scope)
    _socket(iface, "Lens Center", "INPUT", "NodeSocketVector", (0.5, 0.5, 0.0), desc="Center of the lens disc in UV",
            parent=scope)
    _socket(iface, "Lens UV Scale", "INPUT", "NodeSocketFloat", 0.2, 0.0, 10.0,
            "Lens UV units per object cm (measured on the mesh)", parent=scope)
    _socket(iface, "V Sign", "INPUT", "NodeSocketFloat", 1.0, -1.0, 1.0,
            "+1 or -1: orientation of the lens UV's v axis (measured on the mesh)", parent=scope)

    b = _Builder(ng)
    nodes, link = ng.nodes, ng.links.new
    gi = nodes.new("NodeGroupInput")
    gi.location = (-1800, 0)
    go = nodes.new("NodeGroupOutput")
    go.location = (1300, 0)
    inp = gi.outputs
    geo = nodes.new("ShaderNodeNewGeometry")
    geo.location = (-1800, -500)
    tan = nodes.new("ShaderNodeTangent")
    tan.direction_type = 'UV_MAP'
    tan.location = (-1800, -800)
    tc = nodes.new("ShaderNodeTexCoord")
    tc.location = (-1800, 400)

    def dot(a, c, loc):
        n = nodes.new("ShaderNodeVectorMath")
        n.operation = 'DOT_PRODUCT'
        n.location = loc
        link(a, n.inputs[0])
        link(c, n.inputs[1])
        return n.outputs["Value"]

    I, Ng, P = geo.outputs["Incoming"], geo.outputs["True Normal"], geo.outputs["Position"]
    # lens axis from the CoD Sight Axis modifier (flat, per lens); the face normal where it is missing
    attr = nodes.new("ShaderNodeAttribute")
    attr.attribute_type = 'GEOMETRY'
    attr.attribute_name = SIGHT_AXIS_ATTR
    attr.location = (-2100, -250)
    to_world = nodes.new("ShaderNodeVectorTransform")
    to_world.vector_type = 'NORMAL'
    to_world.convert_from = 'OBJECT'
    to_world.convert_to = 'WORLD'
    to_world.location = (-1900, -250)
    link(attr.outputs["Vector"], to_world.inputs[0])
    has_axis = b.math("GREATER_THAN", b.vmath("LENGTH", attr.outputs["Vector"], loc=(-1900, -120)).node.outputs["Value"],
                      0.5, loc=(-1750, -120))
    stored = b.vmath("NORMALIZE", to_world.outputs[0], loc=(-1750, -250))
    N0 = b.vmath("ADD", Ng, b.vmath("SCALE", b.vmath("SUBTRACT", stored, Ng, loc=(-1600, -250)), scale=has_axis,
                                    loc=(-1450, -250)), loc=(-1300, -250))
    # sight axis A: the lens normal, turned to point away from the eye
    facing = b.math("SIGN", dot(N0, I, (-1600, -450)), loc=(-1450, -450))
    A = b.vmath("SCALE", N0, scale=b.math("MULTIPLY", facing, -1.0, loc=(-1300, -450)), loc=(-1150, -450))
    d = b.vmath("SCALE", I, scale=-1.0, loc=(-1600, -600))                       # eye -> lens
    # lens frame: T along UV u, B along UV v (u right / v up seen from the eye)
    T0 = tan.outputs["Tangent"]
    T = b.vmath("NORMALIZE", b.vmath("SUBTRACT", T0, b.vmath("SCALE", A, scale=dot(T0, A, (-1450, -850)),
                                                              loc=(-1300, -850)), loc=(-1150, -850)), loc=(-1000, -850))
    B = b.vmath("CROSS_PRODUCT", T, A, loc=(-850, -850))
    dz = b.math("MAXIMUM", dot(d, A, (-1000, -600)), 0.05, loc=(-850, -600))
    ax = b.math("DIVIDE", dot(d, T, (-700, -700)), dz, loc=(-550, -700))       # tan of the off-axis angle
    ay = b.math("DIVIDE", dot(d, B, (-700, -850)), dz, loc=(-550, -850))
    r = b.math("SQRT", b.math("ADD", b.math("MULTIPLY", ax, ax, loc=(-400, -700)),
                               b.math("MULTIPLY", ay, ay, loc=(-400, -850)), loc=(-250, -780)), loc=(-100, -780))

    def inside(value, edge, loc):
        """1 where value < edge, with a soft edge (anti-aliased reticle lines)"""
        mr = nodes.new("ShaderNodeMapRange")
        mr.data_type = 'FLOAT'
        mr.interpolation_type = 'SMOOTHSTEP'
        mr.location = loc
        link(value, mr.inputs[0])
        link(b.math("MULTIPLY", edge, 0.6, loc=(loc[0] - 160, loc[1] + 80)), mr.inputs[1])
        link(edge, mr.inputs[2])
        mr.inputs[3].default_value = 1.0
        mr.inputs[4].default_value = 0.0
        return mr.outputs[0]

    dot_r = b.math("MULTIPLY", inp["Dot Size"], DEG, loc=(100, -150))
    ring_r = b.math("MULTIPLY", inp["Ring Size"], DEG, loc=(100, -300))
    half_w = b.math("MULTIPLY", inp["Line Width"], DEG * 0.5, loc=(100, -450))
    link(inside(r, dot_r, (450, -150)), go.inputs["Dot"])
    ring_dist = b.math("ABSOLUTE", b.math("SUBTRACT", r, ring_r, loc=(250, -300)), loc=(400, -300))
    link(inside(ring_dist, half_w, (650, -300)), go.inputs["Ring"])
    # duplex crosshair: fine lines in the middle, 3x thicker posts past the ring radius
    posts = b.math("MULTIPLY_ADD", b.math("GREATER_THAN", r, ring_r, loc=(250, -600)), 2.0, 1.0, loc=(400, -600))
    thick = b.math("MULTIPLY", half_w, posts, loc=(550, -600))
    cx = inside(b.math("ABSOLUTE", ay, loc=(550, -700)), thick, (850, -650))
    cy = inside(b.math("ABSOLUTE", ax, loc=(550, -850)), thick, (850, -800))
    link(b.math("MAXIMUM", cx, cy, loc=(1050, -700)), go.inputs["Crosshair"])

    vt = nodes.new("ShaderNodeVectorTransform")
    vt.vector_type = 'VECTOR'
    vt.convert_from = 'OBJECT'
    vt.convert_to = 'WORLD'
    vt.inputs[0].default_value = (0.57735, 0.57735, 0.57735)
    vt.location = (-1300, 700)
    obj_scale = b.vmath("LENGTH", vt.outputs[0], loc=(-1100, 700)).node.outputs["Value"]

    # scope shadow: set by where the EYE sits relative to the scope's center line (the exit pupil), not by the
    # angle of each ray. The eye, projected along the axis onto the lens, lands at this point's UV plus the
    # sideways part of the ray times the view distance; its offset from the lens center shifts the game's
    # relief disc. A centered eye sees the whole disc at any distance - at ADS the eye is only ~2 cm away.
    cam = nodes.new("ShaderNodeCameraData")
    cam.location = (-1100, 450)
    uv_per_world = b.math("DIVIDE", inp["Lens UV Scale"], obj_scale, loc=(-900, 600))
    reach = b.math("MULTIPLY", cam.outputs["View Distance"], uv_per_world, loc=(-750, 500))
    eye = nodes.new("ShaderNodeCombineXYZ")
    eye.location = (-450, 350)
    link(b.math("MULTIPLY", dot(d, T, (-750, 350)), b.math("MULTIPLY", reach, -1.0, loc=(-600, 450)),
                loc=(-600, 350)), eye.inputs[0])
    link(b.math("MULTIPLY", b.math("MULTIPLY", dot(d, B, (-900, 200)), inp["V Sign"], loc=(-750, 200)),
                b.math("MULTIPLY", reach, -1.0, loc=(-600, 250)), loc=(-600, 200)), eye.inputs[1])
    eye_uv = b.vmath("ADD", tc.outputs["UV"], eye.outputs[0], loc=(-300, 350))
    eye_off = b.vmath("SUBTRACT", eye_uv, inp["Lens Center"], loc=(-150, 350))
    relief_uv = b.vmath("SUBTRACT", tc.outputs["UV"], b.vmath("SCALE", eye_off, scale=inp["Eye Relief"],
                                                               loc=(0, 450)), loc=(150, 400))
    link(relief_uv, go.inputs["Relief UV"])
    off_center = nodes.new("ShaderNodeVectorMath")
    off_center.operation = 'DISTANCE'
    off_center.location = (300, 300)
    link(relief_uv, off_center.inputs[0])
    link(inp["Lens Center"], off_center.inputs[1])
    box = nodes.new("ShaderNodeMapRange")
    box.data_type = 'FLOAT'
    box.interpolation_type = 'SMOOTHSTEP'
    box.location = (500, 300)
    link(off_center.outputs["Value"], box.inputs[0])
    box.inputs[1].default_value = 0.26
    box.inputs[2].default_value = 0.38
    box.inputs[3].default_value = 1.0
    box.inputs[4].default_value = 0.0
    link(box.outputs[0], go.inputs["Eye Box"])

    # picture-in-picture: start past the objective, direction = axis + (off-axis part / zoom)
    along = b.vmath("SCALE", A, scale=dz, loc=(-700, -1050))
    d_perp = b.vmath("SUBTRACT", d, along, loc=(-550, -1050))
    shrunk = b.vmath("SCALE", d_perp, scale=b.math("DIVIDE", 1.0, inp["Zoom"], loc=(-700, -1200)), loc=(-400, -1100))
    link(b.vmath("NORMALIZE", b.vmath("ADD", along, shrunk, loc=(-250, -1050)), loc=(-100, -1050)),
         go.inputs["Portal Direction"])
    offset = b.math("MULTIPLY", inp["Portal Offset (cm)"], obj_scale, loc=(-350, -1350))
    link(b.vmath("ADD", P, b.vmath("SCALE", A, scale=offset, loc=(-200, -1350)), loc=(-50, -1350)),
         go.inputs["Portal Position"])
    return ng


def sight_kind(mat_name):
    """'SCOPE' (picture-in-picture surface), 'RETICLE' (UI stencil), 'LENS' (sight / clear glass) or None."""
    name = re.sub(r"\.\d{3}$", "", mat_name).lower()
    if "reticle" in name:
        return 'RETICLE'
    if "ads_scope_lens" in name and "reflection" not in name:
        return 'SCOPE'
    if re.search(r"(^|_)(lens|lenses|glass|glasses)(_|$)", name):
        return 'LENS'
    return None


def _clear_techsets(index):
    """Techsets the game uses for see-through shells. The tear film (lacrimal fluid) is always one of them, and
    the same techset carries things like watch crystals, whose materials hold no textures at all - a 1x1 black
    colour map - so they would otherwise come out as an opaque black disc."""
    found = set()
    for info in index.by_name.values():
        if info.techset and classify(info.name, resolve_slots(info), info.image_names) == 'TEARFILM':
            found.add(info.techset)
    return found


def _is_untextured(info, slots):
    """A material whose colour map is a placeholder constant (1x1 / 4x4) carries no art of its own."""
    cs = slots.get("cs")
    if cs is None:
        return True
    width, height = _sample(cs)[1]
    return max(width, height) <= 8


def is_red_dot_lens(mat_name):
    """The eye-side lens of a reflex / holographic sight carries the reticle (the '_far' lens faces away)."""
    name = mat_name.lower()
    return bool(re.search(r"reddot|red_dot|reflex|holo|minired|eotech|(^|_)rds|(^|_)optic", name)) and "far" not in name


def _material_images(info):
    """Every image a _mat_info lists (lens maps are picked by their unhashed names)."""
    if info is None:
        return []
    paths = list(info.by_semantic.values()) + list(info.by_slot.values()) + info.extras + [info.albedo]
    return [p for p in paths if p and not _is_placeholder(p) and os.path.exists(p)]


def _find_image(paths, *patterns):
    for p in paths:
        base = os.path.basename(p).lower()
        if any(re.search(pt, base) for pt in patterns):
            return p
    return None


def _mean_color(path, default=(1.0, 1.0, 1.0)):
    """Average color of a small tint map, sRGB -> linear. Saturated maps are techset parameters (BO7 keeps a red
    flag in that slot), not a glass tint, so they fall back to the default."""
    px = sample_rgba(path) if path else None
    if px is None:
        return default
    rgb = px[:, :3].mean(0)
    if float(rgb.max() - rgb.min()) > 0.25:
        return default
    return tuple(float(c) ** 2.2 for c in rgb)


def _material_polygons(mat):
    """[(object, [polygons])] of every mesh using the material."""
    found = []
    for ob in bpy.data.objects:
        if ob.type != 'MESH':
            continue
        idx = {i for i, s in enumerate(ob.material_slots) if s.material == mat}
        if idx:
            polys = [p for p in ob.data.polygons if p.material_index in idx]
            if polys:
                found.append((ob, polys))
    return found


def _is_arms_mesh(ob):
    return any(g.name.lower().startswith(ARM_BONE_PREFIXES) for g in ob.vertex_groups)


def _lens_uv_frame(me, polys, mw):
    """(UV units per object unit, dP/du, dP/dv in world) averaged over the lens triangles, or Nones."""
    uv_layer = me.uv_layers.active
    if uv_layer is None:
        return None, None, None
    dpdu, dpdv, lengths = Vector(), Vector(), []
    for p in polys:
        if len(p.loop_indices) < 3:
            continue
        l0, l1, l2 = p.loop_indices[:3]
        t0, t1, t2 = (uv_layer.data[li].uv for li in (l0, l1, l2))
        q0, q1, q2 = (me.vertices[me.loops[li].vertex_index].co for li in (l0, l1, l2))
        du1, dv1, du2, dv2 = t1.x - t0.x, t1.y - t0.y, t2.x - t0.x, t2.y - t0.y
        det = du1 * dv2 - du2 * dv1
        if abs(det) < 1e-12:
            continue
        e1, e2 = q1 - q0, q2 - q0
        pu, pv = (e1 * dv2 - e2 * dv1) / det, (e2 * du1 - e1 * du2) / det
        weight = abs(det)
        dpdu += pu * weight
        dpdv += pv * weight
        lengths.append((pu.length + pv.length) * 0.5)
    if not lengths or dpdu.length < 1e-9:
        return None, None, None
    lengths.sort()
    return 1.0 / lengths[len(lengths) // 2], mw.to_3x3() @ dpdu, mw.to_3x3() @ dpdv


def _scope_geometry(mat):
    """(UV center of the scope disc, portal offset in object cm, UV per object cm, v sign) measured on the rest
    mesh, or Nones. Like the game's scope camera, the magnified view starts past the weapon: the objective lens,
    barrel, muzzle and front sight near the scope axis."""
    geometry = _scope_measure(mat)
    return geometry if geometry else (None, None, None, None)


def _scope_measure(mat):
    users = _material_polygons(mat)
    if not users:
        return None
    ob, polys = users[0]
    me, mw = ob.data, ob.matrix_world
    uv_layer = me.uv_layers.active
    center_uv = None
    if uv_layer is not None:
        uvs = [uv_layer.data[li].uv for p in polys for li in p.loop_indices]
        center_uv = (0.5 * (min(u.x for u in uvs) + max(u.x for u in uvs)),
                     0.5 * (min(u.y for u in uvs) + max(u.y for u in uvs)), 0.0)
    uv_scale, dpdu, dpdv = _lens_uv_frame(me, polys, mw)
    pts = [mw @ me.vertices[v].co for p in polys for v in p.vertices]
    center = sum(pts, pts[0] * 0.0) / len(pts)
    normal = sum((mw.to_3x3() @ p.normal for p in polys), pts[0] * 0.0)
    if normal.length < 1e-6:
        return center_uv, None, uv_scale, 1.0
    normal.normalize()
    radius = max((q - center).length for q in pts)
    scale = sum(abs(v) for v in mw.to_scale()) / 3.0 or 1.0
    # forward = away from the eye: the side where the other lenses of this scope (the objective) sit
    forward, far_lens = 0.0, 0.0
    clear = SCOPE_CLEAR_RADIUS_CM * scale
    weapon = [o for o in bpy.data.objects if o.type == 'MESH' and not _is_arms_mesh(o)
              and (ob.parent is None or o.parent is ob.parent)]
    reach = []
    for other in weapon:
        lens_idx = {i for i, s in enumerate(other.material_slots)
                    if s.material is not None and sight_kind(s.material.name) == 'LENS'}
        omw = other.matrix_world
        for p in other.data.polygons:
            rel = omw @ p.center - center
            along = rel.dot(normal)
            lateral = (rel - normal * along).length
            if p.material_index in lens_idx and lateral < radius * 3.0 and abs(along) > abs(far_lens):
                far_lens = along
            if lateral < clear:
                reach.append(along)
    if abs(far_lens) <= radius:
        return center_uv, None, uv_scale, 1.0
    sign = 1.0 if far_lens > 0 else -1.0
    forward = max(abs(far_lens), max((sign * a for a in reach), default=0.0))
    # the shader's v axis is cross(normal toward the eye, u); flip it if the UVs run the other way
    v_sign = 1.0
    if dpdu is not None:
        toward_eye = normal * -sign
        v_sign = 1.0 if toward_eye.cross(dpdu).dot(dpdv) >= 0.0 else -1.0
    return center_uv, forward / scale + SCOPE_PORTAL_MARGIN_CM, uv_scale, v_sign


def build_sight_material(mat, kind, slots, info, settings):
    if hasattr(mat, "use_nodes") and not mat.use_nodes:
        mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    links = nt.links
    new = nt.nodes.new
    images = _material_images(info)
    maps, sight_nodes, shader_nodes = [], [], []
    # columns: maps | sight | shader (three sub-columns) | output
    x_sight, x_s1, x_s2, x_s3 = X_TEX + 380, X_DEC + 180, X_SHADER + 180, X_OUT + 120
    out = new("ShaderNodeOutputMaterial")

    def at(node, x, y, bucket):
        node.location = (x, y)
        bucket.append(node)
        return node

    def tex(path, data, label):
        node = new("ShaderNodeTexImage")
        node.image = load_image(path, data, False)
        node.label = label
        node.width = 240
        return at(node, X_TEX, Y_TOP - len(maps) * TEX_STEP, maps)

    def math(op, a, b, x, y, bucket):
        node = at(new("ShaderNodeMath"), x, y, bucket)
        node.operation = op
        for i, v in enumerate((a, b)):
            if isinstance(v, bpy.types.NodeSocket):
                links.new(v, node.inputs[i])
            else:
                node.inputs[i].default_value = v
        return node.outputs[0]

    def add_sight_group():
        sight = at(new("ShaderNodeGroup"), x_sight, Y_TOP, sight_nodes)
        sight.node_tree = get_sight_group()
        sight.name = SIGHT_NODE_NAME
        sight.label = "CoD Sight  (reticle + zoom)"
        sight.width = 230
        return sight

    tip_text = "Tip: tweak the CoD Sight node, or use the CoD tab in the sidebar (N)"
    if kind == 'RETICLE':
        # the game draws the scope reticle through this stencil; the scope surface draws it here instead
        t = at(new("ShaderNodeBsdfTransparent"), x_s1, Y_TOP, shader_nodes)
        links.new(t.outputs[0], out.inputs["Surface"])
        out.location = (x_s2, Y_TOP)
        tip_text = "Reticle stencil: see-through here, the scope lens draws the crosshair"
    elif kind == 'SCOPE':
        sight = add_sight_group()
        sin = sight.inputs
        sin["Zoom"].default_value = settings.scope_zoom
        sin["Ring Size"].default_value = 3.0
        sin["Line Width"].default_value = 0.15
        center_uv, offset, uv_scale, v_sign = _scope_geometry(mat)
        if center_uv:
            sin["Lens Center"].default_value = center_uv
        if offset:
            sin["Portal Offset (cm)"].default_value = offset
        if uv_scale:
            sin["Lens UV Scale"].default_value = uv_scale
        if v_sign:
            sin["V Sign"].default_value = v_sign
        portal = at(new("ShaderNodeBsdfRayPortal"), x_s1, Y_TOP, shader_nodes)
        portal.label = "Zoomed View  (Cycles)"
        links.new(sight.outputs["Portal Position"], portal.inputs["Position"])
        links.new(sight.outputs["Portal Direction"], portal.inputs["Direction"])
        relief = _find_image(images, r"relief", r"lens_r\.", r"_r~")
        if relief:
            # the game's eye-relief disc: soft white circle with a chromatic rim = the scope shadow
            rt = tex(relief, False, "Scope Shadow  (relief)")
            rt.extension = 'CLIP'
            links.new(sight.outputs["Relief UV"], rt.inputs["Vector"])
            links.new(rt.outputs["Color"], portal.inputs["Color"])
        else:
            links.new(sight.outputs["Eye Box"], portal.inputs["Color"])
        black = at(new("ShaderNodeEmission"), x_s1, Y_TOP - 250, shader_nodes)
        black.label = "Crosshair Color"
        black.inputs["Color"].default_value = (0.0, 0.0, 0.0, 1.0)
        mix = at(new("ShaderNodeMixShader"), x_s2, Y_TOP, shader_nodes)
        mix.label = "Crosshair"
        links.new(sight.outputs["Crosshair"], mix.inputs[0])
        links.new(portal.outputs[0], mix.inputs[1])
        links.new(black.outputs[0], mix.inputs[2])
        links.new(mix.outputs[0], out.inputs["Surface"])
        out.location = (x_s3, Y_TOP)
        tip_text = "Tip: the zoomed scope view renders in Cycles - set Zoom on the CoD Sight node"
    else:
        # sight / clear glass: tinted see-through with the lens dirt map and a Fresnel reflection
        tint = slots.get("params") or _find_image(images, r"_tf?~", r"_tf?\.")
        dirt = _find_image(images, r"_tr~", r"_tr\.")
        refl_mask = _find_image(images, r"reflection_a")
        reticle = settings.red_dot_reticle and is_red_dot_lens(mat.name)
        y_glass = Y_TOP - 330 if reticle else Y_TOP
        color = at(new("ShaderNodeRGB"), X_DEC, y_glass, shader_nodes)
        color.label = "Glass Tint"
        color.outputs[0].default_value = _mean_color(tint, (0.95, 0.96, 0.96)) + (1.0,)
        glass_col = color.outputs[0]
        if dirt:
            dt = tex(dirt, False, "Lens Dirt  (_tr)")
            mul = at(new("ShaderNodeMix"), x_s1, y_glass, shader_nodes)
            mul.label = "Tint x Dirt"
            mul.data_type = 'RGBA'
            mul.blend_type = 'MULTIPLY'
            mul.inputs[0].default_value = 1.0
            links.new(glass_col, mul.inputs[6])
            links.new(dt.outputs["Color"], mul.inputs[7])
            glass_col = mul.outputs[2]
        clear = at(new("ShaderNodeBsdfTransparent"), x_s2, y_glass, shader_nodes)
        links.new(glass_col, clear.inputs["Color"])
        glossy = at(new("ShaderNodeBsdfGlossy"), x_s2, y_glass - 120, shader_nodes)
        glossy.inputs["Roughness"].default_value = 0.03
        fresnel = at(new("ShaderNodeFresnel"), X_DEC, y_glass - 230, shader_nodes)
        fresnel.inputs["IOR"].default_value = LENS_IOR
        amount = at(new("ShaderNodeValue"), X_DEC, y_glass - 350, shader_nodes)
        amount.name = LENS_REFLECTION_NODE_NAME
        amount.label = "Lens Reflection"
        amount.outputs[0].default_value = COATED_LENS_REFLECTION if "scope" in mat.name.lower() else 1.0
        fac = math('MULTIPLY', fresnel.outputs[0], amount.outputs[0], x_s1, y_glass - 250, shader_nodes)
        if refl_mask:
            mt = tex(refl_mask, True, "Reflection Mask")
            fac = math('MULTIPLY', fac, mt.outputs["Color"], x_s1, y_glass - 420, shader_nodes)
        glass = at(new("ShaderNodeMixShader"), x_s3, y_glass, shader_nodes)
        glass.label = "Glass"
        links.new(fac, glass.inputs[0])
        links.new(clear.outputs[0], glass.inputs[1])
        links.new(glossy.outputs[0], glass.inputs[2])
        surface = glass.outputs[0]
        out.location = (x_s3 + 220, Y_TOP)
        if reticle:
            sight = add_sight_group()
            sight.inputs["Ring Size"].default_value = settings.reticle_size
            style = settings.reticle_style
            if style == 'DOT':
                mask = sight.outputs["Dot"]
            elif style == 'CROSS':
                mask = sight.outputs["Crosshair"]
            else:
                mask = math('MAXIMUM', sight.outputs["Dot"], sight.outputs["Ring"], X_DEC, Y_TOP, sight_nodes)
            # camera rays only: a projected reticle is seen by the eye, it is not reflected by the far lens
            path = at(new("ShaderNodeLightPath"), x_sight, Y_TOP - 330, sight_nodes)
            mask = math('MULTIPLY', mask, path.outputs["Is Camera Ray"], X_DEC, Y_TOP - 170, sight_nodes)
            light = at(new("ShaderNodeEmission"), x_s1, Y_TOP, shader_nodes)
            light.name = RETICLE_NODE_NAME
            light.label = "Reticle Light"
            light.inputs["Color"].default_value = tuple(settings.reticle_color) + (1.0,)
            light.inputs["Strength"].default_value = settings.reticle_brightness
            glow = at(new("ShaderNodeMixShader"), x_s2, Y_TOP, shader_nodes)   # empty input 1: mask * light
            glow.label = "Reticle"
            links.new(mask, glow.inputs[0])
            links.new(light.outputs[0], glow.inputs[2])
            add = at(new("ShaderNodeAddShader"), x_s3, Y_TOP, shader_nodes)
            add.label = "Glass + Reticle"
            links.new(surface, add.inputs[0])
            links.new(glow.outputs[0], add.inputs[1])
            surface = add.outputs[0]
        links.new(surface, out.inputs["Surface"])
        tip_text = ("Tip: set the reticle color and size in the CoD tab (N) or on the Reticle Light node"
                    if reticle else "Tip: Lens Reflection sets how mirror-like the glass is")

    for node in maps + sight_nodes + shader_nodes:
        _hide_unused(node, inputs=node.type not in ('GROUP', 'RGB', 'VALUE', 'EMISSION', 'BSDF_GLOSSY'))
    shader_nodes.append(out)
    if maps:
        _frame(nt, "1 · Lens maps (from Saluki)", "tex", maps)
    if sight_nodes:
        _frame(nt, "2 · Sight (reticle + zoom)", "decode", sight_nodes)
    _frame(nt, "3 · Shader", "shader", shader_nodes)
    tip = new("NodeFrame")
    tip.label = tip_text
    tip.label_size = 18
    tip.use_custom_color = True
    tip.color = FRAME_COLORS["tip"]
    tip.shrink = False
    tip.location = (X_TEX, Y_TOP + 150)
    tip.width = out.location.x + 200 - X_TEX
    tip.height = 70

    if kind != 'RETICLE' and nt.nodes.get(SIGHT_NODE_NAME) is not None:
        _add_sight_axis_modifier(mat)
    if kind == 'LENS' and "ads_scope_lens_reflection" in mat.name.lower():
        # the game's fake-reflection overlay is the same mesh as the scope surface; coincident layers make
        # Cycles skip the portal on random triangles, so keep the overlay out of camera rays (the real
        # eyepiece glass in front already reflects)
        for ob, _ in _material_polygons(mat):
            if not any(s.material is not None and sight_kind(s.material.name) == 'SCOPE' for s in ob.material_slots):
                ob.visible_camera = False
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = 'BLENDED'
    elif hasattr(mat, "blend_method"):
        mat.blend_method = 'BLEND'
    mat.use_backface_culling = False
    mat["cod_shaded"] = True
    mat["cod_kind"] = kind
    mat["cod_metal_mask"] = 0.0


def _material_image_paths(mat):
    if not mat.node_tree:
        return
    for node in mat.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image and node.image.filepath:
            yield os.path.normpath(bpy.path.abspath(node.image.filepath))


def _model_dir_for(path):
    p = os.path.dirname(path)
    for _ in range(8):
        if os.path.isdir(os.path.join(p, "_mat_info")):
            return p
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    return None


def find_info(mat, index):
    paths = list(_material_image_paths(mat))
    for p in paths:
        d = _model_dir_for(p)
        if d:
            index.add_model_dir(d)
    info = index.by_name.get(_norm_name(mat.name))
    if info is None:
        for p in paths:
            info = index.by_albedo.get(os.path.basename(p).lower())
            if info:
                break
    return info


def _rig_materials(mat):
    """Materials on the same rig as `mat`: texture-less lens materials find their export folder through them."""
    parents = {ob.parent for ob, _ in _material_polygons(mat) if ob.parent is not None}
    return {s.material for ob in bpy.data.objects if ob.parent in parents
            for s in getattr(ob, "material_slots", ()) if s.material is not None and s.material != mat}


def shade_materials(mats, settings, report, model_dirs=()):
    """model_dirs: export folders the materials came from (the imported .cast files' folders)."""
    index = ModelIndex()
    if settings.search_folder:
        root = bpy.path.abspath(settings.search_folder)
        if os.path.isdir(root):
            index.add_root(root)
    # index every model folder first: materials without image nodes (scope lenses, reticle stencils) are then
    # found by name, whatever order they come in
    for d in model_dirs:
        if os.path.isdir(os.path.join(d, "_mat_info")):
            index.add_model_dir(d)
    for mat in mats:
        if mat is None or mat.library is not None:
            continue
        paths = list(_material_image_paths(mat))
        if not paths and sight_kind(mat.name):
            paths = [q for m in _rig_materials(mat) for q in _material_image_paths(m)]
        for path in paths:
            d = _model_dir_for(path)
            if d:
                index.add_model_dir(d)
    done, hair, missing = 0, 0, []
    clear_techsets = _clear_techsets(index) if settings.sight_shader else set()
    for mat in mats:
        if mat is None or mat.library is not None:
            continue
        info = find_info(mat, index)
        sight = sight_kind(mat.name) if settings.sight_shader else None
        if (sight is None and info is not None and info.techset in clear_techsets
                and classify(info.name, resolve_slots(info), info.image_names) != 'TEARFILM'
                and _is_untextured(info, resolve_slots(info))):
            sight = 'LENS'          # a see-through shell with no art of its own: watch crystal, visor, cover
        if sight:
            # lenses, scope surfaces and reticle stencils shade by name; the stencil has no textures at all
            slots = resolve_slots(info) if info else {}
            build_sight_material(mat, sight, slots, info, settings)
            done += 1
            continue
        if info is None:
            missing.append(mat.name)
            continue
        slots = resolve_slots(info)
        if not slots["cs"] and not slots["nog"]:
            missing.append(mat.name)
            continue
        build_material(mat, slots, settings, settings.metal_mode, info.image_names)
        done += 1
        if mat.get("cod_kind") == 'HAIR':
            hair += 1
    cycles = getattr(bpy.context.scene, "cycles", None)
    if hair and cycles is not None and cycles.transparent_max_bounces < HAIR_TRANSPARENT_BOUNCES:
        # layered alpha cards go black past the transparent bounce limit (default 8)
        cycles.transparent_max_bounces = HAIR_TRANSPARENT_BOUNCES
        report({'INFO'}, "CoD AutoShader: raised Cycles transparent bounces to %d for hair cards"
               % HAIR_TRANSPARENT_BOUNCES)
    if missing:
        report({'WARNING'}, "CoD AutoShader: no _mat_info match for %d material(s): %s%s" % (
            len(missing), ", ".join(missing[:5]), " ..." if len(missing) > 5 else ""))
    report({'INFO'}, "CoD AutoShader: shaded %d material(s)" % done)
    return done


# --------------------------------------------------------------------------------------------
# Bodycam look (compositor)
# --------------------------------------------------------------------------------------------
# Bodycam-style footage: a wide lens with barrel distortion, rainbow fringes and smeared edges; blown-out
# auto exposure with bloom; a flat, warm grade; digital sharpening and sensor noise. Built as one compositor
# node group inserted before the output, so every slider stays live (Blender 5.0+ node-group compositor).

BODYCAM_GROUP_NAME = "CoD Bodycam Look"
BODYCAM_GROUP_VERSION = 1
BODYCAM_NODE_NAME = "CoD Bodycam"
# (socket, panel, default, min, max, tooltip)
BODYCAM_PARAMS = (
    ("Fisheye", "Lens", 0.6, 0.0, 1.0, "Wide-angle fisheye: straight lines bow outward, the center is magnified"),
    ("Chromatic Aberration", "Lens", 0.6, 0.0, 1.0, "Rainbow color fringes toward the edges"),
    ("Edge Blur", "Lens", 0.5, 0.0, 1.0, "Soft, smeared edges around a sharp center"),
    ("Vignette", "Lens", 0.45, 0.0, 1.0, "Darker corners"),
    ("Exposure", "Light", 0.2, -3.0, 3.0, "Brighter, blown-out auto exposure (in stops)"),
    ("Bloom", "Light", 0.4, 0.0, 1.0, "Glow around lights, windows and sky"),
    ("Contrast", "Color", 0.3, -1.0, 1.0, "Harder (+) or flatter (-) image"),
    ("Saturation", "Color", 0.75, 0.0, 2.0, "Washed-out (< 1) or punchy (> 1) color"),
    ("Warmth", "Color", 0.1, -1.0, 1.0, "Warm (+) or cool (-) camera white balance"),
    ("Sharpen", "Camera", 0.35, 0.0, 1.0, "The digital sharpening of cheap body cameras"),
    ("Grain", "Camera", 0.3, 0.0, 1.0, "Animated sensor noise, strongest in the dark"),
)
BODYCAM_PRESETS = {
    'DAY': {p[0]: p[2] for p in BODYCAM_PARAMS},
    'NIGHT': dict({p[0]: p[2] for p in BODYCAM_PARAMS}, Exposure=1.0, Bloom=0.8, Contrast=0.3, Saturation=0.45,
                  Warmth=-0.1, Sharpen=0.2, Grain=0.75),
}


def _menu(node, socket, *values):
    """Set a menu socket (Blender 5 compositor) to the first value it accepts."""
    for v in values:
        try:
            node.inputs[socket].default_value = v
            return
        except (TypeError, KeyError):
            continue


def get_bodycam_group():
    name = "%s v%d" % (BODYCAM_GROUP_NAME, BODYCAM_GROUP_VERSION)
    ng = bpy.data.node_groups.get(name)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(name, "CompositorNodeTree")
    iface = ng.interface
    _socket(iface, "Image", "OUTPUT", "NodeSocketColor")
    _socket(iface, "Image", "INPUT", "NodeSocketColor")
    panels = {}
    for sock, panel, default, lo, hi, desc in BODYCAM_PARAMS:
        if panel not in panels:
            panels[panel] = iface.new_panel(panel)
        _socket(iface, sock, "INPUT", "NodeSocketFloat", default, lo, hi, desc, parent=panels[panel])

    b = _Builder(ng)
    nodes, link = ng.nodes, ng.links.new
    gi = nodes.new("NodeGroupInput")
    gi.location = (-1400, 0)
    go = nodes.new("NodeGroupOutput")
    go.location = (5100, 0)
    inp = gi.outputs

    def node(tid, loc, **values):
        n = nodes.new(tid)
        n.location = loc
        for key, v in values.items():
            b._feed(n.inputs[key.replace("_", " ")], v)
        return n

    def mix(blend, fac, a, c, loc):
        m = nodes.new("ShaderNodeMix")
        m.data_type = 'RGBA'
        m.blend_type = blend
        m.location = loc
        b._feed(m.inputs[0], fac)
        b._feed(m.inputs[6], a)
        b._feed(m.inputs[7], c)
        return m.outputs[2]

    def smooth(value, lo, hi, loc):
        mr = nodes.new("ShaderNodeMapRange")
        mr.interpolation_type = 'SMOOTHSTEP'
        mr.location = loc
        link(value, mr.inputs[0])
        mr.inputs[1].default_value = lo
        mr.inputs[2].default_value = hi
        return mr.outputs[0]

    # sensor: auto exposure pushed into the highlights, then bloom
    exposure = node("CompositorNodeExposure", (-1100, 0), Image=inp["Image"], Exposure=inp["Exposure"])
    glare = node("CompositorNodeGlare", (-850, 0), Image=exposure.outputs[0], Threshold=1.0, Smoothness=0.4,
                 Strength=b.math("MULTIPLY", inp["Bloom"], 0.6, loc=(-1100, -250)), Size=0.55)
    _menu(glare, "Type", "Bloom", "Fog Glow")
    _menu(glare, "Quality", "Medium")

    # lens: rectilinear -> fisheye remap. Corners stay put, the center is magnified and the edges squeezed
    # (radius r maps to tan(k r) / (k r)); red and blue sample at slightly different scales for color fringes
    # that grow toward the edges. Then blur toward the edges and a vignette.
    src = glare.outputs["Image"]
    coords = node("CompositorNodeImageCoordinates", (-550, -350), Image=src)
    info = node("CompositorNodeImageInfo", (-550, -550), Image=src)
    size = nodes.new("ShaderNodeSeparateXYZ")
    size.location = (-350, -550)
    link(info.outputs["Resolution"], size.inputs[0])
    aspect = b.math("DIVIDE", b.math("MINIMUM", size.outputs[0], size.outputs[1], loc=(-200, -520)),
                    b.math("MAXIMUM", size.outputs[0], size.outputs[1], loc=(-200, -620)), loc=(-50, -560))
    corner = b.math("SQRT", b.math("MULTIPLY_ADD", aspect, aspect, 1.0, loc=(100, -560)), loc=(250, -560))
    radius = b.vmath("LENGTH", coords.outputs["Uniform"], loc=(-350, -350)).node.outputs["Value"]
    k_corner = b.math("MAXIMUM", b.math("MULTIPLY", inp["Fisheye"], 1.3, loc=(-350, -750)), 1e-4, loc=(-200, -750))
    k = b.math("DIVIDE", k_corner, corner, loc=(400, -700))
    x = b.math("MAXIMUM", b.math("MULTIPLY", k, radius, loc=(550, -650)), 1e-4, loc=(700, -650))
    tan_ratio = b.math("DIVIDE", b.math("TANGENT", x, loc=(850, -600)), x, loc=(1000, -650))
    corner_ratio = b.math("DIVIDE", b.math("TANGENT", k_corner, loc=(850, -800)), k_corner, loc=(1000, -800))
    scale = b.math("DIVIDE", tan_ratio, corner_ratio, loc=(1150, -700))
    fringe = b.math("MULTIPLY", b.math("MULTIPLY", radius, radius, loc=(1000, -950)),
                    b.math("MULTIPLY", inp["Chromatic Aberration"], 0.012, loc=(1000, -1100)), loc=(1150, -1000))
    centered = b.vmath("SUBTRACT", coords.outputs["Normalized"], (0.5, 0.5, 0.0), loc=(1150, -400))
    channels = []
    for i, sign in enumerate((1.0, 0.0, -1.0)):          # red outward, green on the lens, blue inward
        channel_scale = b.math("MULTIPLY", scale, b.math("MULTIPLY_ADD", fringe, sign, 1.0, loc=(1300, -700 - i * 150)),
                               loc=(1450, -700 - i * 150))
        uv = b.vmath("ADD", b.vmath("SCALE", centered, scale=channel_scale, loc=(1600, -400 - i * 200)),
                     (0.5, 0.5, 1.0), loc=(1750, -400 - i * 200))           # Map UV reads z as the mask
        remap = node("CompositorNodeMapUV", (1900, -300 - i * 250), Image=src, UV=uv)
        _menu(remap, "Extension X", "Extend")
        _menu(remap, "Extension Y", "Extend")
        split = nodes.new("CompositorNodeSeparateColor")
        split.location = (2100, -300 - i * 250)
        link(remap.outputs[0], split.inputs[0])
        channels.append(split)
    lens = nodes.new("CompositorNodeCombineColor")
    lens.location = (2300, -500)
    for i, split in enumerate(channels):
        link(split.outputs[i], lens.inputs[i])
    link(channels[1].outputs[3], lens.inputs[3])
    blur_size = node("CompositorNodeRelativeToPixel", (2300, -150), Image=lens.outputs[0])
    blur_size.data_type = 'VECTOR'
    blur_size.reference_dimension = 'Greater'
    rel = b.math("MULTIPLY", inp["Edge Blur"], 0.012, loc=(2100, -50))
    link(b.vmath("SCALE", (1.0, 1.0, 0.0), scale=rel, loc=(2200, -100)), _live_socket(blur_size.inputs, "Value"))
    blur = node("CompositorNodeBlur", (2500, -150), Image=lens.outputs[0],
                Size=_live_socket(blur_size.outputs, "Value"))
    _menu(blur, "Type", "Fast Gaussian", "Gaussian")
    soft = mix('MIX', smooth(radius, 0.3, 1.05, (2500, -400)), lens.outputs[0], blur.outputs[0], (2750, 0))
    dark = b.math("MULTIPLY", smooth(radius, 0.5, 1.2, (2750, -400)), inp["Vignette"], loc=(2950, -400))
    vignetted = mix('MULTIPLY', 1.0, soft, b.math("SUBTRACT", 1.0, dark, loc=(3100, -400)), (3150, 0))

    # grade: flat, washed-out, warm
    huesat = node("CompositorNodeHueSat", (3400, 0), Image=vignetted, Saturation=inp["Saturation"])
    contrast = node("CompositorNodeBrightContrast", (3600, 0), Image=huesat.outputs[0],
                    Contrast=b.math("MULTIPLY", inp["Contrast"], 40.0, loc=(3400, -250)))
    balance = node("CompositorNodeCombineColor", (3600, -300),
                   Red=b.math("MULTIPLY_ADD", inp["Warmth"], 0.12, 1.0, loc=(3400, -400)),
                   Green=b.math("MULTIPLY_ADD", inp["Warmth"], 0.03, 1.0, loc=(3400, -550)),
                   Blue=b.math("MULTIPLY_ADD", inp["Warmth"], -0.15, 1.0, loc=(3400, -700)))
    warm = mix('MULTIPLY', 1.0, contrast.outputs[0], balance.outputs[0], (3800, 0))

    # camera: digital sharpening and animated sensor noise, stronger in the shadows
    sharpen = node("CompositorNodeFilter", (4050, 0), Image=warm,
                   Factor=b.math("MULTIPLY", inp["Sharpen"], 0.6, loc=(3850, -250)))
    _menu(sharpen, "Type", "Diamond Sharpen", "Box Sharpen")
    pixel = node("CompositorNodeImageCoordinates", (4050, -350), Image=sharpen.outputs[0])
    frame = nodes.new("CompositorNodeSceneTime")
    frame.location = (4050, -550)
    noise = nodes.new("ShaderNodeTexWhiteNoise")
    noise.noise_dimensions = '4D'
    noise.location = (4250, -350)
    link(pixel.outputs["Pixel"], noise.inputs["Vector"])
    link(frame.outputs["Frame"], noise.inputs["W"])
    luma = node("CompositorNodeRGBToBW", (4250, -150), Image=sharpen.outputs[0])
    shadows = b.math("SUBTRACT", 1.0, b.math("MULTIPLY", luma.outputs[0], 0.6, clamp=True, loc=(4450, -150)),
                     loc=(4600, -150))
    grain = b.math("MULTIPLY", b.math("SUBTRACT", noise.outputs["Value"], 0.5, loc=(4450, -350)),
                   b.math("MULTIPLY", inp["Grain"], shadows, loc=(4600, -300)), loc=(4750, -350))
    link(mix('ADD', 0.16, sharpen.outputs[0], grain, (4850, 0)), go.inputs["Image"])
    return ng


def _compositor_tree(scene, create=False):
    """The scene's compositing node group (Blender 5.0+), created with Render Layers -> Output if asked."""
    if not hasattr(scene, "compositing_node_group"):
        return None
    tree = scene.compositing_node_group
    if tree is None and create:
        tree = bpy.data.node_groups.new("Compositing", "CompositorNodeTree")
        tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        layers = tree.nodes.new("CompositorNodeRLayers")
        layers.location = (-400, 0)
        out = tree.nodes.new("NodeGroupOutput")
        out.location = (400, 0)
        tree.links.new(layers.outputs["Image"], out.inputs[0])
        scene.compositing_node_group = tree
    return tree


def bodycam_node(scene):
    tree = _compositor_tree(scene)
    return tree.nodes.get(BODYCAM_NODE_NAME) if tree is not None else None


def set_bodycam(scene, enable):
    """Insert (or un-mute) the Bodycam Look group before the compositor output; disabling mutes it so the
    sliders are kept."""
    node = bodycam_node(scene)
    if not enable:
        if node is not None:
            node.mute = True
        return
    if node is None:
        tree = _compositor_tree(scene, create=True)
        if tree is None:            # Blender 4.x compositor: not supported
            return
        out = next((n for n in tree.nodes if n.bl_idname == 'NodeGroupOutput' and n.is_active_output),
                   next((n for n in tree.nodes if n.bl_idname == 'NodeGroupOutput'), None))
        if out is None:
            if not tree.interface.items_tree:
                tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
            out = tree.nodes.new("NodeGroupOutput")
        target = out.inputs[0]
        if target.is_linked:
            source = target.links[0].from_socket
        else:
            layers = next((n for n in tree.nodes if n.bl_idname == 'CompositorNodeRLayers'), None)
            if layers is None:
                layers = tree.nodes.new("CompositorNodeRLayers")
                layers.location = (out.location.x - 800, out.location.y)
            source = layers.outputs["Image"]
        node = tree.nodes.new("CompositorNodeGroup")
        node.node_tree = get_bodycam_group()
        node.name = BODYCAM_NODE_NAME
        node.label = "CoD Bodycam Look"
        node.width = 220
        node.location = (out.location.x, out.location.y)
        out.location.x += 320
        tree.links.new(source, node.inputs["Image"])
        tree.links.new(node.outputs["Image"], target)
    node.mute = False
    scene.render.use_compositing = True


def apply_bodycam_preset(scene, preset):
    node = bodycam_node(scene)
    if node is None:
        return
    for sock, value in BODYCAM_PRESETS[preset].items():
        if sock in node.inputs:
            node.inputs[sock].default_value = value


def _anim_play_get(self):
    rig = _anim_target(bpy.context)
    return rig is None or rig.data.pose_position == 'POSE'


def _anim_play_set(self, value):
    rig = _anim_target(bpy.context)
    if rig is not None:
        rig.data.pose_position = 'POSE' if value else 'REST'


def _bodycam_get(self):
    node = bodycam_node(self.id_data)
    return node is not None and not node.mute


def _bodycam_set(self, value):
    set_bodycam(self.id_data, value)


# --------------------------------------------------------------------------------------------
# UI / operators
# --------------------------------------------------------------------------------------------

class CoDSettings(bpy.types.PropertyGroup):
    search_folder: StringProperty(
        name="Export Folder", subtype='DIR_PATH',
        description="Only needed if textures aren't found: the Saluki export folder to search for _mat_info files")
    metal_mode: EnumProperty(
        name="Metal Mask",
        items=(('AUTO', "Auto", "Use CS alpha as metalness only when it is a bimodal mask "
                                "(BO7 stores 1.0 or other data when unused); never on skin, hair or eyes"),
               ('ON', "Always", "Always decode CS alpha as the IW metalness mask"),
               ('OFF', "Never", "Treat every material as dielectric")),
        default='AUTO')
    game: EnumProperty(
        name="Game",
        items=[(g[0], g[1], g[2] + (" - checked against your exports" if g[4] else "") +
                ". Sets the game's gloss-to-roughness curve; texture slots are detected from the export")
               for g in GAMES],
        default='BO7')
    gloss_curve: EnumProperty(
        name="Gloss Curve",
        items=(('GAME', "From Game", "Use the curve of the selected game"),
               ('WWII', "CoD WWII", "alpha = sqrt(2 / (1 + 2^(18 gloss))) - Material Advances in CoD: WWII"),
               ('AW', "CoD Advanced Warfare", "alpha = sqrt(2 / (2 + 2^(16 gloss)))"),
               ('LINEAR', "Linear", "roughness = 1 - gloss")),
        default='GAME')
    normal_strength: FloatProperty(name="Normal Strength", default=1.0, min=0.0, max=4.0,
                                   description="Bumpiness of the decoded normal maps")
    ao_strength: FloatProperty(name="AO Strength", default=1.0, min=0.0, max=1.0,
                               description="How much the baked ambient occlusion darkens the surface")
    emission_strength: FloatProperty(name="Emission Strength", default=1.0, min=0.0, max=100.0,
                                     description="Glow strength of emissive parts (lights, screens, reticles). "
                                                 "Each map is first scaled so its brightest pixel glows")
    emission_color: FloatVectorProperty(name="Emission Color", subtype='COLOR', size=3, min=0.0, max=1.0,
                                        default=(1.0, 1.0, 1.0),
                                        description="Tints the glow; white keeps the colour of the game's map")
    skin_sss: BoolProperty(name="Skin Subsurface", default=True,
                           description="Enable subsurface scattering on detected skin materials")
    sss_weight: FloatProperty(name="SSS Weight", default=0.3, min=0.0, max=1.0,
                              description="How much light scatters under the skin. Past ~0.5 thin parts like "
                                          "ears and nostrils turn into glowing wax")
    sss_scale: FloatProperty(name="SSS Scale (cm)", default=0.12, min=0.0, max=10.0,
                             description="Scatter distance in centimeters of the imported model; "
                                         "follows the object's scale, so a rig scaled to 0.01 stays correct")
    hair_shader: BoolProperty(name="Hair Shader", default=True,
                              description="Shade hair cards with anisotropic R/TRT/TT hair lobes instead of Principled "
                                          "(anisotropic highlights render in Cycles)")
    eye_parallax: BoolProperty(name="Eye Iris Depth", default=True,
                               description="Parallax the iris under the cornea like CoD's eye shader")
    eye_shadow: FloatProperty(name="Eye Lid Shadow", default=0.6, min=0.0, max=1.0,
                              description="Darkening of the eyeball near the lids from the eye mid-shadow shell")
    skin_oil: FloatProperty(name="Skin Oil", default=0.35, min=0.0, max=1.0,
                            description="Thin film of natural skin oil over the skin: a soft sheen that follows the "
                                        "game's gloss map, so the forehead, nose and lips catch light and the "
                                        "cheeks stay matte. 0 = dry skin, 1 = sweaty")
    skin_roughness_min: FloatProperty(name="Skin Roughness Min", default=0.4, min=0.0, max=1.0,
                                      description="Remaps skin roughness into [min, 1]; Principled has no "
                                                  "dual-lobe skin specular, so raw CoD skin gloss looks wet")
    sight_shader: BoolProperty(name="Sights", default=True,
                               description="Shade lenses as glass, red dots with a collimated reticle and scopes as "
                                           "a magnified picture-in-picture (Cycles)")
    red_dot_reticle: BoolProperty(name="Red Dot Reticle", default=True,
                                  description="Draw a reticle on red dot / holographic lenses that stays on the aim "
                                              "point when the head moves, like in game")
    reticle_style: EnumProperty(
        name="Reticle",
        items=(('CIRCLE_DOT', "Circle Dot", "Holographic circle with a center dot"),
               ('DOT', "Dot", "Single red dot"),
               ('CROSS', "Cross", "Fine crosshair")),
        default='CIRCLE_DOT')
    reticle_color: FloatVectorProperty(name="Reticle Color", subtype='COLOR', size=3, min=0.0, max=1.0,
                                       default=(1.0, 0.06, 0.2), description="Color of the red dot reticle")
    reticle_brightness: FloatProperty(name="Reticle Brightness", default=12.0, min=0.0, max=200.0,
                                      description="Emission strength of the red dot reticle")
    reticle_size: FloatProperty(name="Circle Size", default=1.2, min=0.1, max=10.0,
                                description="Radius of the reticle circle in degrees of view")
    scope_zoom: FloatProperty(name="Scope Zoom", default=4.0, min=1.0, max=40.0,
                              description="Magnification of the scope picture-in-picture (renders in Cycles)")
    anim_align_sight: BoolProperty(name="Line Up Sight", default=True,
                                   description="ADS clips put the mounted scope / red dot in the middle of the view, "
                                               "like the game does for each optic")
    anim_folder: StringProperty(name="Animations Folder", subtype='DIR_PATH',
                                description="Only needed if the weapon's animations aren't found: the Saluki "
                                            "animations folder")
    anim_play: BoolProperty(name="Animations", get=_anim_play_get, set=_anim_play_set,
                            description="Play the rig's animations; off shows its rest pose without deleting anything")
    anim_face: BoolProperty(name="Face Animation", default=True,
                            description="Also add the matching facial clip (facial_idle / facial_aim / "
                                        "facial_angry ...) from the export, on its own Face layer")
    anim_recoil: FloatProperty(name="Fire Recoil", default=1.0, min=0.0, max=3.0,
                               description="Procedural gun kick added to fire clips (the game adds it on top of the "
                                           "fire animation); 0 = off")
    bodycam: BoolProperty(name="Bodycam Look", get=_bodycam_get, set=_bodycam_set,
                          description="Bodycam-game camera look in the compositor: fisheye lens, color fringes, "
                                      "blown-out exposure, bloom, sharpening and sensor noise")


class COD_OT_bodycam_preset(bpy.types.Operator):
    bl_idname = "cod.bodycam_preset"
    bl_label = "Bodycam Preset"
    bl_description = "Add the Bodycam look to the compositor (if needed) and load a preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: EnumProperty(items=(('DAY', "Day", "Bright, blown-out daylight footage"),
                                ('NIGHT', "Night", "Dark, noisy night footage")), default='DAY')

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, "compositing_node_group")

    def execute(self, context):
        set_bodycam(context.scene, True)
        apply_bodycam_preset(context.scene, self.preset)
        return {'FINISHED'}


def _selected_materials(context):
    mats = []
    for ob in context.selected_objects:
        for slot in getattr(ob, "material_slots", []):
            if slot.material and slot.material not in mats:
                mats.append(slot.material)
    return mats


class COD_OT_shade_selected(bpy.types.Operator):
    bl_idname = "cod.shade_selected"
    bl_label = "Shade Selected"
    bl_description = "Build CoD materials for every material on the selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mats = _selected_materials(context)
        if not mats:
            self.report({'WARNING'}, "Select the imported meshes first")
            return {'CANCELLED'}
        shade_materials(mats, context.scene.cod_autoshader, self.report)
        return {'FINISHED'}


class COD_OT_shade_all(bpy.types.Operator):
    bl_idname = "cod.shade_all"
    bl_label = "Shade All"
    bl_description = "Build CoD materials for every material in the file that has a Saluki _mat_info"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        shade_materials(list(bpy.data.materials), context.scene.cod_autoshader, self.report)
        return {'FINISHED'}


class COD_OT_import_cast(bpy.types.Operator, ImportHelper):
    bl_idname = "cod.import_cast"
    bl_label = "Import Cast + Shade"
    bl_description = "Import .cast models with the Cast importer, then build CoD materials"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".cast"
    filter_glob: StringProperty(default="*.cast", options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    merge: BoolProperty(name="Merge Into Selected Rig", default=False,
                        description="Join what you import into the armature that is selected, reusing the bones "
                                    "they share (heads, hair, gear, attachments) - like the Cast importer's "
                                    "Import Merge. Heads find their body on their own either way")

    def execute(self, context):
        if not _cast_importer_ready():
            self.report({'ERROR'}, "Cast importer (io_scene_cast) is not enabled")
            return {'CANCELLED'}
        paths = [os.path.join(self.directory, f.name) for f in self.files if f.name] or [self.filepath]
        target = _selected_rig(context) if self.merge else None
        before = set(bpy.data.materials)
        before_objs = set(bpy.data.objects)
        for p in paths:
            bpy.ops.import_scene.cast(filepath=p)
        fresh = [o for o in bpy.data.objects if o not in before_objs and o.type == 'ARMATURE']
        if fresh:
            if context.object is not None and context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            if target is not None and target.name in bpy.data.objects:
                merge_into_rig(target, fresh, self.report)
            else:
                if self.merge:
                    self.report({'WARNING'}, "CoD AutoShader: select the rig to merge into first")
                attach_heads([o for o in context.view_layer.objects if o.type == 'ARMATURE'], self.report)
        new = [m for m in bpy.data.materials if m not in before]
        shade_materials(new, context.scene.cod_autoshader, self.report,
                        model_dirs=[os.path.dirname(p) for p in paths])
        return {'FINISHED'}


# --------------------------------------------------------------------------------------------
# Viewmodel assembly (arms + weapon parts in one rig)
# --------------------------------------------------------------------------------------------
# Verified on BO7's sat_vm_sn_aden_reload: with the receiver root j_gun pinned to the arms'
# tag_weapon (zero offset) and the anim's own j_gun keys ignored (they duplicate tag_weapon_right),
# the left hand stays on the gun's tag_ik_loc_le within 0.5 cm for the whole reload and the right
# hand returns exactly to tag_ik_loc_ri. Attachments root on same-named receiver tags
# (tag_barrel_attach, tag_mag_attach, tag_scope, ...).

VM_GUN_ROOT = "j_gun"
VM_ANCHORS = ("tag_weapon", "tag_weapon_right")      # first one found on the arms wins
VM_CONSTRAINT = "CoD: gun follows " + VM_ANCHORS[0]


def _root_bone(arm):
    return next((b for b in arm.data.bones if b.parent is None), None)


def _is_arms(arm):
    bones = arm.data.bones
    # viewmodel arms carry the eye (tag_view); third-person bodies share tag_weapon_right and wrists but have
    # legs and no view bone
    return (any(a in bones for a in VM_ANCHORS) and ("j_wrist_ri" in bones or "j_wrist_le" in bones)
            and ("tag_view" in bones or "j_knee_le" not in bones))


def _edit_mode(obj):
    for o in list(bpy.context.view_layer.objects):
        if o is not None:                   # entries can be stale right after objects are removed
            o.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    return obj.data.edit_bones


def _merge_armature(target, source, attach_to=None):
    """Move source's bones and meshes into target. The source root reuses a same-named target bone,
    or is created under attach_to with zero offset. Works in native Cast units (armature space), like
    the Cast importer's own merge, so a rig scaled to meters still takes a centimeter weapon."""
    src_root = _root_bone(source)
    src_rest = {b.name: b.matrix_local.copy() for b in source.data.bones}
    src_parent = {b.name: (b.parent.name if b.parent else None) for b in source.data.bones}
    meshes = [c for c in source.children if c.type == 'MESH']
    mesh_world = {m.name: m.matrix_world.copy() for m in meshes}
    src_inv = source.matrix_world.inverted()

    eb = _edit_mode(target)
    if src_root.name not in eb:
        if attach_to is None or attach_to not in eb:
            bpy.ops.object.mode_set(mode='OBJECT')
            return False
        eb.new(src_root.name)
        new = eb[src_root.name]             # re-fetch: edit bone references go stale after .new()
        new.tail = (0.0, 0.0025, 0.0)
        new.parent = eb[attach_to]
        new.matrix = eb[attach_to].matrix.copy()
    T = eb[src_root.name].matrix @ src_rest[src_root.name].inverted()

    pending = [n for n in src_rest if n != src_root.name]
    while pending:
        progressed = False
        for name in list(pending):
            parent = src_parent[name]
            if parent is not None and parent not in eb:
                continue
            if name not in eb:
                eb.new(name)
                bone = eb[name]
                bone.tail = (0.0, 0.0025, 0.0)
                bone.parent = eb[parent] if parent else None
                bone.matrix = T @ src_rest[name]
            pending.remove(name)
            progressed = True
        if not progressed:
            break
    bpy.ops.object.mode_set(mode='OBJECT')

    home = target.users_collection[0] if target.users_collection else bpy.context.scene.collection
    for m in meshes:
        m.data.transform(T @ src_inv @ mesh_world[m.name])
        m.parent = target
        m.matrix_parent_inverse.identity()
        m.matrix_world = target.matrix_world.copy()
        for mod in m.modifiers:
            if mod.type == 'ARMATURE':
                mod.object = target
        for col in list(m.users_collection):
            col.objects.unlink(m)
        home.objects.link(m)

    old_cols = list(source.users_collection)
    bpy.data.objects.remove(source, do_unlink=True)
    for col in old_cols:
        if col is not bpy.context.scene.collection and not col.objects and not col.children:
            bpy.data.collections.remove(col)
    bpy.context.view_layer.update()
    return True


# ---- third person: heads ride on bodies --------------------------------------------------------------------
# A CoD character is a body model plus a separate head model. The head's skeleton starts at j_spine4 and the
# engine bolts it onto the body's j_spine4, so imported on its own it sits at the origin (on the floor) and does
# not follow the body's animation. Merging it into the body reuses the shared neck / head bones.

def _is_body(arm):
    bones = arm.data.bones
    return "j_mainroot" in bones and "j_spine4" in bones and not _is_arms(arm)


def _is_head(arm):
    bones = arm.data.bones
    root = _root_bone(arm)
    return ("j_head" in bones and "j_mainroot" not in bones and root is not None and root.name in bones
            and not _is_arms(arm))


def _model_key(name):
    name = re.sub(r"(_lod\d+)?(\.\d{3})?$", "", name.lower())
    return re.sub(r"^(head|body)_", "", name)


def _selected_rig(context):
    """The armature the user has selected (or the one a selected mesh belongs to)."""
    for ob in [context.object] + list(context.selected_objects):
        if ob is None:
            continue
        if ob.type == 'ARMATURE':
            return ob
        if ob.parent is not None and ob.parent.type == 'ARMATURE':
            return ob.parent
    return None


def merge_into_rig(target, armatures, report):
    """Join imported rigs into `target`: shared bones are reused, the rest are added under their parent (or the
    target's root if the model starts somewhere else). Returns the number merged."""
    merged = 0
    root = _root_bone(target)
    for rig in armatures:
        if rig is target or rig.name not in bpy.data.objects:
            continue
        source_root = _root_bone(rig)
        if source_root is None:
            continue
        name = rig.name
        attach = None if source_root.name in target.data.bones else (root.name if root else None)
        if _merge_armature(target, rig, attach_to=attach):
            merged += 1
            report({'INFO'}, "CoD AutoShader: merged %s into %s" % (name, target.name))
        else:
            report({'WARNING'}, "CoD AutoShader: %s has no bone in common with %s" % (name, target.name))
    if merged:
        for ob in bpy.context.view_layer.objects:
            ob.select_set(ob == target)
        bpy.context.view_layer.objects.active = target
    return merged


def attach_heads(armatures, report):
    """Merge every head rig into the body it belongs to (best name match). Returns the number attached."""
    bodies = [a for a in armatures if _is_body(a)]
    heads = [a for a in armatures if _is_head(a)]
    attached = 0
    for head in heads:
        key = _model_key(head.name)

        def match(body):
            other = _model_key(body.name)
            n = 0
            while n < min(len(key), len(other)) and key[-1 - n] == other[-1 - n]:
                n += 1
            return n
        body = max(bodies, key=match, default=None)
        if body is None or _root_bone(head).name not in body.data.bones:
            continue
        name = head.name
        if _merge_armature(body, head):
            attached += 1
            report({'INFO'}, "CoD AutoShader: attached %s to %s" % (name, body.name))
    return attached


def _pin_gun(arms, anchor):
    """j_gun follows the anchor tag no matter what the animation keys on j_gun."""
    pb = arms.pose.bones.get(VM_GUN_ROOT)
    if pb is None:
        return
    for c in list(pb.constraints):
        if c.name.startswith("CoD: gun follows"):
            pb.constraints.remove(c)
    con = pb.constraints.new('COPY_TRANSFORMS')
    con.name = "CoD: gun follows " + anchor
    con.target = arms
    con.subtarget = anchor
    con.target_space = 'WORLD'
    con.owner_space = 'WORLD'


def assemble_viewmodel(armatures, report):
    """Arms + receiver + attachments -> one rig. Returns the rig."""
    armatures = [a for a in armatures if a is not None and a.type == 'ARMATURE']
    arms = next((a for a in armatures if _is_arms(a)), None)
    receiver = next((a for a in armatures if a is not arms and _root_bone(a) and _root_bone(a).name == VM_GUN_ROOT), None)
    if arms is None and receiver is None:
        report({'WARNING'}, "CoD AutoShader: select the VM arms and/or the weapon receiver (root bone j_gun)")
        return None
    # third person: a character body takes the gun on its own j_gun (right hand), which its animations drive
    body = next((a for a in armatures if _is_body(a)), None) if arms is None else None
    rig = arms or body or receiver
    if bpy.context.object is not None and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    anchor = None
    if arms is not None:
        anchor = next(a for a in VM_ANCHORS if a in arms.data.bones)
        eb = _edit_mode(arms)
        if VM_GUN_ROOT in eb:
            # the arms carry a j_gun placeholder under the shoulder; the game drives the gun from tag_weapon
            eb[VM_GUN_ROOT].parent = eb[anchor]
            eb[VM_GUN_ROOT].matrix = eb[anchor].matrix.copy()
        bpy.ops.object.mode_set(mode='OBJECT')
        if receiver is not None:
            _merge_armature(arms, receiver, attach_to=anchor)
    elif body is not None and receiver is not None:
        for key in ("cod_weapon", "cod_weapon_pnum", "cod_weapon_family", "cod_anim_dir"):
            if receiver.get(key) is not None:
                body[key] = receiver[key]
        _rig_folder_cache.pop(body.name, None)
        _merge_armature(body, receiver, attach_to="tag_weapon_right")

    merged = []
    rest = [a for a in armatures if a is not rig and a is not receiver]
    while rest:
        progressed = False
        for att in list(rest):
            root = _root_bone(att)
            if root is not None and root.name in rig.data.bones:
                name = att.name
                if _merge_armature(rig, att):
                    merged.append(name)
                rest.remove(att)
                progressed = True
        if not progressed:
            break

    if arms is not None and VM_GUN_ROOT in arms.data.bones:
        _pin_gun(arms, anchor)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig

    msg = "CoD AutoShader: assembled %s (%s%d attachment%s)" % (
        "character" if body is not None else "viewmodel",
        "arms + gun, " if arms and receiver else "body + gun, " if body is not None and receiver else "",
        len(merged), "" if len(merged) == 1 else "s")
    if rest:
        msg += "; no matching tag for: " + ", ".join(a.name for a in rest)
        report({'WARNING'}, msg)
    else:
        report({'INFO'}, msg)
    return rig


class COD_OT_assemble_vm(bpy.types.Operator):
    bl_idname = "cod.assemble_vm"
    bl_label = "Assemble Viewmodel"
    bl_description = ("Join selected VM arms, weapon receiver and attachments into one rig: the gun is pinned to the "
                      "arms' tag_weapon and attachments snap to their receiver tags, so animations keep it in the "
                      "hands. A selected third-person head is attached to its body")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'ARMATURE' for o in context.selected_objects)

    def execute(self, context):
        selected = [o for o in context.selected_objects if o.type == 'ARMATURE']
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        names = [o.name for o in selected]
        heads = attach_heads(selected, self.report)
        remaining = [bpy.data.objects[n] for n in names if n in bpy.data.objects]    # merged heads are gone
        if heads and not any(_is_arms(o) or (_root_bone(o) and _root_bone(o).name == VM_GUN_ROOT) for o in remaining):
            return {'FINISHED'}
        rig = assemble_viewmodel(remaining, self.report)
        return {'FINISHED'} if rig or heads else {'CANCELLED'}


def _weapon_part_paths(path):
    """Saluki puts each weapon part in its own folder (sat_vm_sn_aden_rec, sat_vm_sn_aden_bar, ...).
    From one part, find its siblings sharing the name prefix, LOD0 only."""
    folder = os.path.dirname(path)
    base = os.path.basename(folder)
    # MWII-era part folders end in a variant tag: att_vm_p21_sn_mromeo_rec_v0, ..._mag_v35
    variant = re.search(r"_v\d+$", base)
    stem = base[:variant.start()] if variant else base
    if "_" not in stem:
        return [path]
    prefix = stem.rsplit("_", 1)[0] + "_"
    parts = {}                                   # part name -> {variant: cast}
    for sib in sorted(glob.glob(os.path.join(os.path.dirname(folder), glob.escape(prefix) + "*"))):
        if not os.path.isdir(sib):
            continue
        casts = sorted(glob.glob(os.path.join(sib, "*_LOD0.cast"))) or sorted(glob.glob(os.path.join(sib, "*.cast")))
        if not casts:
            continue
        name = os.path.basename(sib)
        v = re.search(r"_v\d+$", name)
        parts.setdefault(name[:v.start()] if v else name, {})[v.group(0) if v else ""] = casts[0]
    want = variant.group(0) if variant else ""
    found = [variants.get(want) or variants[sorted(variants)[0]] for _, variants in sorted(parts.items())]
    return found or [path]


class COD_OT_import_vm(bpy.types.Operator, ImportHelper):
    bl_idname = "cod.import_vm"
    bl_label = "Import Viewmodel"
    bl_description = ("Pick the weapon's receiver .cast (e.g. ..._rec_LOD0.cast): its other parts are found in the "
                      "neighbouring folders, imported, assembled onto the VM arms in the scene and shaded")
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".cast"
    filter_glob: StringProperty(default="*.cast", options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    find_parts: BoolProperty(name="Find all weapon parts", default=True,
                             description="Also import the weapon's other parts from neighbouring folders with the "
                                         "same name prefix (barrel, mag, scope, stock, ...)")

    def execute(self, context):
        if not _cast_importer_ready():
            self.report({'ERROR'}, "Cast importer (io_scene_cast) is not enabled")
            return {'CANCELLED'}
        chosen = [os.path.join(self.directory, f.name) for f in self.files if f.name] or [self.filepath]
        paths = []
        for p in chosen:
            for q in (_weapon_part_paths(p) if self.find_parts else [p]):
                if os.path.normcase(q) not in {os.path.normcase(x) for x in paths}:
                    paths.append(q)
        # VM arms already in the scene (selected first) receive the gun
        scene_arms = [o for o in context.selected_objects if o.type == 'ARMATURE' and _is_arms(o)] or \
                     [o for o in context.view_layer.objects if o.type == 'ARMATURE' and _is_arms(o)]
        before_objs, before_mats = set(bpy.data.objects), set(bpy.data.materials)
        failed = []
        for p in paths:
            if context.object is not None and context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            for o in context.view_layer.objects:
                o.select_set(False)
            context.view_layer.objects.active = None     # never let the Cast importer merge into a selection
            try:
                bpy.ops.import_scene.cast(filepath=p)
            except RuntimeError:
                failed.append(os.path.basename(p))
        if failed:
            self.report({'WARNING'}, "CoD AutoShader: could not import " + ", ".join(failed))
        new = [o for o in bpy.data.objects if o not in before_objs]
        armatures = [o for o in new if o.type == 'ARMATURE']
        if scene_arms and not any(_is_arms(a) for a in armatures):
            armatures.insert(0, scene_arms[0])
        self.report({'INFO'}, "CoD AutoShader: imported %d weapon part(s)" % len(paths))
        rig = assemble_viewmodel(armatures, self.report)
        weapon = _weapon_token(chosen[0], ("vm",))
        if rig is not None and weapon:
            rig["cod_weapon"], rig["cod_weapon_pnum"], rig["cod_weapon_family"] = weapon[:3]
            rig["cod_anim_dir"] = _find_anim_dir(chosen[0])
            _rig_folder_cache.pop(rig.name, None)
        shade_materials([m for m in bpy.data.materials if m not in before_mats], context.scene.cod_autoshader, self.report,
                        model_dirs=[os.path.dirname(p) for p in paths])
        return {'FINISHED'} if rig else {'CANCELLED'}


# --------------------------------------------------------------------------------------------
# Animation layers
# --------------------------------------------------------------------------------------------
# CoD viewmodel animations are pieces of the game's state machine: full-body clips (idle, fire, reload, ...)
# plus the ADS transition, which only moves tag_ads - the parent of the whole viewmodel under tag_view - to
# slide the gun up to the eye (MWII ads_up: 12 cm back, 7 cm to the center, 2 cm up). The Cast importer
# replaces the current action and resets every bone, so ads_up alone snaps the arms back to the bind pose.
# Here each clip becomes an NLA strip instead: full-body clips on the Base track, tag_ads clips on the ADS
# track above it (holding their last frame, so the gun stays up until ads_down), and truly additive clips
# (Cast curve mode "additive") on an Additive track in Combine mode.

ANIM_TRACK_BASE, ANIM_TRACK_UPPER = "CoD Base", "CoD Upper"
ANIM_TRACK_ADS, ANIM_TRACK_ADD, ANIM_TRACK_FACE = "CoD ADS", "CoD Additive", "CoD Face"
ANIM_TRACK_ORDER = (ANIM_TRACK_BASE, ANIM_TRACK_UPPER, ANIM_TRACK_ADS, ANIM_TRACK_ADD, ANIM_TRACK_FACE)
ADS_BONES = {"tag_ads"}
LEG_BONES = ("j_knee", "j_ankle", "j_ball", "j_hip", "j_mainroot", "j_toe")
FACE_BONES = ("j_brow", "j_jaw", "j_eye", "j_lip", "j_cheek", "j_nose", "j_chin", "j_mouth", "j_teeth",
              "j_tongue", "j_uppercheek", "j_smile", "j_frown", "j_nostril", "j_forehead", "j_temple")
# which facial_* clip goes with an action clip (the game runs a face layer alongside the body)
FACE_FOR_ACTION = ((r"melee|execution|finish", "angry"), (r"fire|shoot|recoil", "angry"),
                   (r"ads|aim|scope", "aim"), (r"sprint|run", "run"), (r"death|die", "death"),
                   (r"pain|hit|flinch", "pain"), (r"", "idle"))
EYE_BONES = ("tag_camera", "tag_cambone", "tag_view")
VM_CAMERA_NAME = "CoD Viewmodel Camera"
VM_CAMERA_LENS = 24.0            # ~74 deg horizontal, close to CoD's default viewmodel field of view


def _cast_importer_ready():
    """bpy.ops attributes always exist; only the registered operator has an RNA type."""
    try:
        bpy.ops.import_scene.cast.get_rna_type()
        return True
    except (AttributeError, KeyError):
        return False


def _cast_module():
    """The Cast importer's file reader, wherever the add-on is installed (legacy add-on or extension)."""
    import addon_utils
    import importlib
    for mod in addon_utils.modules():
        if mod.__name__.split(".")[-1] == "io_scene_cast":
            try:
                return importlib.import_module(mod.__name__ + ".cast")
            except ImportError:
                continue
    return None


OFFSET_KEY_MAX_DEG = 20.0    # a clip whose rotations (OFFSET_SHARE of its bones) stay this close to identity...
OFFSET_SHARE = 0.85          # (the trigger finger of a fire clip curls further)
OFFSET_REST_MIN_DEG = 30.0   # ...while bones it drives rest this far from identity is an additive layer


def _anim_info(path):
    """Read the clip once: {'additive': Cast additive curves, 'offsets': every rotation key within a few degrees
    of identity, 'rotated': bones with rotation keys, 'identity': bones keyed as a constant identity}.
    CoD third-person fire / 'addoff' clips are additive layers exported as absolute keys (MWII stand_fire: every
    bone within 16 deg of identity) - taken as poses they lay the body flat on its back. Constant identity keys
    in a real pose clip are bones it does not drive."""
    info = {"additive": False, "offsets": False, "rotated": set(), "identity": set()}
    cast = _cast_module()
    if cast is None:
        return info
    near = math.cos(math.radians(OFFSET_KEY_MAX_DEG) / 2.0)
    exact = math.cos(math.radians(0.2) / 2.0)
    near_count = 0
    try:
        for root in cast.Cast.load(path).Roots():
            for anim in root.ChildrenOfType(cast.Animation):
                for curve in anim.Curves():
                    info["additive"] = info["additive"] or curve.Mode() == "additive"
                    if curve.KeyPropertyName() != "rq" or curve.Mode() not in ("absolute", None):
                        continue
                    v = curve.KeyValueBuffer()
                    if not len(v):
                        continue
                    info["rotated"].add(curve.NodeName())
                    ws = [abs(v[i + 3]) for i in range(0, len(v), 4)]
                    near_count += min(ws) >= near
                    if min(ws) >= exact:
                        info["identity"].add(curve.NodeName())
                info["offsets"] = bool(info["rotated"]) and near_count >= OFFSET_SHARE * len(info["rotated"])
                return info
    except Exception:
        pass
    return info


def _rest_local(pb):
    bone = pb.bone
    local = bone.matrix_local if bone.parent is None else bone.parent.matrix_local.inverted() @ bone.matrix_local
    return local.to_quaternion()


def _rekey_rotations(rig, action, bones, as_offsets):
    """The importer keyed rotations absolute: basis = rest^-1 * key. as_offsets: re-key every listed bone as
    basis = key (an offset on top of the layer below). Otherwise drop the listed identity placeholders of bones
    that don't rest at identity, so the layer below / the rest pose shows through."""
    names = {b.lower() for b in bones}
    for pb in rig.pose.bones:
        if pb.name.lower() not in names:
            continue
        rest = _rest_local(pb)
        curves = _bone_curves(action, pb.name, "rotation_quaternion")
        if len(curves) != 4 or (not as_offsets and rest.angle < math.radians(2.0)):
            continue
        if as_offsets:
            frames = sorted({k.co[0] for k in curves[0].keyframe_points})
            values = {f: rest @ Quaternion([fc.evaluate(f) for fc in curves]) for f in frames}
            for i, fc in enumerate(curves):
                for key in fc.keyframe_points:
                    q = values.get(key.co[0])
                    if q is not None:
                        shift = q[i] - key.co[1]
                        key.co[1] += shift
                        key.handle_left[1] += shift
                        key.handle_right[1] += shift
                fc.update()
        else:
            for fc in curves:
                for layer in getattr(action, "layers", ()):
                    for strip in layer.strips:
                        for bag in getattr(strip, "channelbags", ()):
                            if fc in bag.fcurves.values():
                                bag.fcurves.remove(fc)
            pb.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)


def _is_offset_clip(rig, info):
    """All-near-identity rotations only mean 'additive' if some of those bones rest far from identity."""
    if not info["offsets"]:
        return False
    limit = math.radians(OFFSET_REST_MIN_DEG)
    return any(_rest_local(pb).angle > limit for pb in rig.pose.bones if pb.name in info["rotated"])


def _action_fcurves(action):
    if getattr(action, "layers", None):          # Blender 4.4+ layered actions
        return [fc for layer in action.layers for strip in layer.strips
                for bag in getattr(strip, "channelbags", ()) for fc in bag.fcurves]
    return list(getattr(action, "fcurves", ()))


def _action_bones(action):
    bones = set()
    for fc in _action_fcurves(action):
        m = re.match(r'pose\.bones\["(.+?)"\]', fc.data_path)
        if m:
            bones.add(m.group(1))
    return bones


def _anim_target(context):
    """The armature animations go on: the active/selected rig, a selected mesh's rig, or the only rig."""
    for ob in [context.object] + list(context.selected_objects):
        if ob is None:
            continue
        if ob.type == 'ARMATURE':
            return ob
        if ob.parent is not None and ob.parent.type == 'ARMATURE':
            return ob.parent
    rigs = [o for o in context.view_layer.objects if o.type == 'ARMATURE']
    arms = [o for o in rigs if _is_arms(o)]
    return (arms or rigs)[0] if len(arms or rigs) == 1 else None


def _nla_track(anim_data, name):
    """Get or create a named track, stacked Base < Upper < ADS < Additive < Face (bottom to top)."""
    track = anim_data.nla_tracks.get(name)
    if track is not None:
        return track
    order = ANIM_TRACK_ORDER
    below = [anim_data.nla_tracks.get(n) for n in order[:order.index(name)]]
    below = [t for t in below if t is not None]
    if name != ANIM_TRACK_BASE and not below:
        below = [_nla_track(anim_data, ANIM_TRACK_BASE)]     # the base layer always exists under the others
    track = anim_data.nla_tracks.new(prev=below[-1]) if below else anim_data.nla_tracks.new()
    track.name = name
    return track


def _layer_track(anim_data, name, start, end):
    """Additive and face clips stack: the aim offset, the fire kick and the face all run at once, so a busy
    layer gets another track above it (below the layers that come later in ANIM_TRACK_ORDER)."""
    family = [_nla_track(anim_data, name)]
    family += [t for t in anim_data.nla_tracks if t.name.startswith(name + " ")]
    for track in family:
        if not any(strip.frame_start < end and start < strip.frame_end for strip in track.strips):
            return track
    track = anim_data.nla_tracks.new(prev=family[-1])
    track.name = "%s %d" % (name, len(family) + 1)
    return track


def _stash_active_action(rig):
    """An action imported earlier the normal way (e.g. idle) becomes the first Base clip."""
    ad = rig.animation_data
    if ad is None or ad.action is None:
        return
    action = ad.action
    track = _nla_track(ad, ANIM_TRACK_BASE)
    if not any(s.action == action for s in track.strips):
        start = int(action.frame_range[0])
        if not any(s.frame_start <= start < s.frame_end for s in track.strips):
            strip = track.strips.new(action.name, start, action)
            strip.extrapolation = 'HOLD'
    ad.action = None


def _place_strip(track, action, start, scale, name, report):
    """Add a clip at `start`. A clip already playing there on this layer is cut at `start` (the new clip takes
    over, like the game switching states); clips it would run into are replaced."""
    end = start + (action.frame_range[1] - action.frame_range[0]) * scale
    for old in list(track.strips):
        if old.frame_start < start < old.frame_end:
            old.frame_end_ui = start
        elif start <= old.frame_start <= end:
            report({'INFO'}, "CoD AutoShader: %s replaces %s" % (name, old.name))
            track.strips.remove(old)
    strip = track.strips.new(name, int(start), action)
    if hasattr(strip, "action_slot") and strip.action_slot is None and len(action.slots):
        strip.action_slot = action.slots[0]
    strip.scale = scale
    strip.extrapolation = 'HOLD' if len(track.strips) == 1 else 'HOLD_FORWARD'
    return strip


def _eye_matrix(rig):
    """World matrix of the player's eye: the eye bone, looking down CoD +X with +Z up (a camera looks down -Z)."""
    bone = next((b for b in EYE_BONES if b in rig.pose.bones), None)
    if bone is None:
        return None, None
    pb = rig.pose.bones[bone]
    to_world = rig.matrix_world.to_3x3()
    forward = (to_world @ Vector((1.0, 0.0, 0.0))).normalized()
    up = (to_world @ Vector((0.0, 0.0, 1.0))).normalized()
    right = forward.cross(up).normalized()
    eye_rest = Matrix((right, (-forward).cross(right), -forward)).transposed().to_4x4()
    eye_rest.translation = rig.matrix_world @ pb.bone.head_local
    offset = (rig.matrix_world @ pb.bone.matrix_local).inverted() @ eye_rest
    eye = rig.matrix_world @ pb.matrix @ offset
    return Matrix.LocRotScale(eye.translation, eye.to_quaternion(), None), bone


def _rig_meshes(rig):
    return [o for o in bpy.data.objects if o.type == 'MESH' and not o.hide_render and not o.hide_viewport and
            (o.parent is rig or any(m.type == 'ARMATURE' and m.object is rig for m in o.modifiers))]


def _sight_point(rig, deps):
    """World center of the mounted optic: the scope's picture-in-picture surface, else a red dot's eye-side lens."""
    found = {}
    for ob in _rig_meshes(rig):
        kinds = {i: ('SCOPE' if sight_kind(sl.material.name) == 'SCOPE' else
                     'DOT' if sight_kind(sl.material.name) == 'LENS' and is_red_dot_lens(sl.material.name) else None)
                 for i, sl in enumerate(ob.material_slots) if sl.material is not None}
        if not any(kinds.values()):
            continue
        ev = ob.evaluated_get(deps)
        me = ev.to_mesh()
        for p in me.polygons:
            kind = kinds.get(p.material_index)
            if kind:
                found.setdefault(kind, []).append(ob.matrix_world @ p.center)
        ev.to_mesh_clear()
    pts = found.get('SCOPE') or found.get('DOT')
    return sum(pts, Vector()) / len(pts) if pts else None


def _bone_curves(action, bone, prop):
    path = 'pose.bones["%s"].%s' % (bone, prop)
    return sorted((fc for fc in _action_fcurves(action) if fc.data_path == path), key=lambda fc: fc.array_index)


def _align_ads_clip(context, rig, strip, report):
    """The engine lines each optic up with the eye at full ADS; the tag_ads clip alone is generic (MWII MCPR:
    scope 1.5 cm high). Offset the clip's tag_ads path, scaled by how far into ADS each frame is, so the
    mounted sight ends up on the view axis."""
    curves = _bone_curves(strip.action, "tag_ads", "location")
    if len(curves) != 3:
        return
    a0, a1 = strip.action.frame_range
    loc0 = Vector([fc.evaluate(a0) for fc in curves])
    loc1 = Vector([fc.evaluate(a1) for fc in curves])
    ads_at_end = loc1.length >= loc0.length
    hip, ads = (loc0, loc1) if ads_at_end else (loc1, loc0)
    if (ads - hip).length < 1e-3:
        return
    scene = context.scene
    frame = scene.frame_current
    scene.frame_set(int(round(strip.frame_end - 0.01)) if ads_at_end else int(strip.frame_start))
    deps = context.evaluated_depsgraph_get()
    eye, _ = _eye_matrix(rig)
    point = _sight_point(rig, deps)
    pb = rig.pose.bones["tag_ads"]
    frame_basis = (rig.matrix_world @ pb.matrix @ pb.matrix_basis.inverted()).to_3x3()
    scene.frame_set(frame)
    if eye is None or point is None:
        return
    miss = eye.inverted() @ point                     # camera space: x right, y up, -z forward
    fix = frame_basis.inverted() @ (eye.to_3x3() @ Vector((-miss.x, -miss.y, 0.0)))
    span = (ads - hip).length
    frames = {key.co[0] for fc in curves for key in fc.keyframe_points}
    weight = {f: min(max((Vector([c.evaluate(f) for c in curves]) - hip).length / span, 0.0), 1.2) for f in frames}
    for fc_index, fc in enumerate(curves):
        for key in fc.keyframe_points:
            shift = fix[fc_index] * weight[key.co[0]]
            key.co[1] += shift
            key.handle_left[1] += shift
            key.handle_right[1] += shift
        fc.update()
    report({'INFO'}, "CoD AutoShader: lined the sight up with the eye (moved %.1f cm)" % Vector((miss.x, miss.y)).length)


RECOIL_PROFILE = ((0, 0.0), (1, 1.0), (3, 0.6), (6, 0.2), (9, -0.06), (13, 0.0))   # (frames at 30 fps, kick)
RECOIL_KICK_CM = Vector((-1.2, 0.0, 0.3))         # back and a little up, in rig space (CoD: +X forward, +Z up)
RECOIL_PITCH_DEG = 1.4                            # muzzle climb, pivoting at the eye
RECOIL_ADS_KICK = 0.25                            # aimed: the eye sits ~2 cm behind the scope, so it barely moves back


def _recoil_action(rig, strength, fps, seed, aimed=False):
    """A short kick on tag_ads (the whole viewmodel) - CoD adds gun kick procedurally on top of fire anims."""
    import random
    rng = random.Random(seed)
    pb = rig.pose.bones["tag_ads"]
    to_basis = pb.bone.matrix_local.to_3x3().inverted()
    kick = to_basis @ (RECOIL_KICK_CM * strength * (RECOIL_ADS_KICK if aimed else 1.0))
    yaw = math.radians(rng.uniform(-0.5, 0.5)) * strength
    axis_pitch = (to_basis @ Vector((0.0, -1.0, 0.0))).normalized()   # about the gun's right: muzzle up
    axis_yaw = (to_basis @ Vector((0.0, 0.0, 1.0))).normalized()
    action = bpy.data.actions.new("CoD Recoil")
    ad = rig.animation_data
    active = ad.action
    ad.action = action                                # Blender 5 creates curves through the assigned slot
    keys = [(t * fps / 30.0, k) for t, k in RECOIL_PROFILE]
    values = {("location", i): [(f, kick[i] * k) for f, k in keys] for i in range(3)}
    for i in range(4):
        values[("rotation_quaternion", i)] = []
    for f, k in keys:
        q = (Quaternion(axis_pitch, math.radians(RECOIL_PITCH_DEG) * strength * k) @
             Quaternion(axis_yaw, yaw * k))
        for i in range(4):
            values[("rotation_quaternion", i)].append((f, q[i]))
    for (prop, index), pts in values.items():
        if hasattr(action, "fcurve_ensure_for_datablock"):
            fc = action.fcurve_ensure_for_datablock(rig, 'pose.bones["tag_ads"].%s' % prop, index=index,
                                                    group_name="tag_ads")
        else:
            fc = action.fcurves.new('pose.bones["tag_ads"].%s' % prop, index=index, action_group="tag_ads")
        for f, v in pts:
            fc.keyframe_points.insert(f, v, options={'FAST'})
        fc.update()
    ad.action = active
    return action


def _add_recoil(rig, start, strength, fps, aimed=False):
    ad = rig.animation_data
    action = _recoil_action(rig, strength, fps, int(start), aimed)
    span = RECOIL_PROFILE[-1][0] * fps / 30.0
    track = _layer_track(ad, ANIM_TRACK_ADD, start, start + span)
    strip = track.strips.new("Recoil", int(start), action)
    if hasattr(strip, "action_slot") and strip.action_slot is None and len(action.slots):
        strip.action_slot = action.slots[0]
    strip.blend_type = 'COMBINE'
    strip.extrapolation = 'NOTHING'
    return strip


def import_layered_animation(context, rig, path, start, report, force_track=None):
    """Import one .cast animation onto `rig` as an NLA clip. Returns (strip, layer name) or (None, None)."""
    scene = context.scene
    ad = rig.animation_data or rig.animation_data_create()
    _stash_active_action(rig)
    first = not any(t.name in ANIM_TRACK_ORDER and len(t.strips) for t in ad.nla_tracks)
    fps = scene.render.fps / scene.render.fps_base
    frame_range = (scene.frame_start, scene.frame_end)
    if context.object is not None and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in context.view_layer.objects:
        o.select_set(False)
    rig.select_set(True)
    context.view_layer.objects.active = rig
    before = set(bpy.data.actions)
    # the importer measures each bone's rest orientation from the current pose: with the NLA playing (e.g. idle)
    # every new clip would come out relative to that pose, so the layers are paused while it runs
    use_nla = ad.use_nla
    ad.use_nla = False
    try:
        bpy.ops.import_scene.cast(filepath=path, import_reset=True, import_time=False)
    except RuntimeError as e:
        report({'WARNING'}, "CoD AutoShader: could not import %s (%s)" % (os.path.basename(path), e))
        return None, None
    finally:
        ad.use_nla = use_nla
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    action = ad.action if ad.action not in before else next((a for a in bpy.data.actions if a not in before), None)
    if action is None:
        report({'WARNING'}, "CoD AutoShader: %s has no animation" % os.path.basename(path))
        return None, None
    ad.action = None
    for bone in rig.pose.bones:                       # the importer leaves its last pose in the bones
        bone.matrix_basis.identity()
    anim_fps = scene.render.fps / scene.render.fps_base
    if first:
        scale = 1.0                                   # the first clip sets the scene frame rate
    else:
        scene.render.fps, scene.render.fps_base = round(fps), round(fps) / fps
        scale = fps / anim_fps
    info = _anim_info(path)
    bones = _action_bones(action)
    offset_clip = _is_offset_clip(rig, info)
    lowered = {b.lower() for b in bones}
    face_bones = {b for b in lowered if b.startswith(FACE_BONES)}
    if force_track is not None:
        track_name, blend = force_track, 'REPLACE'
    elif bones and bones <= ADS_BONES:
        track_name, blend = ANIM_TRACK_ADS, 'REPLACE'
    elif len(face_bones) >= 5 and len(face_bones) >= 0.5 * len(bones):
        track_name, blend = ANIM_TRACK_FACE, 'REPLACE'       # a facial clip runs alongside the body
    elif info["additive"] or offset_clip:
        if offset_clip:
            _rekey_rotations(rig, action, info["rotated"], as_offsets=True)
        track_name, blend = ANIM_TRACK_ADD, 'COMBINE'
    else:
        if info["identity"]:
            _rekey_rotations(rig, action, info["identity"], as_offsets=False)
        # a clip that moves the legs is the stance / locomotion everything else sits on; an upper-body clip
        # (a third-person inspect, reload, ...) goes above it so the legs keep the stance
        full_body = any(b.startswith(LEG_BONES) for b in lowered)
        track_name, blend = (ANIM_TRACK_BASE if full_body else ANIM_TRACK_UPPER), 'REPLACE'
    length = (action.frame_range[1] - action.frame_range[0]) * scale
    track = (_layer_track(ad, track_name, start, start + length) if track_name in (ANIM_TRACK_ADD, ANIM_TRACK_FACE)
             else _nla_track(ad, track_name))
    strip = _place_strip(track, action, start, scale, action.name, report)
    strip.blend_type = blend
    scene.frame_start = frame_range[0]
    scene.frame_end = max(frame_range[1] if not first else 0, int(math.ceil(strip.frame_end)))
    settings = scene.cod_autoshader
    if (force_track is None and settings.anim_face and _is_body(rig)
            and track_name in (ANIM_TRACK_BASE, ANIM_TRACK_UPPER, ANIM_TRACK_ADD)
            and any(b.startswith(FACE_BONES) for b in (x.name.lower() for x in rig.pose.bones))):
        folder = _rig_weapon(rig, settings)[3]
        add_face_clip(context, rig, strip, path, folder, report)
    if track_name == ANIM_TRACK_ADS and settings.anim_align_sight:
        _align_ads_clip(context, rig, strip, report)
    if (track_name == ANIM_TRACK_BASE and settings.anim_recoil > 0.0 and "tag_ads" in rig.pose.bones
            and re.search(r"(^|_)fire(_last)?$", action.name.lower())):
        _add_recoil(rig, strip.frame_start, settings.anim_recoil, scene.render.fps / scene.render.fps_base,
                    aimed=_ads_up_at(rig, strip.frame_start))
    return strip, track_name


def _face_clip_for(clip, folder):
    """The facial_* clip that goes with an action clip, if the export has one."""
    if not folder or not os.path.isdir(folder):
        return None, None
    name = os.path.basename(clip).lower()
    mood = next(m for pattern, m in FACE_FOR_ACTION if not pattern or re.search(pattern, name))
    best = None
    for entry in os.scandir(folder):
        low = entry.name.lower()
        if not low.endswith(".cast") or "facial" not in low or "enemy" in low:
            continue
        if re.search(r"facial_%s(_|\.)" % mood, low) or low.endswith("facial_%s.cast" % mood):
            if best is None or len(entry.name) < len(os.path.basename(best)):
                best = entry.path
    return best, mood


def add_face_clip(context, rig, body_strip, source_clip, folder, report):
    """Put the matching facial clip on the Face track, repeated to cover the body clip."""
    path, mood = _face_clip_for(source_clip, folder)
    if path is None:
        return None
    strip, _ = import_layered_animation(context, rig, path, int(body_strip.frame_start), report,
                                        force_track=ANIM_TRACK_FACE)
    if strip is None:
        return None
    span = body_strip.frame_end - body_strip.frame_start
    length = strip.frame_end - strip.frame_start
    if length > 0 and span > length:
        strip.repeat = min(span / length, 100.0)           # the face loops under the action
    report({'INFO'}, "CoD AutoShader: face '%s' added" % mood)
    return strip


class COD_OT_import_anim(bpy.types.Operator, ImportHelper):
    bl_idname = "cod.import_anim"
    bl_label = "Import Animation"
    bl_description = ("Import CoD .cast animations as layered clips on the viewmodel rig, starting at the playhead: "
                      "idle / fire / reload stay on the Base layer, ADS up/down go on the ADS layer on top, so "
                      "you can aim and fire over an idle")
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".cast"
    filter_glob: StringProperty(default="*.cast", options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    move_playhead: BoolProperty(name="Move Playhead to End", default=True,
                                description="After importing, put the playhead at the end of the new clip so the "
                                            "next import continues from there")

    @classmethod
    def poll(cls, context):
        return _cast_importer_ready()

    def invoke(self, context, event):
        if _anim_target(context) is None:
            self.report({'ERROR'}, "Select the viewmodel rig (armature) to animate first")
            return {'CANCELLED'}
        return super().invoke(context, event)

    def execute(self, context):
        rig = _anim_target(context)
        if rig is None:
            self.report({'ERROR'}, "Select the viewmodel rig (armature) to animate first")
            return {'CANCELLED'}
        paths = [os.path.join(self.directory, f.name) for f in self.files if f.name] or [self.filepath]
        frame = context.scene.frame_current
        placed = []
        for path in paths:                            # several files play one after another
            strip, layer = import_layered_animation(context, rig, path, frame, self.report)
            if strip is not None:
                placed.append("%s on %s" % (strip.name, layer.replace("CoD ", "")))
                frame = int(math.ceil(strip.frame_end))
        for o in context.view_layer.objects:
            o.select_set(o == rig)
        context.view_layer.objects.active = rig
        if placed and self.move_playhead:
            context.scene.frame_set(frame)
        self.report({'INFO'}, "CoD AutoShader: added " + ", ".join(placed) if placed else "CoD AutoShader: nothing imported")
        return {'FINISHED'} if placed else {'CANCELLED'}


def clear_rig_animation(rig):
    """Remove every clip / action from the rig (and the shape-key clips of its meshes), put the bones back in the
    rest pose and delete the actions nothing else uses. Returns (clips removed, actions deleted)."""
    actions, clips = set(), 0
    meshes = [o for o in bpy.data.objects if o.type == 'MESH' and
              (o.parent is rig or any(m.type == 'ARMATURE' and m.object is rig for m in o.modifiers))]
    datas = [rig] + [o.data for o in meshes] + [o.data.shape_keys for o in meshes if o.data.shape_keys is not None]
    for data in datas:
        ad = data.animation_data
        if ad is None:
            continue
        if ad.action is not None:
            actions.add(ad.action)
            ad.action = None
            clips += 1
        for track in list(ad.nla_tracks):
            for strip in track.strips:
                if strip.action is not None:
                    actions.add(strip.action)
                clips += 1
            ad.nla_tracks.remove(track)
    for bone in rig.pose.bones:
        bone.matrix_basis.identity()
    rig.data.pose_position = 'POSE'
    deleted = 0
    for action in actions:
        action.use_fake_user = False                  # the Cast importer keeps every clip with a fake user
        if action.users == 0:
            bpy.data.actions.remove(action)
            deleted += 1
    return clips, deleted


class COD_OT_clear_anim(bpy.types.Operator):
    bl_idname = "cod.clear_anim"
    bl_label = "Clear Animations"
    bl_description = ("Remove the animations from the viewmodel rig and put it back in its rest pose "
                      "(Ctrl+Z brings them back)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _anim_target(context) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        rig = _anim_target(context)
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        clips, deleted = clear_rig_animation(rig)
        context.view_layer.update()
        self.report({'INFO'}, "CoD AutoShader: removed %d clip(s) from %s, back in its rest pose" % (clips, rig.name))
        return {'FINISHED'}


# ---- weapon clips: find the gun's animations in the export and add a move with the clips it needs ----------

ANIM_DIR_NAMES = ("animations", "Animations", "anims", "xanims")
NEUTRAL_CLIPS = ("idle", "idle_non_loop", "pose", "pose_r")
QUICK_CLIPS = (("ads_up", "Aim", 'HIDE_OFF'), ("ads_down", "Lower", 'HIDE_ON'), ("idle", "Idle", 'POSE_HLT'),
               ("ads_fire", "ADS Fire", 'LIGHT_SUN'), ("fire", "Hip Fire", 'LIGHT_POINT'),
               ("reload", "Reload", 'FILE_REFRESH'))
# third person: the stance clips carry the legs, the weapon clips the upper body (key, pattern, label, icon)
TP_QUICK = (("stand", r"(^|_)mp_me_stand_idle(_\d+)?$", "Stand", 'POSE_HLT'),
            ("crouch", r"(^|_)mp_me_crouch_idle(_\d+)?$", "Crouch", 'TRIA_DOWN_BAR'),
            ("aim pose", r"addoff_{token}_nonads$", "Aim Pose", 'HIDE_OFF'),
            ("inspect", r"{token}_inspect_stand$", "Inspect", 'VIEWZOOM'),
            ("reload", r"{token}_reload_stand$", "Reload", 'FILE_REFRESH'),
            ("fire", r"stand_fire_{token}$", "Fire", 'LIGHT_SUN'))
TP_STANCE_KEYS = ("stand", "crouch")
_clip_cache = {}
_rig_folder_cache = {}
_CLIP_ITEMS = []


def _weapon_token(name, anchors=("vm", "wpn")):
    """Weapon id from a CoD asset name: att_vm_p21_sn_mromeo_rec_v0 -> ('sn_mromeo', 'p21', ''),
    att_rex_vm_ar_mike4_rec_v0 -> ('ar_mike4', '', 'rex'). None if the name has no vm_ / wpn_ part."""
    segs = re.sub(r"\.\d{3}$", "", os.path.splitext(os.path.basename(name))[0]).lower().split("_")
    i = next((k for k, seg in enumerate(segs) if seg in anchors), None)
    if i is None:
        return None
    family = segs[i - 1] if i > 0 and segs[i - 1] not in ("att", "wpn", "m", "mtl") else ""
    rest = segs[i + 1:]
    pnum = ""
    if rest and re.fullmatch(r"p\d+", rest[0]):
        pnum, rest = rest[0], rest[1:]
    if len(rest) < 2:
        return None
    return "_".join(rest[:2]), pnum, family, rest[2:]


def _find_anim_dir(model_path):
    """Saluki puts animations next to models: <export>/models/<model>/x.cast -> <export>/animations."""
    d = os.path.dirname(os.path.abspath(model_path))
    for _ in range(4):
        d = os.path.dirname(d)
        for name in ANIM_DIR_NAMES:
            if os.path.isdir(os.path.join(d, name)):
                return os.path.join(d, name)
    return ""


def _rig_weapon(rig, settings):
    """(weapon id, pnum, family, animations folder) for a viewmodel rig."""
    token, pnum, family = rig.get("cod_weapon", ""), rig.get("cod_weapon_pnum", ""), rig.get("cod_weapon_family", "")
    cached = _rig_folder_cache.get(rig.name)
    if not token or not rig.get("cod_anim_dir"):
        if cached is None:
            got_token, got_pnum, got_family, got_dir = "", "", "", ""
            for ob in _rig_meshes(rig):
                for sl in ob.material_slots:
                    if sl.material is None:
                        continue
                    weapon = _weapon_token(sl.material.name, ("wpn",))
                    if weapon and not got_token:
                        got_token, got_pnum, got_family = weapon[:3]
                    if not got_dir:
                        for image in _material_image_paths(sl.material):
                            model_dir = _model_dir_for(image)
                            if model_dir:
                                got_dir = _find_anim_dir(os.path.join(model_dir, "x"))
                                break
                if got_token and got_dir:
                    break
            cached = (got_token, got_pnum, got_family, got_dir)
            _rig_folder_cache[rig.name] = cached
        token = token or cached[0]
        pnum = pnum or cached[1]
        family = family or cached[2]
    folder = bpy.path.abspath(settings.anim_folder) if settings.anim_folder else \
        (rig.get("cod_anim_dir") or (cached[3] if cached else ""))
    return token, pnum, family, folder


def weapon_clips(rig, settings):
    """clip name -> .cast path for the rig's weapon ('idle', 'ads_up', 'fire', ...)."""
    token, pnum, family, folder = _rig_weapon(rig, settings)
    if not token or not folder or not os.path.isdir(folder):
        return token, folder, {}
    key = (folder, token, pnum, family, os.path.getmtime(folder))
    if key not in _clip_cache:
        best = {}
        for entry in os.scandir(folder):
            if not entry.name.lower().endswith(".cast"):
                continue
            found = _weapon_token(entry.name, ("vm",))
            if not found or found[0] != token or not found[3]:
                continue
            clip = "_".join(found[3])
            score = (found[2] == family) + (found[1] == pnum)      # prefer the gun's own prefix (rex_, p21_)
            if clip not in best or score > best[clip][0]:
                best[clip] = (score, entry.path)
        _clip_cache[key] = {clip: path for clip, (score, path) in best.items()}
    return token, folder, _clip_cache[key]


def third_person_clips(rig, settings):
    """clip name -> .cast path for a character body: the stance clips, this weapon's third-person moves and the
    facial clips of the export."""
    token, pnum, family, folder = _rig_weapon(rig, settings)
    if not folder or not os.path.isdir(folder):
        return token, folder, {}
    key = ("3p", folder, token, os.path.getmtime(folder))
    if key not in _clip_cache:
        clips = {}
        quick = {name: re.compile(pattern.format(token=re.escape(token or "~none~")))
                 for name, pattern, _, _ in TP_QUICK}
        for entry in os.scandir(folder):
            if not entry.name.lower().endswith(".cast"):
                continue
            stem = entry.name[:-5].lower()
            if "_vm_" in stem or stem.startswith("vm_"):
                continue
            for name, pattern in quick.items():
                if pattern.search(stem) and (name not in clips or len(stem) < len(os.path.basename(clips[name]))):
                    clips[name] = entry.path
            if stem.startswith("facial_") and "enemy" not in stem:
                clips["face " + re.sub(r"^facial_", "", stem)] = entry.path
            elif token and token in stem:
                clips[re.sub(r"^(iw9_|sdr_|rex_)?mp_", "", stem).replace(token + "_", "").replace("_" + token, "")] = entry.path
        _clip_cache[key] = clips
    return token, folder, _clip_cache[key]


def clip_catalogue(rig, settings):
    """(weapon id, animations folder, clips) - the weapon's viewmodel clips, or the third-person set."""
    if rig is not None and _is_body(rig):
        return third_person_clips(rig, settings)
    return weapon_clips(rig, settings) if rig is not None else ("", "", {})


def _ads_up_at(rig, frame):
    """Is the gun aimed at `frame` (the last ADS clip starting before it is an 'up')?"""
    ad = rig.animation_data
    track = ad.nla_tracks.get(ANIM_TRACK_ADS) if ad else None
    strips = [st for st in (track.strips if track else ()) if st.frame_start <= frame]
    last = max(strips, key=lambda st: st.frame_start, default=None)
    return last is not None and re.search(r"ads_(up|in)", last.name.lower()) is not None


def _base_empty(rig):
    ad = rig.animation_data
    track = ad.nla_tracks.get(ANIM_TRACK_BASE) if ad else None
    return (ad is None or ad.action is None) and (track is None or not len(track.strips))


def plan_clip_third_person(rig, clip, clips):
    """A third-person move needs the stance under it, or the legs stay in the model's straight bind pose."""
    if clip in TP_STANCE_KEYS or clip.startswith("face ") or not _base_empty(rig):
        return [(clip, True)]
    stance = "stand" if "stand" in clips else ("crouch" if "crouch" in clips else None)
    return ([(stance, False)] if stance and stance != clip else []) + [(clip, True)]


def plan_clip(rig, clip, clips, frame):
    """The clips a move needs, in order: [(clip, next clip starts after it)]. An ADS clip gets the idle under
    it; an ADS fire / reload gets 'aim' first; a hip clip while aimed gets 'lower' first."""
    plan = []
    ads_layer = re.match(r"ads_(up|down)", clip) is not None
    wants_aim = clip.startswith("ads_") and not ads_layer
    if _base_empty(rig) and "idle" in clips and clip != "idle" and (ads_layer or wants_aim):
        plan.append(("idle", False))
    aimed = _ads_up_at(rig, frame)
    if wants_aim and not aimed and "ads_up" in clips:
        plan.append(("ads_up", True))
    elif not clip.startswith("ads_") and clip not in NEUTRAL_CLIPS and aimed and "ads_down" in clips:
        plan.append(("ads_down", True))
    plan.append((clip, True))
    return plan


def add_weapon_clip(context, rig, clip, report):
    _, _, clips = clip_catalogue(rig, context.scene.cod_autoshader)
    if clip not in clips:
        report({'ERROR'}, "No '%s' animation found for this character / weapon" % clip)
        return []
    start = context.scene.frame_current
    placed = []
    plan = plan_clip_third_person(rig, clip, clips) if _is_body(rig) else plan_clip(rig, clip, clips, start)
    for name, advance in plan:
        strip, layer = import_layered_animation(context, rig, clips[name], start, report)
        if strip is None:
            break
        placed.append(name)
        if advance:
            start = int(math.ceil(strip.frame_end))
    for o in context.view_layer.objects:
        o.select_set(o == rig)
    context.view_layer.objects.active = rig
    if placed:
        context.scene.frame_set(start)
        report({'INFO'}, "CoD AutoShader: added " + " + ".join(n.replace("_", " ") for n in placed))
    return placed


def _clip_enum_items(self, context):
    global _CLIP_ITEMS
    rig = _anim_target(context) if context else None
    clips = clip_catalogue(rig, context.scene.cod_autoshader)[2] if rig is not None else {}
    _CLIP_ITEMS = [(c, c.replace("_", " "), os.path.basename(path)) for c, path in sorted(clips.items())] or \
        [('NONE', "No clips found", "")]
    return _CLIP_ITEMS


class _ClipOperator:
    @classmethod
    def poll(cls, context):
        return _cast_importer_ready() and _anim_target(context) is not None


class COD_OT_add_clip(_ClipOperator, bpy.types.Operator):
    bl_idname = "cod.add_clip"
    bl_label = "Add Weapon Clip"
    bl_options = {'REGISTER', 'UNDO'}

    clip: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        needs = {"ads_up": "Raise the sights (adds the idle under it if needed)",
                 "ads_down": "Lower the sights back to the hip",
                 "ads_fire": "Aim and fire: adds Aim first if the gun isn't up yet",
                 "fire": "Fire from the hip: lowers the sights first if aimed",
                 "reload": "Reload from the hip: lowers the sights first if aimed"}
        return needs.get(properties.clip, "Add the weapon's '%s' animation at the playhead" % properties.clip)

    def execute(self, context):
        return {'FINISHED'} if add_weapon_clip(context, _anim_target(context), self.clip, self.report) \
            else {'CANCELLED'}


class COD_OT_add_clip_search(_ClipOperator, bpy.types.Operator):
    bl_idname = "cod.add_clip_search"
    bl_label = "Add Clip"
    bl_description = "Search the weapon's animations and add one at the playhead, with the clips it needs"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "clip"

    clip: EnumProperty(items=_clip_enum_items)

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if self.clip == 'NONE':
            return {'CANCELLED'}
        return {'FINISHED'} if add_weapon_clip(context, _anim_target(context), self.clip, self.report) \
            else {'CANCELLED'}


class COD_OT_vm_camera(bpy.types.Operator):
    bl_idname = "cod.vm_camera"
    bl_label = "Viewmodel Camera"
    bl_description = ("Add a camera on the arms' eye bone (tag_camera) and make it the scene camera, so ADS "
                      "animations bring the sights to the middle of the view like in game")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        rig = _anim_target(context)
        bone = next((b for b in EYE_BONES if rig is not None and b in rig.pose.bones), None)
        if bone is None:
            self.report({'ERROR'}, "Select a viewmodel rig with a tag_camera / tag_view bone")
            return {'CANCELLED'}
        cam = bpy.data.objects.get(VM_CAMERA_NAME)
        if cam is None or cam.type != 'CAMERA':
            cam = bpy.data.objects.new(VM_CAMERA_NAME, bpy.data.cameras.new(VM_CAMERA_NAME))
            context.scene.collection.objects.link(cam)
            cam.data.lens = VM_CAMERA_LENS
        scale = sum(abs(v) for v in rig.matrix_world.to_scale()) / 3.0 or 1.0
        cam.data.clip_start = 1.0 * scale             # rigs are in cm; a 0.01-scaled rig keeps working
        cam.data.clip_end = 100000.0 * scale
        cam.parent = rig
        cam.parent_type = 'BONE'
        cam.parent_bone = bone
        context.view_layer.update()
        eye, _ = _eye_matrix(rig)
        cam.matrix_world = eye
        context.view_layer.update()
        context.scene.camera = cam
        self.report({'INFO'}, "CoD AutoShader: camera attached to %s" % bone)
        return {'FINISHED'}


def _active_material(context):
    mat = getattr(context, "material", None)
    if mat is None and context.object is not None:
        mat = context.object.active_material
    return mat


class COD_OT_shade_active(bpy.types.Operator):
    bl_idname = "cod.shade_active"
    bl_label = "Reshade Active"
    bl_description = "Rebuild the active material with the current CoD AutoShader defaults"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_material(context) is not None

    def execute(self, context):
        shade_materials([_active_material(context)], context.scene.cod_autoshader, self.report)
        return {'FINISHED'}


def _split(layout):
    """Blender's standard property layout: label column | value column, no animate dots."""
    layout.use_property_split = True
    layout.use_property_decorate = False
    return layout


def _settings(context):
    return context.scene.cod_autoshader


# ---- tool panel sections (shared by the 3D View and the Shader Editor) ------------------------

def _draw_main(layout):
    col = layout.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1.5
    row.operator(COD_OT_import_cast.bl_idname, text="Import & Shade", icon='IMPORT')
    row = col.row(align=True)
    row.scale_y = 1.15
    row.operator(COD_OT_shade_selected.bl_idname, text="Shade Selected", icon='RESTRICT_SELECT_OFF')
    row.operator(COD_OT_shade_all.bl_idname, text="Shade All", icon='WORLD')


def _draw_viewmodel(layout, s):
    rig = _anim_target(bpy.context)
    col = layout.column(align=True)
    col.scale_y = 1.15
    col.operator(COD_OT_import_vm.bl_idname, text="Import Viewmodel", icon='IMPORT')
    col.operator(COD_OT_assemble_vm.bl_idname, text="Assemble Selected", icon='LINKED')
    col = layout.column(align=True)
    col.scale_y = 1.15
    col.operator(COD_OT_import_anim.bl_idname, text="Import Animation", icon='ACTION')
    col.operator(COD_OT_vm_camera.bl_idname, text="Viewmodel Camera", icon='CAMERA_DATA')
    row = col.row(align=True)
    row.enabled = rig is not None
    row.prop(s, "anim_play", text="Animations" if s.anim_play else "Rest Pose", toggle=True,
             icon='PLAY' if s.anim_play else 'ARMATURE_DATA')
    row.operator(COD_OT_clear_anim.bl_idname, text="Clear", icon='TRASH')

    token, folder, clips = clip_catalogue(rig, s) if rig is not None else ("", "", {})
    third_person = rig is not None and _is_body(rig)
    header, body = layout.panel("cod_weapon_clips", default_closed=False)
    header.label(text=("Character Clips" if third_person else "Weapon Clips") +
                 ("  (%s)" % token.split("_", 1)[-1] if token else ""), icon='ANIM')
    if body:
        if clips:
            grid = body.grid_flow(row_major=True, columns=3, even_columns=True, align=True)
            grid.scale_y = 1.1
            quick = [(k, label, icon) for k, _, label, icon in TP_QUICK] if third_person else QUICK_CLIPS
            for clip, label, icon in quick:
                cell = grid.row(align=True)
                cell.enabled = clip in clips
                cell.operator(COD_OT_add_clip.bl_idname, text=label, icon=icon).clip = clip
            body.operator(COD_OT_add_clip_search.bl_idname, text="More Clips...", icon='VIEWZOOM')
        else:
            body.label(text="Select the rig" if rig is None else "No animations found in the export",
                       icon='INFO')
        if s.anim_folder or (rig is not None and not clips):
            body.prop(s, "anim_folder", text="")

    col = _split(layout.column(align=True))
    col.prop(s, "anim_align_sight", text="Line Up Sight")
    col.prop(s, "anim_face", text="Face Animation")
    col.prop(s, "anim_recoil", text="Fire Recoil", slider=True)


def _draw_game(layout, s):
    grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=True)
    grid.scale_y = 1.1
    grid.prop(s, "game", expand=True)


def _draw_surface(layout, s):
    _split(layout)
    layout.prop(s, "metal_mode", text="Metal")
    col = layout.column(align=True)
    col.prop(s, "normal_strength", text="Normal")
    col.prop(s, "ao_strength", text="Occlusion")
    col.prop(s, "emission_strength", text="Emission")
    col.prop(s, "emission_color", text="Emission Color")
    header, body = layout.panel("cod_surface_advanced", default_closed=True)
    header.label(text="Advanced")
    if body:
        body.prop(s, "gloss_curve", text="Gloss Curve")


def _draw_character(layout, s):
    _split(layout)
    col = layout.column(align=True, heading="Skin")
    col.prop(s, "skin_sss", text="Subsurface")
    sub = col.column(align=True)
    sub.active = s.skin_sss
    sub.prop(s, "sss_weight", text="Weight")
    sub.prop(s, "sss_scale", text="Scale (cm)")
    layout.prop(s, "skin_oil", text="Oil / Sheen")
    layout.prop(s, "skin_roughness_min", text="Roughness Min")
    layout.separator()
    layout.column(heading="Hair").prop(s, "hair_shader", text="Hair Shader")
    layout.separator()
    col = layout.column(heading="Eyes")
    col.prop(s, "eye_parallax", text="Iris Depth")
    layout.prop(s, "eye_shadow", text="Lid Shadow", slider=True)


def _draw_sights(layout, s):
    _split(layout)
    layout.active = s.sight_shader
    col = layout.column(align=True, heading="Red Dot")
    col.prop(s, "red_dot_reticle", text="Reticle")
    sub = layout.column(align=True)
    sub.active = s.red_dot_reticle
    sub.prop(s, "reticle_style", text="Style")
    sub.prop(s, "reticle_color", text="Color")
    sub.prop(s, "reticle_brightness", text="Brightness")
    sub.prop(s, "reticle_size", text="Circle Size")
    layout.separator()
    layout.prop(s, "scope_zoom", text="Scope Zoom")
    row = layout.row()
    row.alignment = 'RIGHT'
    row.label(text="Scope zoom needs Cycles", icon='INFO')


BODYCAM_LABELS = {"Chromatic Aberration": "Color Fringe"}


def _draw_bodycam(layout, s):
    scene = s.id_data
    if not hasattr(scene, "compositing_node_group"):
        layout.label(text="Needs Blender 5.0 or newer", icon='ERROR')
        return
    row = layout.row(align=True)
    row.scale_y = 1.15
    row.operator(COD_OT_bodycam_preset.bl_idname, text="Day", icon='LIGHT_SUN').preset = 'DAY'
    row.operator(COD_OT_bodycam_preset.bl_idname, text="Night", icon='LIGHT_HEMI').preset = 'NIGHT'
    node = bodycam_node(scene)
    if node is None:
        return
    _split(layout)
    body = layout.column()
    body.active = not node.mute
    for panel in ("Lens", "Light", "Color", "Camera"):
        col = body.column(align=True, heading=panel)
        for sock, group, *_ in BODYCAM_PARAMS:
            if group == panel:
                col.prop(node.inputs[sock], "default_value", text=BODYCAM_LABELS.get(sock, sock))
    space = bpy.context.space_data
    if space is not None and space.type == 'VIEW_3D':
        body.prop(space.shading, "use_compositor", text="Viewport")
    row = layout.row()
    row.alignment = 'RIGHT'
    row.label(text="Tip: a 16-20 mm camera lens helps", icon='INFO')


def _draw_search(layout, s):
    _split(layout)
    layout.prop(s, "search_folder", text="Export Folder")


# (key, label, header icon, closed by default, draw function, header checkbox property)
TOOL_SECTIONS = (
    ("game", "Game", 'WORLD', False, _draw_game, None),
    ("vm", "Viewmodel", 'ARMATURE_DATA', False, _draw_viewmodel, None),
    ("surface", "Surface", 'MATERIAL', False, _draw_surface, None),
    ("character", "Character", 'USER', True, _draw_character, None),
    ("sights", "Sights", 'HIDE_OFF', True, _draw_sights, "sight_shader"),
    ("bodycam", "Bodycam Look", 'CAMERA_DATA', True, _draw_bodycam, "bodycam"),
    ("search", "Texture Search", 'VIEWZOOM', True, _draw_search, None),
)


class _ViewSpace:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "CoD"


class _NodeSpace:
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CoD"

    @classmethod
    def poll(cls, context):
        return getattr(context.space_data, "tree_type", "") == 'ShaderNodeTree'


# Blender checks that panel callbacks take exactly (self, context), so bind per-section data in closures
def _section_draw(fn):
    def draw(self, context):
        fn(self.layout, _settings(context))
    return draw


def _section_header(icon, header_prop):
    def draw_header(self, context):
        if header_prop:
            self.layout.prop(_settings(context), header_prop, text="")
        else:
            self.layout.label(icon=icon)
    return draw_header


def _make_tool_panels(space, tag, main_closed):
    main_id = "COD_PT_%s_tools" % tag

    def draw_main(self, context):
        _draw_main(self.layout)

    def draw_main_header(self, context):
        self.layout.label(icon='SHADING_TEXTURE')

    classes = [type(main_id, (space, bpy.types.Panel), {
        "bl_idname": main_id, "bl_label": "CoD AutoShader",
        "bl_options": {'DEFAULT_CLOSED'} if main_closed else set(),
        "draw": draw_main, "draw_header": draw_main_header,
    })]
    for key, label, icon, closed, fn, header_prop in TOOL_SECTIONS:
        pid = "COD_PT_%s_%s" % (tag, key)
        classes.append(type(pid, (space, bpy.types.Panel), {
            "bl_idname": pid, "bl_label": label, "bl_parent_id": main_id,
            "bl_options": {'DEFAULT_CLOSED'} if closed else set(),
            "draw": _section_draw(fn), "draw_header": _section_header(icon, header_prop),
        }))
    return classes




# ---- Shader Editor: live controls for the active material -------------------------------------

KIND_LABELS = {'DEFAULT': "Surface", 'SKIN': "Skin", 'HAIR': "Hair", 'EYE': "Eye", 'TEARFILM': "Tear Film",
               'LENS': "Lens", 'SCOPE': "Scope", 'RETICLE': "Reticle Stencil"}


def _material_state(context):
    """(material, nodes, decode group node) for the active material, or Nones."""
    mat = _active_material(context)
    if mat is None or mat.node_tree is None:
        return None, None, None
    nodes = mat.node_tree.nodes
    grp = next((n for n in nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith(GROUP_NAME)), None)
    return mat, nodes, grp


def _socket_props(layout, node, pairs):
    col = layout.column(align=True)
    for name, text in pairs:
        sock = node.inputs.get(name)
        if sock is not None and not sock.is_linked:
            col.prop(sock, "default_value", text=text)
    return col


class COD_PT_node_material(_NodeSpace, bpy.types.Panel):
    bl_idname = "COD_PT_node_material"
    bl_label = "CoD Material"

    def draw_header(self, context):
        self.layout.label(icon='NODE_MATERIAL')

    def draw(self, context):
        layout = self.layout
        mat, nodes, grp = _material_state(context)
        if mat is None:
            layout.label(text="No active material", icon='INFO')
            return
        row = layout.row(align=True)
        row.label(text=mat.name, icon='MATERIAL')
        if mat.get("cod_kind"):
            sub = row.row()
            sub.alignment = 'RIGHT'
            sub.label(text=KIND_LABELS.get(mat["cod_kind"], mat["cod_kind"]))
        row = layout.row()
        row.scale_y = 1.15
        shaded = grp is not None or bool(mat.get("cod_shaded"))
        row.operator(COD_OT_shade_active.bl_idname, text="Reshade" if shaded else "Shade", icon='FILE_REFRESH')
        if not shaded:
            layout.label(text="Not shaded by CoD AutoShader yet", icon='INFO')


class _MaterialSubPanel(_NodeSpace):
    bl_parent_id = "COD_PT_node_material"

    @classmethod
    def poll(cls, context):
        if not _NodeSpace.poll.__func__(cls, context):
            return False
        mat, nodes, grp = _material_state(context)
        return grp is not None and cls.applies(mat, nodes)

    @staticmethod
    def applies(mat, nodes):
        return True


class COD_PT_node_mat_adjust(_MaterialSubPanel, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_adjust"
    bl_label = "Adjust"

    def draw_header(self, context):
        self.layout.label(icon='MODIFIER')

    def draw(self, context):
        _, _, grp = _material_state(context)
        _split(self.layout)
        _socket_props(self.layout, grp, (("Normal Strength", "Normal"), ("AO Strength", "Occlusion"),
                                         ("Emission Strength", "Emission"), ("Emission Color", "Emission Color")))
        _socket_props(self.layout, grp, (("Roughness Min", "Roughness Min"), ("Roughness Max", "Max")))


class COD_PT_node_mat_hair(_MaterialSubPanel, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_hair"
    bl_label = "Hair"

    @staticmethod
    def applies(mat, nodes):
        return nodes.get(HAIR_NODE_NAME) is not None

    def draw_header(self, context):
        self.layout.label(icon='STRANDS')

    def draw(self, context):
        _, nodes, _ = _material_state(context)
        hair = nodes[HAIR_NODE_NAME]
        layout = _split(self.layout)
        _socket_props(layout, hair, (("Shine", "White Highlight"), ("Shine Softness", "Softness")))
        _socket_props(layout, hair, (("Color Shine", "Color Highlight"), ("Color Shine Softness", "Softness")))
        _socket_props(layout, hair, (("Backlight", "Backlight"), ("Strand Variation", "Variation")))
        header, body = layout.panel("cod_mat_hair_adv", default_closed=True)
        header.label(text="Advanced")
        if body:
            _socket_props(body, hair, (("Shine Shift", "White Shift"), ("Color Shine Shift", "Color Shift"),
                                       ("Strand Stretch", "Stretch")))


class COD_PT_node_mat_eye(_MaterialSubPanel, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_eye"
    bl_label = "Eye"

    @staticmethod
    def applies(mat, nodes):
        return (nodes.get(EYE_NODE_NAME) is not None or nodes.get(EYE_SHADOW_NODE_NAME) is not None
                or mat.get("cod_kind") == 'EYE')

    def draw_header(self, context):
        self.layout.label(icon='HIDE_OFF')

    def draw(self, context):
        mat, nodes, _ = _material_state(context)
        layout = _split(self.layout)
        eye = nodes.get(EYE_NODE_NAME)
        if eye is not None:
            _socket_props(layout, eye, (("Iris Depth", "Iris Depth"), ("Iris Radius", "Iris Radius")))
        bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if bsdf is not None and mat.get("cod_kind") == 'EYE':
            col = layout.column(align=True)
            for name, text in (("Coat Weight", "Cornea Gloss"), ("Coat Roughness", "Cornea Roughness")):
                sock = _principled_input(bsdf, name)
                if sock is not None:
                    col.prop(sock, "default_value", text=text)
        shadow = nodes.get(EYE_SHADOW_NODE_NAME)
        if shadow is not None:
            layout.prop(shadow.inputs[1], "default_value", text="Lid Shadow")


class COD_PT_node_mat_sss(_MaterialSubPanel, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_sss"
    bl_label = "Skin"

    @staticmethod
    def applies(mat, nodes):
        return nodes.get(SSS_NODE_NAME) is not None or nodes.get(SKIN_OIL_NODE_NAME) is not None

    def draw_header(self, context):
        self.layout.label(icon='USER')

    def draw(self, context):
        _, nodes, _ = _material_state(context)
        layout = _split(self.layout)
        bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        sss = nodes.get(SSS_NODE_NAME)
        if sss is not None:
            col = layout.column(align=True, heading="Subsurface")
            if bsdf is not None:
                w = _principled_input(bsdf, "Subsurface Weight", "Subsurface")
                if w is not None:
                    col.prop(w, "default_value", text="Weight")
            col.prop(sss.inputs[1], "default_value", text="Scale (cm)")
        oil = nodes.get(SKIN_OIL_NODE_NAME)
        if oil is not None:
            layout.column(align=True).prop(oil.inputs[1], "default_value", text="Oil / Sheen")


class COD_PT_node_mat_sight(_NodeSpace, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_sight"
    bl_label = "Sight"
    bl_parent_id = "COD_PT_node_material"

    @classmethod
    def poll(cls, context):
        if not _NodeSpace.poll.__func__(cls, context):
            return False
        mat, nodes, _ = _material_state(context)
        return nodes is not None and (nodes.get(SIGHT_NODE_NAME) is not None
                                      or nodes.get(LENS_REFLECTION_NODE_NAME) is not None)

    def draw_header(self, context):
        self.layout.label(icon='HIDE_OFF')

    def draw(self, context):
        mat, nodes, _ = _material_state(context)
        layout = _split(self.layout)
        reflection = nodes.get(LENS_REFLECTION_NODE_NAME)
        if reflection is not None:
            layout.prop(reflection.outputs[0], "default_value", text="Lens Reflection")
        sight = nodes.get(SIGHT_NODE_NAME)
        if sight is None:
            return
        light = nodes.get(RETICLE_NODE_NAME)
        if light is not None:
            col = layout.column(align=True)
            col.prop(light.inputs["Color"], "default_value", text="Reticle Color")
            col.prop(light.inputs["Strength"], "default_value", text="Brightness")
            _socket_props(layout, sight, (("Dot Size", "Dot Size"), ("Ring Size", "Circle Size"),
                                          ("Line Width", "Line Width")))
        if mat.get("cod_kind") == 'SCOPE':
            _socket_props(layout, sight, (("Zoom", "Zoom"), ("Eye Relief", "Eye Relief")))
            _socket_props(layout, sight, (("Line Width", "Crosshair Width"), ("Ring Size", "Post Start")))
            header, body = layout.panel("cod_mat_scope_adv", default_closed=True)
            header.label(text="Advanced")
            if body:
                _socket_props(body, sight, (("Portal Offset (cm)", "Portal Offset"),))
            row = layout.row()
            row.alignment = 'RIGHT'
            row.label(text="Zoomed view needs Cycles", icon='INFO')


class COD_PT_node_mat_advanced(_MaterialSubPanel, bpy.types.Panel):
    bl_idname = "COD_PT_node_mat_advanced"
    bl_label = "CoD Decode"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(icon='PREFERENCES')

    def draw(self, context):
        _, _, grp = _material_state(context)
        layout = _split(self.layout)
        _socket_props(layout, grp, (("Metal Mask", "Metal Mask"), ("Insulator Range", "Insulator Range"),
                                    ("Dielectric F0", "Dielectric F0"), ("F0 Floor", "F0 Floor")))
        _socket_props(layout, grp, (("CoD Gloss Curve", "Gloss Curve"), ("Gloss Exponent", "Exponent"),
                                    ("Gloss Bias", "Bias")))


UI_CLASSES = (
    _make_tool_panels(_ViewSpace, "view", main_closed=False)
    + [COD_PT_node_material, COD_PT_node_mat_adjust, COD_PT_node_mat_hair, COD_PT_node_mat_eye,
       COD_PT_node_mat_sss, COD_PT_node_mat_sight, COD_PT_node_mat_advanced]
    + _make_tool_panels(_NodeSpace, "node", main_closed=True)
)


def _menu_import(self, context):
    self.layout.operator(COD_OT_import_cast.bl_idname, text="CoD Cast + AutoShader (.cast)")
    self.layout.operator(COD_OT_import_vm.bl_idname, text="CoD Viewmodel: arms + gun (.cast)")
    self.layout.operator(COD_OT_import_anim.bl_idname, text="CoD Animation, layered (.cast)")


classes = (CoDSettings, COD_OT_shade_selected, COD_OT_shade_all, COD_OT_shade_active, COD_OT_import_cast,
           COD_OT_bodycam_preset,
           COD_OT_assemble_vm, COD_OT_import_vm, COD_OT_import_anim, COD_OT_clear_anim, COD_OT_add_clip,
           COD_OT_add_clip_search, COD_OT_vm_camera, *UI_CLASSES)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.cod_autoshader = bpy.props.PointerProperty(type=CoDSettings)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    del bpy.types.Scene.cod_autoshader
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
