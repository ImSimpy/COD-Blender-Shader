"""CoD Anim Montage - a library of third-person Call of Duty animations and a montage builder that layers them
the way the game does.

A CoD character in third person is never one clip. The game stacks:
    Base / Full Body   the stance, locomotion, death or lobby clip that drives the legs
    Upper Body         weapon clips (rex_wm_*, iw9_mp_*: reload, inspect, fire) - spine and arms only
    Aim Offset         'addoff' clips - small offsets on top, exported as near-identity absolute keys
    Face               facial_* clips - face joints only
Played alone, an upper-body clip leaves the legs in the bind pose and an aim offset leaves the arms floating, so
here every clip goes on its own NLA layer, masked to the joints that layer owns, over a base pose, and
consecutive clips crossfade instead of popping.

Needs only the Cast importer (io_scene_cast). Works next to CoD AutoShader but does not depend on it.
"""
import math
import os
import re

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from mathutils import Quaternion

# ---------------------------------------------------------------------------------------------------------------
# Joints
# ---------------------------------------------------------------------------------------------------------------

LEG_BONES = ("j_knee", "j_ankle", "j_ball", "j_hip", "j_mainroot", "j_toe", "tag_origin")
FACE_BONES = ("j_brow", "j_jaw", "j_eye", "j_lip", "j_cheek", "j_nose", "j_chin", "j_mouth", "j_teeth",
              "j_tongue", "j_uppercheek", "j_smile", "j_frown", "j_nostril", "j_forehead", "j_temple")

OFFSET_KEY_MAX_DEG = 20.0    # an 'addoff' clip keeps nearly every rotation this close to identity...
OFFSET_SHARE = 0.85
OFFSET_REST_MIN_DEG = 30.0   # ...on joints that rest far from identity

# ---------------------------------------------------------------------------------------------------------------
# Library categories (by name - fast enough for a 2,400-clip export) and montage slots (by content)
# ---------------------------------------------------------------------------------------------------------------

CATEGORIES = (
    ('ALL', "All", "Every third-person clip", 'ASSET_MANAGER'),
    ('MOVE', "Movement", "Stand, crouch, walk, run, sprint, jump, slide, swim", 'MOD_DASH'),
    ('WEAPON', "Weapon", "Third-person weapon clips: reload, inspect, fire, melee (upper body)", 'TOOL_SETTINGS'),
    ('AIM', "Aim Offset", "'addoff' clips: small offsets layered on top", 'HIDE_OFF'),
    ('FACE', "Face", "Facial expressions", 'MONKEY'),
    ('DEATH', "Death", "Deaths and last stand", 'GHOST_ENABLED'),
    ('EMOTE', "Emote", "Emotes and gestures", 'FUND'),
    ('LOBBY', "Lobby", "Menu and operator-select clips", 'COMMUNITY'),
    ('CINE', "Cinematic", "Cutscenes, executions, meat shields", 'CAMERA_DATA'),
    ('VEHICLE', "Vehicle", "Seats, turrets, helicopters", 'AUTO'),
    ('NPC', "NPC", "AI soldiers: patrol, alert, cover, combat", 'GHOST_DISABLED'),
    ('OTHER', "Other", "Everything else", 'QUESTION'),
)
CATEGORY_ICON = {c[0]: c[3] for c in CATEGORIES}
CATEGORY_RULES = (                       # checked in order; the first match wins
    ('FACE', r"facial|(^|_)face_|expression|lipsync"),
    ('DEATH', r"death|(^|_)die(_|$)|dying|laststand|last_stand"),
    ('EMOTE', r"emote|gesture|taunt|celebrat"),
    ('LOBBY', r"(^|_)fe_|char_sel|operator_select|op_select|lobby|gunsmith|frontend"),
    ('CINE', r"(^|_)cin_|cinematic|meatshield|execution|finisher|takedown"),
    ('VEHICLE', r"(^|_)veh_|vehicle|(^|_)seat_|heli|motocycle|motorcycle|(^|_)utv|(^|_)pwc_|turret"),
    ('AIM', r"addoff|aim_?offset|aimset"),
    ('WEAPON', r"(^|_)wm_|(^|_)mp_.*(reload|inspect|fire|melee|raise|drop|equip|trans_2|rechamber)"),
    ('NPC', r"^(sdr|reb|hm)_|patrol|(^|_)alert|curious|cornercheck|(^|_)cover_|(^|_)com_"),
    ('MOVE', r"(^|_)(run|sprint|walk|jog|strafe|loco|turn|jump|land|slide|mantle|swim|prone|crouch|stand|supine)"
             r"(_|$)|stand_idle|crouch_idle"),
)

SLOTS = (
    ('AUTO', "Auto", "Pick the layer from the joints the clip moves", 'AUTO'),
    ('BASE', "Base Pose", "Held under the whole montage: the first frame of this clip is the stance everything "
                          "else plays on", 'ARMATURE_DATA'),
    ('FULL', "Full Body", "Moves the whole body (stance, run, death, emote, lobby)", 'POSE_HLT'),
    ('UPPER', "Upper Body", "Spine, arms and weapon only - the legs keep the clip below", 'TOOL_SETTINGS'),
    ('AIM', "Aim Offset", "Added on top of everything below", 'HIDE_OFF'),
    ('FACE', "Face", "Face joints only", 'MONKEY'),
)
SLOT_ICON = {s[0]: s[3] for s in SLOTS}
SLOT_NAME = {s[0]: s[1] for s in SLOTS}

# NLA tracks, bottom to top
TRACK_BASE = "Montage Base"
TRACKS = (TRACK_BASE, "Montage Full A", "Montage Full B", "Montage Upper A", "Montage Upper B",
          "Montage Aim", "Montage Face")
SRC_PROP, SLOT_PROP, RIG_PROP = "cod_montage_src", "cod_montage_slot", "cod_montage_rig"


def _is_viewmodel(stem):
    return "_vm_" in stem or stem.startswith("vm_")


def clip_category(stem):
    stem = stem.lower()
    return next((cat for cat, pattern in CATEGORY_RULES if re.search(pattern, stem)), 'OTHER')


def clip_label(stem):
    """Shorter names in the list: the game prefix (rex_, iw9_, t10_, sat_ ...) adds nothing."""
    return re.sub(r"^(rex|iw9|iw8|jup|sat|t10|t9|s4|sdr|ch|mp)_(mp_|wm_)?", "", stem)


def fs_path(path):
    """Windows: export trees nest deep enough to pass 260 characters, which plain paths silently skip."""
    if os.name == "nt" and path and not path.startswith("\\\\?\\") and len(path) > 240:
        return "\\\\?\\" + os.path.abspath(path)
    return path


# ---------------------------------------------------------------------------------------------------------------
# Reading and re-keying clips
# ---------------------------------------------------------------------------------------------------------------

def _cast_ready():
    try:
        bpy.ops.import_scene.cast.get_rna_type()
        return True
    except (AttributeError, KeyError):
        return False


def _cast_module():
    """The Cast importer's file reader, wherever it is installed (legacy add-on or extension)."""
    import addon_utils
    import importlib
    for mod in addon_utils.modules():
        if mod.__name__.split(".")[-1] == "io_scene_cast":
            try:
                return importlib.import_module(mod.__name__ + ".cast")
            except ImportError:
                continue
    return None


def clip_info(path):
    """{'additive': Cast additive curves, 'offsets': every rotation key near identity, 'rotated': joints with
    rotation keys, 'identity': joints keyed as a constant identity (placeholders for joints it does not drive)}."""
    info = {"additive": False, "offsets": False, "rotated": set(), "identity": set()}
    cast = _cast_module()
    if cast is None:
        return info
    near = math.cos(math.radians(OFFSET_KEY_MAX_DEG) / 2.0)
    exact = math.cos(math.radians(0.2) / 2.0)
    near_count = 0
    try:
        for root in cast.Cast.load(path).Roots():
            for anim in root.ChildrenOfType(cast.Animation):
                for curve in anim.Curves():
                    info["additive"] = info["additive"] or curve.Mode() == "additive"
                    if curve.KeyPropertyName() != "rq" or curve.Mode() not in ("absolute", None):
                        continue
                    v = curve.KeyValueBuffer()
                    if not len(v):
                        continue
                    info["rotated"].add(curve.NodeName())
                    ws = [abs(v[i + 3]) for i in range(0, len(v), 4)]
                    near_count += min(ws) >= near
                    if min(ws) >= exact:
                        info["identity"].add(curve.NodeName())
                info["offsets"] = bool(info["rotated"]) and near_count >= OFFSET_SHARE * len(info["rotated"])
                return info
    except Exception:
        pass
    return info


def _fcurves(action):
    if getattr(action, "layers", None):                     # Blender 4.4+ layered actions
        return [fc for layer in action.layers for strip in layer.strips
                for bag in getattr(strip, "channelbags", ()) for fc in bag.fcurves]
    return list(getattr(action, "fcurves", ()))


def _remove_fcurve(action, fc):
    for layer in getattr(action, "layers", ()):
        for strip in layer.strips:
            for bag in getattr(strip, "channelbags", ()):
                if fc in bag.fcurves.values():
                    bag.fcurves.remove(fc)
                    return
    if hasattr(action, "fcurves") and fc in action.fcurves.values():
        action.fcurves.remove(fc)


def _bone_of(fc):
    m = re.match(r'pose\.bones\["(.+?)"\]', fc.data_path)
    return m.group(1) if m else None


def action_bones(action):
    return {b for b in (_bone_of(fc) for fc in _fcurves(action)) if b}


def _rest_local(pb):
    bone = pb.bone
    local = bone.matrix_local if bone.parent is None else bone.parent.matrix_local.inverted() @ bone.matrix_local
    return local.to_quaternion()


def _bone_curves(action, bone, prop):
    path = 'pose.bones["%s"].%s' % (bone, prop)
    return sorted((fc for fc in _fcurves(action) if fc.data_path == path), key=lambda fc: fc.array_index)


def _is_offset_clip(rig, info):
    if not info["offsets"]:
        return False
    limit = math.radians(OFFSET_REST_MIN_DEG)
    return any(_rest_local(pb).angle > limit for pb in rig.pose.bones if pb.name in info["rotated"])


def _rekey(rig, action, bones, as_offsets):
    """The importer keys rotations as basis = rest^-1 * key. as_offsets: key them as basis = key, an offset on top
    of the layer below. Otherwise drop identity placeholders so the layer below shows through."""
    names = {b.lower() for b in bones}
    for pb in rig.pose.bones:
        if pb.name.lower() not in names:
            continue
        rest = _rest_local(pb)
        curves = _bone_curves(action, pb.name, "rotation_quaternion")
        if len(curves) != 4 or (not as_offsets and rest.angle < math.radians(2.0)):
            continue
        if as_offsets:
            frames = sorted({k.co[0] for k in curves[0].keyframe_points})
            values = {f: rest @ Quaternion([fc.evaluate(f) for fc in curves]) for f in frames}
            for i, fc in enumerate(curves):
                for key in fc.keyframe_points:
                    q = values.get(key.co[0])
                    if q is not None:
                        shift = q[i] - key.co[1]
                        key.co[1] += shift
                        key.handle_left[1] += shift
                        key.handle_right[1] += shift
                fc.update()
        else:
            for fc in curves:
                _remove_fcurve(action, fc)


def detect_slot(bones, info, offset_clip):
    low = {b.lower() for b in bones}
    face = {b for b in low if b.startswith(FACE_BONES)}
    if len(face) >= 5 and len(face) >= 0.5 * len(low):
        return 'FACE'
    if info["additive"] or offset_clip:
        return 'AIM'
    return 'FULL' if any(b.startswith(LEG_BONES) for b in low) else 'UPPER'


def mask_action(action, slot):
    """Keep only the joints the slot owns."""
    for fc in list(_fcurves(action)):
        bone = _bone_of(fc)
        if bone is None:
            continue
        low = bone.lower()
        face = low.startswith(FACE_BONES)
        legs = low.startswith(LEG_BONES)
        if (slot == 'FACE' and not face) or (slot in ('UPPER', 'AIM') and (face or legs)) or \
                (slot == 'BASE' and face):
            _remove_fcurve(action, fc)


class _Paused:
    """Everything the Cast importer must not see: NLA playing, an active action, constraints (it measures rest
    from the current pose)."""

    def __init__(self, rig):
        self.rig = rig
        self.ad = rig.animation_data or rig.animation_data_create()

    def __enter__(self):
        self.action, self.use_nla = self.ad.action, self.ad.use_nla
        self.ad.action, self.ad.use_nla = None, False
        self.cons = [c for pb in self.rig.pose.bones for c in pb.constraints if not c.mute]
        for c in self.cons:
            c.mute = True
        for pb in self.rig.pose.bones:
            pb.matrix_basis.identity()
        bpy.context.view_layer.update()
        return self

    def __exit__(self, *exc):
        self.ad.action = self.action
        self.ad.use_nla = self.use_nla
        for c in self.cons:
            c.mute = False
        for pb in self.rig.pose.bones:
            pb.matrix_basis.identity()
        return False


def load_clip(context, rig, path, slot):
    """(action, slot) for a clip on this rig, imported once and reused. slot 'AUTO' is resolved from the clip."""
    for a in bpy.data.actions:
        if a.get(SRC_PROP) == path and a.get(RIG_PROP) == rig.name and \
                (a.get("cod_montage_auto") if slot == 'AUTO' else a.get(SLOT_PROP) == slot):
            return a, a[SLOT_PROP]
    scene = context.scene
    fps = (scene.render.fps, scene.render.fps_base)
    if context.object is not None and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in context.view_layer.objects:
        o.select_set(False)
    rig.select_set(True)
    context.view_layer.objects.active = rig
    before = set(bpy.data.actions)
    with _Paused(rig) as paused:
        bpy.ops.import_scene.cast(filepath=path, import_reset=True, import_time=False)
        action = paused.ad.action if paused.ad.action not in before else \
            next((a for a in bpy.data.actions if a not in before), None)
        paused.ad.action = None
    clip_fps = scene.render.fps / scene.render.fps_base
    scene.render.fps, scene.render.fps_base = fps
    if action is None:
        return None, None
    info = clip_info(path)
    offset = _is_offset_clip(rig, info)
    if offset:
        _rekey(rig, action, info["rotated"], as_offsets=True)
    elif info["identity"]:
        _rekey(rig, action, info["identity"], as_offsets=False)
    auto = slot == 'AUTO'
    if auto:
        slot = detect_slot(action_bones(action), info, offset)
    mask_action(action, slot)
    action.name = "M_" + os.path.splitext(os.path.basename(path))[0]
    action.use_fake_user = False
    action[SRC_PROP], action[SLOT_PROP], action[RIG_PROP] = path, slot, rig.name
    action["cod_montage_auto"] = auto
    action["cod_montage_fps"] = clip_fps
    return action, slot


# ---------------------------------------------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------------------------------------------

def _guess_folder(context):
    """The export's Animations folder: next to CoD AutoShader's Models Folder, or from an imported rig."""
    for o in context.scene.objects:
        d = o.get("cod_anim_dir") if o.type == 'ARMATURE' else None
        if d and os.path.isdir(d):
            return d
    s = getattr(context.scene, "cod_autoshader", None)
    root = bpy.path.abspath(getattr(s, "search_folder", "") or "") if s else ""
    if root:
        parent = os.path.dirname(os.path.normpath(root))
        for name in ("Animations", "animations", "anims"):
            if os.path.isdir(os.path.join(parent, name)):
                return os.path.join(parent, name)
    return ""


class CODM_LibraryClip(bpy.types.PropertyGroup):
    path: StringProperty()
    label: StringProperty()
    category: StringProperty()


def _entry_defaults(entry, category):
    entry.hold_end = category == 'DEATH'
    if category == 'FACE':
        entry.slot = 'FACE'
    elif category == 'AIM':
        entry.slot = 'AIM'


class CODM_Entry(bpy.types.PropertyGroup):
    path: StringProperty()
    label: StringProperty()
    category: StringProperty()
    slot: EnumProperty(name="Layer", items=[s[:3] + (s[3], i) for i, s in enumerate(SLOTS)], default='AUTO')
    start: EnumProperty(
        name="Starts",
        items=(('AUTO', "Auto", "Face and aim-offset clips play with the clip before them, the rest after it"),
               ('AFTER', "After Previous", "When the clip before it ends (overlapping by the blend)"),
               ('WITH', "With Previous", "At the same frame as the clip before it - layering, e.g. a reload "
                                         "over a run, or a face over a death")),
        default='AUTO')
    blend: IntProperty(name="Blend", default=6, min=0, max=60,
                       description="Frames to fade in and out, so clips crossfade instead of popping")
    repeat: FloatProperty(name="Repeat", default=1.0, min=0.1, max=50.0,
                          description="Play the clip this many times (loops: runs, idles, faces)")
    speed: FloatProperty(name="Speed", default=1.0, min=0.1, max=10.0)
    hold_end: BoolProperty(name="Hold Last Frame",
                           description="Stay on the last frame after the clip ends (deaths), instead of "
                                       "returning to the clip below")
    mute: BoolProperty(name="Skip", description="Leave this clip out of the montage")
    resolved: StringProperty()             # the layer Auto picked at the last build


def _category_update(self, context):
    self.library_index = 0


class CODM_Settings(bpy.types.PropertyGroup):
    folder: StringProperty(name="Animations", subtype='DIR_PATH',
                           description="The export's Animations folder (Saluki: exported_files/<game>/Animations)")
    category: EnumProperty(name="Category", items=[c[:3] + (c[3], i) for i, c in enumerate(CATEGORIES)],
                           default='ALL', update=_category_update)
    library: CollectionProperty(type=CODM_LibraryClip)
    library_index: IntProperty()
    scanned_folder: StringProperty()
    entries: CollectionProperty(type=CODM_Entry)
    entry_index: IntProperty()
    start_frame: IntProperty(name="Start Frame", default=1)
    auto_base: BoolProperty(
        name="Auto Base Pose", default=True,
        description="When upper-body or aim clips have nothing under them, hold a standing clip from the "
                    "library (or the first full-body clip in the montage) under the whole montage, so the legs "
                    "stand instead of staying in the bind pose")


# ---------------------------------------------------------------------------------------------------------------
# Building the montage
# ---------------------------------------------------------------------------------------------------------------

def _track(ad, name):
    track = ad.nla_tracks.get(name)
    if track is not None:
        return track
    below = [ad.nla_tracks.get(n) for n in TRACKS[:TRACKS.index(name)]]
    below = [t for t in below if t is not None]
    track = ad.nla_tracks.new(prev=below[-1]) if below else ad.nla_tracks.new()
    track.name = name
    return track


def clear_montage(rig, purge=True):
    """Take the montage layers off. purge: also delete the clips imported for it (else they are reused)."""
    ad = rig.animation_data
    if ad is None:
        return
    for name in TRACKS:
        track = ad.nla_tracks.get(name)
        if track is not None:
            ad.nla_tracks.remove(track)
    for a in list(bpy.data.actions) if purge else ():
        if a.get(RIG_PROP) == rig.name and a.users == 0:
            bpy.data.actions.remove(a)


def _new_strip(track, action, start, name):
    strip = track.strips.new(name, int(round(start)), action)
    if hasattr(strip, "action_slot") and strip.action_slot is None and len(action.slots):
        strip.action_slot = action.slots[0]
    return strip


def _stand_clip(settings):
    """A standing clip from the library for the base pose, best first."""
    best = None
    for item in settings.library:
        low = item.label.lower()
        for rank, pattern in enumerate((r"(^|_)me_stand_idle", r"stand_idle", r"(^|_)stand(_|$)", r"_idle$")):
            if re.search(pattern, low) and item.category in ('MOVE', 'LOBBY', 'OTHER'):
                if best is None or rank < best[0]:
                    best = (rank, item)
                break
    return best[1] if best else None


def _fit(strip, action, length):
    """Stretch a strip to `length` frames. A one-frame pose clip plays its first frame for the whole span."""
    f0, f1 = action.frame_range
    if f1 - f0 < 1.0:
        strip.action_frame_start, strip.action_frame_end = f0, f0 + 1.0
    strip.scale = max(length, 1.0) / max(strip.action_frame_end - strip.action_frame_start, 1.0)


def build_montage(context, rig, settings, report):
    if not _cast_ready():
        report({'ERROR'}, "The Cast importer (io_scene_cast) is not enabled")
        return 0
    entries = [e for e in settings.entries if not e.mute and e.path]
    if not entries:
        report({'WARNING'}, "The montage is empty - add clips from the library first")
        return 0
    clear_montage(rig, purge=False)
    ad = rig.animation_data or rig.animation_data_create()
    scene = context.scene
    frame_cur = scene.frame_current
    start0 = settings.start_frame

    # every clip first: the layers are then made bottom to top (Blender can only add a track above another)
    loaded = []
    for e in entries:
        if not os.path.exists(fs_path(e.path)):
            report({'WARNING'}, "Missing: %s" % e.label)
            continue
        action, slot = load_clip(context, rig, e.path, e.slot)
        if action is None:
            report({'WARNING'}, "%s has no animation" % e.label)
            continue
        e.resolved = slot
        loaded.append((e, action, slot))
    if not loaded:
        return 0
    # CoD clips run at their own rate (30 fps): the scene takes the first clip's, so they play at game speed
    clip_fps = loaded[0][1].get("cod_montage_fps", 30.0)
    scene.render.fps, scene.render.fps_base = round(clip_fps), round(clip_fps) / clip_fps
    tracks, prev = {}, None
    for name in TRACKS:
        prev = ad.nla_tracks.new(prev=prev) if prev is not None else ad.nla_tracks.new()
        prev.name = name
        tracks[name] = prev

    last_start, last_len, seq_end, flip = start0, 0.0, None, {'FULL': 0, 'UPPER': 0}
    placed, bases, layered_alone, full_spans = [], [], False, []
    for e, action, slot in loaded:
        if slot == 'BASE':
            bases.append(action)
            continue
        fps_scale = clip_fps / action.get("cod_montage_fps", clip_fps)
        frames = action.frame_range[1] - action.frame_range[0]
        mode = e.start if e.start != 'AUTO' else ('WITH' if slot in ('FACE', 'AIM') else 'AFTER')
        if mode == 'AFTER' and seq_end is not None:
            s = seq_end - e.blend
        else:
            s = last_start if mode == 'WITH' else start0
        if slot in ('FULL', 'UPPER'):
            name = TRACKS[1 + (0 if slot == 'FULL' else 2) + flip[slot] % 2]
            flip[slot] += 1
        else:
            name = "Montage Aim" if slot == 'AIM' else "Montage Face"
        strip = _new_strip(tracks[name], action, s, e.label)
        if frames < 1.0:
            # a pose (aim offsets are one frame): it lasts as long as the clip it is layered with
            _fit(strip, action, last_len if mode == 'WITH' and last_len else 30.0)
        else:
            strip.scale = fps_scale / e.speed
            strip.repeat = e.repeat
        strip.blend_type = 'COMBINE' if slot == 'AIM' else 'REPLACE'
        strip.extrapolation = 'HOLD_FORWARD' if e.hold_end else 'NOTHING'
        if e.blend:
            strip.use_auto_blend = False
            span = strip.frame_end - strip.frame_start
            strip.blend_in = min(e.blend, span / 2)
            strip.blend_out = 0 if e.hold_end else min(e.blend, span / 2)
        if mode == 'AFTER' or seq_end is None:
            last_start, last_len = strip.frame_start, strip.frame_end - strip.frame_start
            seq_end = strip.frame_end
        if slot == 'FULL':
            full_spans.append((strip.frame_start, strip.frame_end))
        elif slot in ('UPPER', 'AIM'):
            layered_alone = layered_alone or not any(a <= strip.frame_start < b for a, b in full_spans)
        placed.append(strip)
    end = max([st.frame_end for st in placed] + [start0 + 1])

    if not bases and layered_alone and settings.auto_base:
        stand = _stand_clip(settings)
        src = stand.path if stand is not None else next(
            (st.action[SRC_PROP] for st in placed if st.action.get(SLOT_PROP) == 'FULL'), None)
        action = load_clip(context, rig, src, 'BASE')[0] if src else None
        if action is not None:
            bases.append(action)
            report({'INFO'}, "Base pose: %s (the legs stand on it)" % action.name[2:])
        else:
            report({'WARNING'}, "No base pose: the legs stay in the bind pose under upper-body clips. Add a "
                                "standing or other full-body clip to the montage with Layer: Base Pose")
    for action in bases[:1]:
        strip = _new_strip(tracks[TRACK_BASE], action, start0, "Base: " + action.name[2:])
        f0 = action.frame_range[0]
        strip.action_frame_start, strip.action_frame_end = f0, f0 + 1.0          # its first frame, held
        strip.scale = max(end - start0, 1.0)
        strip.extrapolation = 'HOLD'
        strip.blend_type = 'REPLACE'
    for name, track in tracks.items():
        if not len(track.strips):
            ad.nla_tracks.remove(track)
    ad.use_nla = True
    scene.frame_start, scene.frame_end = start0, int(math.ceil(end))
    scene.frame_set(frame_cur if start0 <= frame_cur <= end else start0)
    return len(placed) + len(bases[:1])


# ---------------------------------------------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------------------------------------------

def _settings(context):
    return context.scene.cod_montage


def _target_rig(context):
    o = context.object
    if o is not None and o.type != 'ARMATURE' and o.parent is not None and o.parent.type == 'ARMATURE':
        o = o.parent
    return o if o is not None and o.type == 'ARMATURE' else None


class CODM_OT_scan(bpy.types.Operator):
    bl_idname = "cod_montage.scan"
    bl_label = "Scan Library"
    bl_description = "List every third-person clip in the Animations folder (viewmodel clips are left out)"

    def execute(self, context):
        s = _settings(context)
        if not s.folder:
            s.folder = _guess_folder(context)
        folder = bpy.path.abspath(s.folder)
        if not folder or not os.path.isdir(fs_path(folder)):
            self.report({'ERROR'}, "Pick the export's Animations folder first")
            return {'CANCELLED'}
        found = []
        for dirpath, _dirs, files in os.walk(fs_path(folder)):
            for f in files:
                if not f.lower().endswith(".cast"):
                    continue
                stem = f[:-5]
                if _is_viewmodel(stem.lower()):
                    continue
                found.append((clip_label(stem.lower()), os.path.join(dirpath, f), clip_category(stem)))
        s.library.clear()
        for label, path, cat in sorted(found):
            item = s.library.add()
            item.name, item.label, item.path, item.category = label, label, path, cat
        s.library_index = 0
        s.scanned_folder = folder
        counts = {}
        for _l, _p, cat in found:
            counts[cat] = counts.get(cat, 0) + 1
        self.report({'INFO'}, "%d clips: %s" % (len(found), ", ".join(
            "%d %s" % (n, dict((c[0], c[1]) for c in CATEGORIES)[k].lower()) for k, n in
            sorted(counts.items(), key=lambda kv: -kv[1]))))
        return {'FINISHED'}


class CODM_OT_add(bpy.types.Operator):
    bl_idname = "cod_montage.add"
    bl_label = "Add to Montage"
    bl_description = "Add this clip to the end of the montage"
    bl_options = {'INTERNAL'}

    index: IntProperty(default=-1)

    def execute(self, context):
        s = _settings(context)
        i = self.index if self.index >= 0 else s.library_index
        if not 0 <= i < len(s.library):
            return {'CANCELLED'}
        item = s.library[i]
        e = s.entries.add()
        e.name, e.label, e.path, e.category = item.label, item.label, item.path, item.category
        _entry_defaults(e, item.category)
        s.entry_index = len(s.entries) - 1
        return {'FINISHED'}


class CODM_OT_set_base(bpy.types.Operator):
    bl_idname = "cod_montage.set_base"
    bl_label = "Use as Base Pose"
    bl_description = "Hold this clip's first frame under the whole montage (the stance the legs stand in)"

    def execute(self, context):
        s = _settings(context)
        if not 0 <= s.library_index < len(s.library):
            return {'CANCELLED'}
        for e in [e for e in s.entries if e.slot == 'BASE']:
            s.entries.remove(list(s.entries).index(e))
        item = s.library[s.library_index]
        e = s.entries.add()
        e.name, e.label, e.path, e.category, e.slot = item.label, item.label, item.path, item.category, 'BASE'
        s.entries.move(len(s.entries) - 1, 0)
        s.entry_index = 0
        return {'FINISHED'}


class CODM_OT_move(bpy.types.Operator):
    bl_idname = "cod_montage.move"
    bl_label = "Move Clip"
    bl_options = {'INTERNAL'}

    direction: EnumProperty(items=(('UP', "Up", ""), ('DOWN', "Down", "")))

    def execute(self, context):
        s = _settings(context)
        i, j = s.entry_index, s.entry_index + (-1 if self.direction == 'UP' else 1)
        if 0 <= i < len(s.entries) and 0 <= j < len(s.entries):
            s.entries.move(i, j)
            s.entry_index = j
        return {'FINISHED'}


class CODM_OT_remove(bpy.types.Operator):
    bl_idname = "cod_montage.remove"
    bl_label = "Remove Clip"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        s = _settings(context)
        if 0 <= s.entry_index < len(s.entries):
            s.entries.remove(s.entry_index)
            s.entry_index = max(0, min(s.entry_index, len(s.entries) - 1))
        return {'FINISHED'}


class CODM_OT_clear_list(bpy.types.Operator):
    bl_idname = "cod_montage.clear_list"
    bl_label = "Clear Montage List"
    bl_description = "Empty the montage list (the character keeps what was built until you build again)"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        _settings(context).entries.clear()
        return {'FINISHED'}


class CODM_OT_build(bpy.types.Operator):
    bl_idname = "cod_montage.build"
    bl_label = "Build Montage"
    bl_description = "Put the montage on the selected character: each clip on its own masked layer, crossfaded"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _target_rig(context) is not None

    def execute(self, context):
        rig = _target_rig(context)
        n = build_montage(context, rig, _settings(context), self.report)
        if n:
            for o in context.view_layer.objects:
                o.select_set(o == rig)
            context.view_layer.objects.active = rig
            self.report({'INFO'}, "Montage built on %s: %d clip(s), frames %d-%d" % (
                rig.name, n, context.scene.frame_start, context.scene.frame_end))
        return {'FINISHED'} if n else {'CANCELLED'}


class CODM_OT_clear_rig(bpy.types.Operator):
    bl_idname = "cod_montage.clear_rig"
    bl_label = "Remove Montage"
    bl_description = "Take the montage layers off the selected character"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _target_rig(context) is not None

    def execute(self, context):
        rig = _target_rig(context)
        clear_montage(rig)
        for pb in rig.pose.bones:
            pb.matrix_basis.identity()
        return {'FINISHED'}


# ---------------------------------------------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------------------------------------------

class CODM_UL_library(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        row = layout.row(align=True)
        row.label(text=item.label, icon=CATEGORY_ICON.get(item.category, 'QUESTION'))
        op = row.operator(CODM_OT_add.bl_idname, text="", icon='ADD', emboss=False)
        op.index = index

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        flags = helper.filter_items_by_name(self.filter_name, self.bitflag_filter_item, items, "label") \
            if self.filter_name else [self.bitflag_filter_item] * len(items)
        cat = data.category
        if cat != 'ALL':
            flags = [f if it.category == cat else 0 for f, it in zip(flags, items)]
        return flags, []


class CODM_UL_entries(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        slot = item.slot if item.slot != 'AUTO' else (item.resolved or 'AUTO')
        row = layout.row(align=True)
        row.active = not item.mute
        row.label(text="%d. %s" % (index + 1, item.label), icon=SLOT_ICON.get(slot, 'AUTO'))
        start = item.start if item.start != 'AUTO' else ('WITH' if slot in ('FACE', 'AIM') else 'AFTER')
        if item.slot != 'BASE':
            row.label(text="with" if start == 'WITH' else "", icon='LINKED' if start == 'WITH' else 'NONE')
        row.prop(item, "mute", text="", icon='HIDE_ON' if item.mute else 'HIDE_OFF', emboss=False)


class CODM_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "CoD Montage"
    bl_label = "CoD Anim Montage"

    def draw(self, context):
        layout = self.layout
        s = _settings(context)
        rig = _target_rig(context)
        if not _cast_ready():
            layout.label(text="Enable the Cast importer (io_scene_cast)", icon='ERROR')
        box = layout.box()
        row = box.row()
        row.label(text=rig.name if rig else "Select a character", icon='ARMATURE_DATA' if rig else 'INFO')

        header, body = layout.panel("codm_library", default_closed=False)
        header.label(text="Library", icon='ASSET_MANAGER')
        if body:
            row = body.row(align=True)
            row.prop(s, "folder", text="")
            row.operator(CODM_OT_scan.bl_idname, text="", icon='FILE_REFRESH')
            if not s.library:
                body.operator(CODM_OT_scan.bl_idname, text="Scan Animations", icon='VIEWZOOM')
            else:
                grid = body.grid_flow(row_major=True, columns=3, even_columns=True, align=True)
                grid.prop(s, "category", expand=True)
                body.template_list("CODM_UL_library", "", s, "library", s, "library_index", rows=8)
                row = body.row(align=True)
                row.operator(CODM_OT_add.bl_idname, text="Add", icon='ADD').index = -1
                row.operator(CODM_OT_set_base.bl_idname, text="Base Pose", icon='ARMATURE_DATA')

        header, body = layout.panel("codm_montage", default_closed=False)
        header.label(text="Montage (%d)" % len(s.entries), icon='NLA')
        if body:
            row = body.row()
            row.template_list("CODM_UL_entries", "", s, "entries", s, "entry_index", rows=5)
            col = row.column(align=True)
            col.operator(CODM_OT_move.bl_idname, text="", icon='TRIA_UP').direction = 'UP'
            col.operator(CODM_OT_move.bl_idname, text="", icon='TRIA_DOWN').direction = 'DOWN'
            col.separator()
            col.operator(CODM_OT_remove.bl_idname, text="", icon='REMOVE')
            col.operator(CODM_OT_clear_list.bl_idname, text="", icon='TRASH')
            if 0 <= s.entry_index < len(s.entries):
                e = s.entries[s.entry_index]
                col = body.column(align=True)
                col.use_property_split = True
                col.use_property_decorate = False
                col.prop(e, "slot")
                if e.slot != 'BASE':
                    col.prop(e, "start")
                    col.prop(e, "blend")
                    col.prop(e, "repeat")
                    col.prop(e, "speed")
                    col.prop(e, "hold_end")
            col = body.column(align=True)
            col.use_property_split = True
            col.use_property_decorate = False
            col.prop(s, "start_frame")
            col.prop(s, "auto_base")
            row = body.row(align=True)
            row.scale_y = 1.4
            row.operator(CODM_OT_build.bl_idname, text="Build on Character", icon='PLAY')
            row.operator(CODM_OT_clear_rig.bl_idname, text="", icon='TRASH')


classes = (CODM_LibraryClip, CODM_Entry, CODM_Settings, CODM_OT_scan, CODM_OT_add, CODM_OT_set_base, CODM_OT_move,
           CODM_OT_remove, CODM_OT_clear_list, CODM_OT_build, CODM_OT_clear_rig, CODM_UL_library, CODM_UL_entries,
           CODM_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.cod_montage = PointerProperty(type=CODM_Settings)


def unregister():
    del bpy.types.Scene.cod_montage
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
